#############################

### [TEMPLATE_NAME] Template ###

#############################



Theme Name: [TEMPLATE_NAME]

Theme URI: [THEME_URI]

Description: [TEMPLATE_DESCRIPTION]

Version: 1.0

Author: [AUTHOR]

Author URI: [AUTHOR_URI]


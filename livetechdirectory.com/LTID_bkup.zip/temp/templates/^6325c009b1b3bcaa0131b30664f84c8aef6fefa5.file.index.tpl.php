<?php /* Smarty version Smarty-3.1.12, created on 2014-05-24 05:42:27
         compiled from "/home/mylive5/public_html/livetechdirectory.com/templates/Core/DefaultFrontend/views/tag/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:82570175853803143b1b435-75890145%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6325c009b1b3bcaa0131b30664f84c8aef6fefa5' => 
    array (
      0 => '/home/mylive5/public_html/livetechdirectory.com/templates/Core/DefaultFrontend/views/tag/index.tpl',
      1 => 1386917016,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '82570175853803143b1b435-75890145',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_53803143b1beb9_38631856',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_53803143b1beb9_38631856')) {function content_53803143b1beb9_38631856($_smarty_tpl) {?><?php }} ?>
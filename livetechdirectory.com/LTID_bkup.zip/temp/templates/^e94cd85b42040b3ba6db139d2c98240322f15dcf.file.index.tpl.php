<?php /* Smarty version Smarty-3.1.12, created on 2014-04-25 16:56:26
         compiled from "/home/mylive5/public_html/livetechdirectory.com/templates/Core/DefaultFrontend/views/index/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1543662343535a93ba7f2777-30597515%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e94cd85b42040b3ba6db139d2c98240322f15dcf' => 
    array (
      0 => '/home/mylive5/public_html/livetechdirectory.com/templates/Core/DefaultFrontend/views/index/index.tpl',
      1 => 1386917016,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1543662343535a93ba7f2777-30597515',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'MAINCONTENT' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_535a93ba7f70c8_33288587',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535a93ba7f70c8_33288587')) {function content_535a93ba7f70c8_33288587($_smarty_tpl) {?><?php echo $_smarty_tpl->tpl_vars['MAINCONTENT']->value;?>
<?php }} ?>
<?php /* Smarty version Smarty-3.1.12, created on 2015-10-29 00:13:11
         compiled from "/home/mylive5/public_html/livetechdirectory.com/templates/Core/DefaultFrontend/views/_listings/_placeholders/videoEmbed.tpl" */ ?>
<?php /*%%SmartyHeaderCode:199166202456316497af7d23-86454944%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e4106d1e2945adc51e9def4333f2a6086da37cf1' => 
    array (
      0 => '/home/mylive5/public_html/livetechdirectory.com/templates/Core/DefaultFrontend/views/_listings/_placeholders/videoEmbed.tpl',
      1 => 1386917016,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '199166202456316497af7d23-86454944',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'LISTING_VIDEO_HTML' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_56316497b01836_24597750',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56316497b01836_24597750')) {function content_56316497b01836_24597750($_smarty_tpl) {?><div class="video-container">
    <?php echo $_smarty_tpl->tpl_vars['LISTING_VIDEO_HTML']->value;?>

    
</div>
<?php }} ?>
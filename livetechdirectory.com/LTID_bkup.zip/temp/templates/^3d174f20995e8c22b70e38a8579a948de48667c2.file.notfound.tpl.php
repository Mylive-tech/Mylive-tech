<?php /* Smarty version Smarty-3.1.12, created on 2014-04-25 16:57:35
         compiled from "/home/mylive5/public_html/livetechdirectory.com/templates/Core/DefaultFrontend/views/error/notfound.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1910934303535a93ff40a3a5-31689671%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3d174f20995e8c22b70e38a8579a948de48667c2' => 
    array (
      0 => '/home/mylive5/public_html/livetechdirectory.com/templates/Core/DefaultFrontend/views/error/notfound.tpl',
      1 => 1386917016,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1910934303535a93ff40a3a5-31689671',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_535a93ff40c929_74795078',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535a93ff40c929_74795078')) {function content_535a93ff40c929_74795078($_smarty_tpl) {?><div class="pageNotFound">
    <div>404</div>
    Page Not Found
</div><?php }} ?>
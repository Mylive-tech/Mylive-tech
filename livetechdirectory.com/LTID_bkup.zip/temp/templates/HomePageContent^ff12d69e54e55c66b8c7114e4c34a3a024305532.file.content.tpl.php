<?php /* Smarty version Smarty-3.1.12, created on 2014-04-25 16:56:26
         compiled from "/home/mylive5/public_html/livetechdirectory.com/application/widgets/HomePageContent/templates/content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1645672386535a93ba80d0f2-66622007%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ff12d69e54e55c66b8c7114e4c34a3a024305532' => 
    array (
      0 => '/home/mylive5/public_html/livetechdirectory.com/application/widgets/HomePageContent/templates/content.tpl',
      1 => 1387383446,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1645672386535a93ba80d0f2-66622007',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'TEXT' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_535a93ba813b03_47799584',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535a93ba813b03_47799584')) {function content_535a93ba813b03_47799584($_smarty_tpl) {?><div class="textbox">
<?php echo $_smarty_tpl->tpl_vars['TEXT']->value;?>

</div>
<?php }} ?>
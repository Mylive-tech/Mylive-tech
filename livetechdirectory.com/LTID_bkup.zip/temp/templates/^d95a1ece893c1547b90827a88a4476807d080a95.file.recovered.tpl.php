<?php /* Smarty version Smarty-3.1.12, created on 2015-01-25 05:45:01
         compiled from "/home/mylive5/public_html/livetechdirectory.com/templates/Core/DefaultFrontend/views/user/recovered.tpl" */ ?>
<?php /*%%SmartyHeaderCode:113954101154c482dd16b262-18180500%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd95a1ece893c1547b90827a88a4476807d080a95' => 
    array (
      0 => '/home/mylive5/public_html/livetechdirectory.com/templates/Core/DefaultFrontend/views/user/recovered.tpl',
      1 => 1386917016,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '113954101154c482dd16b262-18180500',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_54c482dd16bb60_01880446',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54c482dd16bb60_01880446')) {function content_54c482dd16bb60_01880446($_smarty_tpl) {?><?php }} ?>
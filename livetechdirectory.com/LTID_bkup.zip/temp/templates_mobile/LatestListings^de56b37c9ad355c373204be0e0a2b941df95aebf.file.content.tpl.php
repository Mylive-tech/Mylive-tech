<?php /* Smarty version Smarty-3.1.12, created on 2014-04-26 09:08:18
         compiled from "/home/mylive5/public_html/livetechdirectory.com/application/widgets/LatestListings/templates/content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1445324658535b7782a80f13-09057333%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'de56b37c9ad355c373204be0e0a2b941df95aebf' => 
    array (
      0 => '/home/mylive5/public_html/livetechdirectory.com/application/widgets/LatestListings/templates/content.tpl',
      1 => 1387383446,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1445324658535b7782a80f13-09057333',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'LISTINGS' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_535b7782a8aeb3_78181315',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535b7782a8aeb3_78181315')) {function content_535b7782a8aeb3_78181315($_smarty_tpl) {?><div class="listingsList">
<?php echo $_smarty_tpl->tpl_vars['LISTINGS']->value;?>

</div><?php }} ?>
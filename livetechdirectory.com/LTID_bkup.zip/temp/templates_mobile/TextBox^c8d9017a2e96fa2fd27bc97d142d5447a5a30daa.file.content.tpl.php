<?php /* Smarty version Smarty-3.1.12, created on 2014-05-06 17:08:12
         compiled from "/home/mylive5/public_html/livetechdirectory.com/application/widgets/TextBox/templates/content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1305616377536916fc2fd5b0-48598426%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c8d9017a2e96fa2fd27bc97d142d5447a5a30daa' => 
    array (
      0 => '/home/mylive5/public_html/livetechdirectory.com/application/widgets/TextBox/templates/content.tpl',
      1 => 1387383446,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1305616377536916fc2fd5b0-48598426',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'TEXTBOX' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_536916fc307ea5_58561800',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_536916fc307ea5_58561800')) {function content_536916fc307ea5_58561800($_smarty_tpl) {?><div class="textbox">
<?php echo $_smarty_tpl->tpl_vars['TEXTBOX']->value;?>

</div>
<?php }} ?>
<?php /* Smarty version Smarty-3.1.12, created on 2014-04-27 18:56:49
         compiled from "/home/mylive5/public_html/livetechdirectory.com/templates/MobileFormat/views/index/latest.tpl" */ ?>
<?php /*%%SmartyHeaderCode:534046169535d52f1e92c46-50130912%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5fc47bd52e758554b3fb229c9aa22e793a844af4' => 
    array (
      0 => '/home/mylive5/public_html/livetechdirectory.com/templates/MobileFormat/views/index/latest.tpl',
      1 => 1387383446,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '534046169535d52f1e92c46-50130912',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_535d52f1ea0795_41334940',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535d52f1ea0795_41334940')) {function content_535d52f1ea0795_41334940($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("views/_shared/listingRender.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('PAGETITLE'=>"Latest"), 0);?>

<?php }} ?>
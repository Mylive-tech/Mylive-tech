<?php /* Smarty version Smarty-3.1.12, created on 2014-04-25 17:19:03
         compiled from "/home/mylive5/public_html/livetechdirectory.com/templates/MobileFormat/views/error/notfound.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1994479309535a9907bca045-17946357%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bbe1d955c237fd8337e8a16547a9c67625c2b6ba' => 
    array (
      0 => '/home/mylive5/public_html/livetechdirectory.com/templates/MobileFormat/views/error/notfound.tpl',
      1 => 1387383446,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1994479309535a9907bca045-17946357',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_535a9907bcbbb5_17706297',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535a9907bcbbb5_17706297')) {function content_535a9907bcbbb5_17706297($_smarty_tpl) {?>
    <li class="group">404</li>
    <li>Page Not Found</li>
<?php }} ?>
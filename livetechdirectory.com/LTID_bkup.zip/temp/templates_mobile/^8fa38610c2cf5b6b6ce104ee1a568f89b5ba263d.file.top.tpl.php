<?php /* Smarty version Smarty-3.1.12, created on 2014-05-07 00:23:49
         compiled from "/home/mylive5/public_html/livetechdirectory.com/templates/MobileFormat/views/index/top.tpl" */ ?>
<?php /*%%SmartyHeaderCode:140732794453697d1598cec1-76056307%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8fa38610c2cf5b6b6ce104ee1a568f89b5ba263d' => 
    array (
      0 => '/home/mylive5/public_html/livetechdirectory.com/templates/MobileFormat/views/index/top.tpl',
      1 => 1387383446,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '140732794453697d1598cec1-76056307',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_53697d159a24b7_17498842',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_53697d159a24b7_17498842')) {function content_53697d159a24b7_17498842($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("views/_shared/listingRender.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('PAGETITLE'=>"Top"), 0);?>
<?php }} ?>
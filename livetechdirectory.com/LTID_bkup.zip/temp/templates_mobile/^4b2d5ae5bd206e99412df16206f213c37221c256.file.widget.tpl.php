<?php /* Smarty version Smarty-3.1.12, created on 2014-04-25 17:19:03
         compiled from "/home/mylive5/public_html/livetechdirectory.com/templates/MobileFormat/views/_shared/widget.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1479315206535a9907c88a91-89607131%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4b2d5ae5bd206e99412df16206f213c37221c256' => 
    array (
      0 => '/home/mylive5/public_html/livetechdirectory.com/templates/MobileFormat/views/_shared/widget.tpl',
      1 => 1387383446,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1479315206535a9907c88a91-89607131',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'CONTENT' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_535a9907c8dbd0_14784957',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535a9907c8dbd0_14784957')) {function content_535a9907c8dbd0_14784957($_smarty_tpl) {?><?php echo $_smarty_tpl->tpl_vars['CONTENT']->value;?>


<?php }} ?>
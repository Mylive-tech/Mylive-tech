<?php /* Smarty version Smarty-3.1.12, created on 2014-04-25 19:18:20
         compiled from "/home/mylive5/public_html/livetechdirectory.com/application/widgets/CategoryContent/templates/content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1899056329535ab4fc460fe1-97565525%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a892390d73c5273ac0dd3394211b710e7c9c3c6f' => 
    array (
      0 => '/home/mylive5/public_html/livetechdirectory.com/application/widgets/CategoryContent/templates/content.tpl',
      1 => 1387383446,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1899056329535ab4fc460fe1-97565525',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'TEXT' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_535ab4fc46a567_99450751',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_535ab4fc46a567_99450751')) {function content_535ab4fc46a567_99450751($_smarty_tpl) {?><div class="textbox">
<?php echo $_smarty_tpl->tpl_vars['TEXT']->value;?>

</div>
<?php }} ?>
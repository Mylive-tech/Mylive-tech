jQuery( document ).ready(function($) {
    $('#ask_an_estimate_popup').addClass('mfp-hide');
    /* Open Estimate Lightbox */
    $(".ask-an-estimate-button").magnificPopup();
});

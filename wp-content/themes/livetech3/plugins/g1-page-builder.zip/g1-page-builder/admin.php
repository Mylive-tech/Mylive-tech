<?php
// Prevent direct script access
if ( !defined('ABSPATH') )
    die ( 'No direct script access allowed' );
?>
<?php
if ( ! class_exists( 'G1_Page_Builder_Admin' ) ):

class G1_Page_Builder_Admin {
    public function __construct() {
        add_action( 'admin_init', array( $this, 'admin_init' ) );
        //add_action( 'admin_menu', array( $this, 'add_admin_page' ) );

        add_action('wp_ajax_g1_pb_load_wp_editor', array( $this, 'load_wp_editor' ));
    }

    public function load_wp_editor ()
    {
        $ajax_data = $_POST['ajax_data'];

        $content = stripcslashes($ajax_data['content']);
        $element_id = $ajax_data['element_id'];

        ob_start();
        wp_editor( $content, $element_id , array() );
        $output = ob_get_clean();

        echo $output;
        exit;
    }

    public function admin_init() {
        register_setting( G1_Page_Builder::get_option_name(), G1_Page_Builder::get_option_name() );
    }

    public function add_admin_page() {
        add_options_page(
            __( 'G1 Page Builder', 'g1_theme' ),
            __( 'G1 Page Builder', 'g1_theme' ),
            'manage_options',
            'g1_page_builder_options',
            array( $this, 'render_admin_page' )
        );
    }

    public function capture_admin_page() {
        ob_start();
            include( 'tpl_admin.php');
        $out = ob_get_clean();

        return $out;
    }

    public function render_admin_page() {
        echo $this->capture_admin_page();
    }
}
endif;

function G1_Page_Builder_Admin() {
    static $instance = null;

    if ( null === $instance )
        $instance = new G1_Page_Builder_Admin();

    return $instance;
}
// Fire in the hole :)
G1_Page_Builder_Admin();
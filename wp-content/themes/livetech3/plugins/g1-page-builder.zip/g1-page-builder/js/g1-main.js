/* global jQuery */
/* global g1PageBuilder */

(function ($) {
    "use strict";

    g1PageBuilder.setDebugMode(false);

    $('#postdivrich').g1Builder();
})(jQuery);
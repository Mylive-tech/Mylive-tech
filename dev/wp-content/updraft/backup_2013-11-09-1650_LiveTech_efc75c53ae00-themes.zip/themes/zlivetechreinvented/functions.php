<?php

// ====================================================
// WORDPRESS
// ====================================================

// Post thumbnail
if( function_exists( 'add_theme_support' ) )
{    
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 100, 100, true );
}

// Remove generator
remove_action( 'wp_head', 'wp_generator' );
function wpt_remove_version() 
{
	return '';
}
add_filter( 'the_generator', 'wpt_remove_version' );

// ====================================================
// CUSTOM FUNCTIONS
// ====================================================

// Does page navigation exist?
function mb_page_navigation_exist() 
{
	global $wp_query;
	return ( $wp_query->max_num_pages > 1 );
}

// Get category Id by slug
function mb_get_category_id_by_slug( $slug )
{
    $category_obj = get_category_by_slug( $slug ); 
    return $category_obj->term_id;   
}

// Display post summary
function mb_display_post_summary( $post_id )
{    
    $post_summary = '';
    
    $summary = get_post_meta( $post_id, 'summary', true );
    if( trim( $summary ) != '' )
    {
        $post_summary = $summary;
    }
    else
    {   
        $post_summary = get_the_content( '' );
    }
    
    return substr( strip_tags( $post_summary ) , 0, 250 );
}

// Display breadcrumb
function mb_display_breadcrumb() 
{
	if( !is_home() ) 
	{
		echo '<a href="' . get_option( 'home' ) . '">' . 'Home' . '</a> <strong>&rsaquo;</strong> ';
		
		if( is_category() || is_single() ) 
		{
			the_category(', ');
//			if(is_single()) 
//			{
//				echo " <strong>&rsaquo;</strong> ";
//				the_title();
//			}
		} 
		elseif( is_page() ) 
			{ echo the_title(); }
		elseif( is_tag() ) 
			{ single_tag_title(); }
		elseif( is_day() ) 
			{ echo 'Archive for '; the_time( 'j F, Y' ); }
		elseif( is_month() ) 
			{ echo 'Archive for '; the_time( 'F Y' ); }
		elseif( is_year() ) 
			{ echo 'Archive for '; the_time( 'Y' ); }
		elseif( is_author() ) 
			{ echo 'Author Archive'; }
		elseif( isset( $_GET['paged'] ) && ! empty( $_GET['paged'] ) ) 
			{ echo 'Blog Archives'; }
		elseif( is_search() ) 
			{ echo 'Search Results'; }
	}
}

// ====================================================
// GOOGLE ADS
// ====================================================

define( 'DEFAULT_ADSENSE_PUBID', 'pub-6033100621695623' );
define( 'NCHOUGLE_ADSENSE_PUBID', 'pub-6074295968436653' );

function mb_display_google_ad( $user_login, $ad_width = '160', $ad_height = '600', $ad_type = 'text_image', $ad_color_border = 'FFFFFF', $ad_color_bg = 'FFFFFF' )
{
    echo '<script type="text/javascript">';
    
    switch( strtolower( $user_login ) )
    { 
        case 'nchougle': 
            echo 'google_ad_client = "' . NCHOUGLE_ADSENSE_PUBID . '";'; break;
        default: 
            echo 'google_ad_client = "' . DEFAULT_ADSENSE_PUBID . '";';
    }
    
    echo 'google_ad_width = ' . $ad_width . ';';
    echo 'google_ad_height = ' . $ad_height . ';';
    echo 'google_ad_format = "' . $ad_width . 'x' . $ad_height . '_as";';
    echo 'google_ad_type = "' . $ad_type . '";';
    echo 'google_color_border = "' . $ad_color_border . '";';
    echo 'google_color_bg = "' . $ad_color_bg . '";';
    echo 'google_color_link = "C3413F";';
    echo 'google_color_text = "101010";';
    echo 'google_color_url = "346F29";';
    echo '</script>';
    echo '<script type="text/javascript"';
    echo ' src="http://pagead2.googlesyndication.com/pagead/show_ads.js">';
    echo '</script>';
}

// ====================================================
// COMMENTS
// ====================================================

function tj_comment_class( $classname = '' ) 
{
	global $comment, $post;

	$c = array();	
	if( $classname )
		$c[] = $classname;

	// Collects the comment type (comment, trackback),
	$c[] = $comment->comment_type;

	// If the comment author has an id (registered), then print the log in name
	if ( $comment->user_id > 0 ) {
		$user = get_userdata( $comment->user_id );

		// For all registered users, 'byuser'; to specificy the registered user, 'commentauthor+[log in name]'
		$c[] = "byuser comment-author-" . sanitize_title_with_dashes( strtolower( $user->user_login ) );
		// For comment authors who are the author of the post
		if ( $comment->user_id === $post->post_author )
			$c[] = 'bypostauthor';
	}

	// Separates classes with a single space, collates classes for comment LI
	return join( ' ', apply_filters( 'comment_class', $c ) );
}

// ================================================
// DISQUS
// ================================================

// Hide Disqus from the Pages
// Ref: http://buffernow.com/disable-disqus-on-certain-pages-wordpress/
function hide_disqus_from_pages()
{
	if( is_page() )
	{
		?>
	<script>
	$( document ).ready( function() 
	{
		$( "#disqus_thread" ).remove()
	});
	</script>
<?php 
	} 
}
add_action('wp_footer', 'hide_disqus_from_pages');

// ================================================
// IP FILTRATION
// ================================================

function get_no_ads_ip_range()
{
	$no_ads_ip_range = array(
			'65.55.0.0/16',
			'66.249.0.0/16',
			'67.195.0.0/16',
			'72.14.192.0/18',
			'72.14.194.17',
			'72.30.0.0/16',
			'74.6.0.0/16',
			'74.125.0.0/16',
			'122.152.129.15',
			'202.160.0.0/16',
			'172.16.3.100',
			'172.16.3.109',
			'157.54.0.0/15',
			'157.56.0.0/14',
			'157.60.0.0/16',
			'207.46.0.0/16',
			'38.99.96.0/24',
			'64.13.159.0/24',
			'199.87.248.0/21');
	return $no_ads_ip_range;
}
// Ref: http://www.php.net/manual/en/function.ip2long.php#86793

function custom_ip2long( $ip ) 
{
	if( is_numeric( $ip ) ) 
		return sprintf( "%u", floatval( $ip ) );
	else 
		return sprintf( "%u", floatval( ip2long( $ip ) ) );
} 

// This function checks if $ip is present in the $filter_list range.
function custom_ipfilter( $ip, $filter_list ) 
{
	$ip_addr = decbin( custom_ip2long( $ip ) );
	
	foreach( $filter_list as $this_ip )
	{
		$network = explode( "/", $this_ip );
		
		$net_addr = decbin( custom_ip2long( $network[0] ) );
		if( isset( $network[1] ) ) $cidr = $network[1];
		
		if( isset( $cidr ) )
		{
			if( substr( $net_addr, 0, $cidr ) == substr( $ip_addr, 0, $cidr ) ) 
				return true;
		}
		else
		{
			if( $net_addr == $ip_addr )
				return true;
		}
	}

	return false;
}

?>

<?php get_header(); ?>

<br /><br /><br /><br /><br /><br /><br /><br />
<center> Pages will come here. </center>
<br /><br /><br /><br /><br /><br /><br /><br />

<?php get_footer(); ?>
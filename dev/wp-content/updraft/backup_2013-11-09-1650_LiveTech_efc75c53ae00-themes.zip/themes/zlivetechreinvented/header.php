<!DOCTYPE html>
<html xmlns:fb="http://ogp.me/ns/fb#">
<head>

	<!-- Title -->
	<title><?php if ( is_front_page() || is_home() ) echo 'Live-Tech - Technical Support | VoIP Services | Cloud Services | Business Solutions | Web Solutions'; else wp_title( '', true ); ?></title>
	
	<!-- Stylesheet -->
	<link href="<?php bloginfo('template_url'); ?>/css/bootstrap.min.css" type="text/css" rel="stylesheet" media="all" />
	<link href="<?php bloginfo('template_url'); ?>/css/style.css" type="text/css" rel="stylesheet" media="all" />
	
    <!-- Script -->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js" type="text/javascript"></script>
    <script src="<?php bloginfo('template_url'); ?>/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php bloginfo('template_url'); ?>/js/jquery.scrollUp.min.js" type="text/javascript"></script>
    
    <!-- Favicon -->
    <link href="<?php bloginfo('template_url'); ?>/img/favicon.png" rel="icon" type="image/x-png" />
    <link href="<?php bloginfo('template_url'); ?>/img/favicon.png" rel="shortcut icon" type="image/x-png" />
    
    <!-- Font -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
    
    <!--[if lt IE 9]>
	<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
    
    <!-- Meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="copyright" content="Copyright &copy; Live-Tech. All Rights Reserved." />
    <meta charset="UTF-8" />
    <meta name="author" content="Live-Tech Web Team" />
	<meta name="robots" content="all" />
	<meta name="distribution" content="global" />
	<meta name="document-classification" content="general" />
	<meta name="rating" content="general" />
	<meta name="language" content="EN" />
    <meta name="application-name" content="Live-Tech" />
	<meta name="google-site-verification" content="p3zRB22wROv6pWKW-wE64_QuE2H2zI09fDz6KdUBTW4" />
	<meta name="alexaVerifyID" content="VyeIdnE9n11YyFnm7tQrEPTk0w8" />
	
	<?php /* 
    <meta name="description" content="Live Tech provides 24x7 Worldwide Technical Support. We Service Residential, Small Business, Corporate, Business Office Centers, Health Care and Government. We offer Onsite Technical Support or 100 percent Secure Eco Friendly Remote Support. We Install, Support and Maintain MAC and PC Computer Networks, Windows Servers, Windows Platforms, TalkSwitch PBX systems, Lynk VoIP Service and Support. Global setup and configure of IP phones and VoIP phone systems. Our Goal is to keep you worry free from anything IT" />
	<meta name="keywords" content="mylive tech com, IT technical support, on demand support packages, remote technical support, residential IT, business IT, anti virus solutions, IT support provider, fix my computer, computer repair services, computer tech support, Secure remote support, remote technical support, remote tech support, remote computer support, online tech support, online computer tech support, pc remote support, pc tech support, pc repair, pc repair services, pc services, small business computer support, help desk outsourcing, computer help desk support, residential computer repair, TalkSwitch Sales & Support, Lynk VoIP, AVG Antivirus Solutions, support consulting, certified AVG reseller, Microsoft Certified, TalkSwitch Certified and Gold Partner" />
	*/ ?>
	
	<!-- SupportSuite -->
	<script type="text/javascript" src="http://support.mylive-tech.com/visitor/index.php?_m=livesupport&_a=htmlcode&nolink=1"></script>
	
	<!-- ScrollUp -->
	<script type="text/javascript">
	if( $(window).width() > 800 )
	{
		$(function () 
		{
			$.scrollUp
			({
				scrollName: 'scrollUp', // Element ID
			    topDistance: '300', // Distance from top before showing element (px)
			    topSpeed: 1200, // Speed back to top (ms)
			    animation: 'fade', // Fade, slide, none
			    animationInSpeed: 200, // Animation in speed (ms)
			    animationOutSpeed: 200, // Animation out speed (ms)
			    scrollText: 'Back to Top', // Text for element
			    activeOverlay: false, // Set CSS color to display scrollUp active point, e.g '#00FFFF'
			});
		});
	}
	</script>
	
	<?php wp_head(); ?>
    
    <!-- Google Analytics -->
    <script type="text/javascript">
    /*
		var _gaq = _gaq || [];
		_gaq.push(['_setAccount', 'UA-17548286-2']);
		_gaq.push(['_trackPageview']);

		(function() {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		})();
	*/
	</script>
	
</head>
<body>

    <!-- HEADER -->

	<div class="navbar navbar-fixed-top">

		<!-- Support Action Calls -->
	
		<div class="container support-action-calls">	
		<div class="row">
		<div class="span2" style="text-align: center;">
			<a class="btn btn-warning btn-sup-action" href="" onclick="window.open('http://support.mylive-tech.com/visitor/index.php?_m=livesupport&_a=startclientchat&sessionid=yrph78uldkjpq9mkvf3jwaeca5hghb5p&proactive=0&departmentid=0&randno=19&fullname=&email=', 'newwindow', 'width=500, height=350'); return false;" title="Chat now with a Live-Tech agent."><i class="icon-comment"></i> Live Chat with Support</a>
		</div>
		<div class="span2" style="text-align: center;">
			<a class="btn btn-warning btn-sup-action" href="http://www.mylive-tech.com/connect.html" title="Start a remote session." target="_blank"><i class="icon-globe"></i> Start Remote Session</a>
		</div>
		<div class="span2" style="text-align: center;">
			<a class="btn btn-warning btn-sup-action" href="http://support.mylive-tech.com/index.php?_m=tickets&_a=submit" title="Submit a new ticket." target="_blank"><i class="icon-list-alt"></i> Submit a Ticket</a>
		</div>
		<div class="span2" style="text-align: center;">
			<a class="btn btn-warning btn-sup-action" href="http://support.mylive-tech.com/" title="Go to the Support Suite." target="_blank"><i class="icon-briefcase"></i> Support Suite</a>
		</div>
		<div class="span2" style="text-align: center;">
			<a class="btn btn-warning btn-sup-action" href="http://support.mylive-tech.com/index.php?_m=knowledgebase&_a=view" title="Read our Knowledge Base." target="_blank"><i class="icon-book"></i> Read Knowledge Base</a>
		</div>
		<div class="span2" style="text-align: center;">
			<a class="btn btn-warning btn-sup-action" href="#consultationform" title="Get genuine consultation."><i class="icon-ok-circle"></i> Get Consultation</a>
		</div>
		</div>
		</div>
		
		<!-- Header Bar -->
		
		<div class="container-fluid header-bar">
			
			<!-- Logo -->
			
			<div class="pull-left header-bar-logo">
				<a href="<?php echo site_url(); ?>" title="Welcome to Live-Tech."><strong><?php bloginfo( 'name' ); ?></strong> <span><?php bloginfo( 'description' ); ?></span></a> 
			</div>
			
			<!-- Search Box -->
			
			<script type="text/javascript">
			$(document).ready(function()
			{
				$('.search-query').focus(function() { $(this).animate({width: '150px'}, 500); });
				$('.search-query').blur(function() { $(this).animate({width: '70px'}, 500); });
			});
			</script>
			<form id="searchform" method="get" action="<?php echo htmlspecialchars( $_SERVER['PHP_SELF'] ); ?>" class="navbar-search pull-right">
			<input type="text" id="s" name="s" value="<?php the_search_query(); ?>" class="search-query" placeholder="Search" title="Type a keyword and hit Enter." />
			</form>
			
			<!-- Toll Free Phone Numbers -->
			
			<div class="btn-group pull-right toll-free-numbers">
		    	<button class="btn btn-success" onclick="window.location.href='tel:18883618511'" title="Click to call."><i class="icon-headphones"></i> Call Us Toll Free: USA/Canada | 1-888-361-8511</button>
			    <button class="btn btn-success dropdown-toggle" data-toggle="dropdown">
			    <span class="caret"></span>
			    </button>
			    <ul class="dropdown-menu">
			    	<li><a href="tel:17869752146" rel="external" title="Click to call."><i class="icon-headphones"></i> Miami, FL Office | 1-786-975-2146</a></li>
			    	<li><a href="tel:19544824464" rel="external" title="Click to call."><i class="icon-headphones"></i> Ft. Lauderdale, FL Office | 1-954-482-4464</a></li>
			    	<li><a href="tel:14169001260" rel="external" title="Click to call."><i class="icon-headphones"></i> Toronto, Ontario Canada | 1-416-900-1260</a></li>
			    	<li class="divider"></li>
			    	<li><a href="tel:+4402030516419" rel="external" title="Click to call."><i class="icon-headphones"></i> London | +44 020-3051-6419</a></li>
			    	<li class="divider"></li>
			    	<li><a href="tel:+551232125101" rel="external" title="Click to call."><i class="icon-headphones"></i> S�o Paulo | +55 12-3212-5101</a></li>
			    </ul>
			</div>
			
			<!-- Social -->
			
			<div class="btn-group pull-right header-bar-social">
				<p>
				<a href="http://www.facebook.com/pages/My-Live-Tech/224274488659" title="Follow Live-Tech on Facebook." target="_blank" rel="nofollow"> <img src="<?php bloginfo('template_url'); ?>/img/facebook-24.png" alt="Facebook" /> </a>
				<a href="https://plus.google.com/u/0/b/112659795564637259745/112659795564637259745" title="Follow Live-Tech on Google+." target="_blank" rel="nofollow"> <img src="<?php bloginfo('template_url'); ?>/img/googleplus-24.png" alt="Google+" /> </a>
				<a href="http://www.twitter.com/mylivetech" title="Follow Live-Tech on Twitter." target="_blank" rel="nofollow"> <img src="<?php bloginfo('template_url'); ?>/img/twitter-24.png" alt="Twitter" /> </a>
				<a href="https://www.youtube.com/user/livetech2006" title="Watch Live-Tech Videos on YouTube." target="_blank" rel="nofollow"> <img src="<?php bloginfo('template_url'); ?>/img/youtube-24.png" alt="YouTube" /> </a>
				<a href="http://www.linkedin.com/companies/live-tech" title="Follow Live-Tech on LinkedIn." target="_blank" rel="nofollow"> <img src="<?php bloginfo('template_url'); ?>/img/linkedin-24.png" alt="LinkedIn" /> </a>
				<a href="http://pinterest.com/frankzabroski/live-tech/" title="Follow Live-Tech on Pinterest." target="_blank" rel="nofollow"> <img src="<?php bloginfo('template_url'); ?>/img/pinterest-24.png" alt="Pinterest" /> </a>
				<a href="http://support.mylive-tech.com/rss/index.php?_m=news&amp;_a=view&amp;group=supportsuite" title="Subscribe to Live-Tech's RSS Feed." target="_blank" rel="nofollow"> <img src="<?php bloginfo('template_url'); ?>/img/rss-24.png" alt="RSS" /> </a>
				</p>
			</div>
		
		</div>
		
		<!-- Global Navigation -->
		
		<div class="container-fluid global-navigation">
			
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
            	<span class="icon-bar"></span>
            	<span class="icon-bar"></span>
            	<span class="icon-bar"></span>
          	</a>
			
			<div class="nav-collapse">
            <ul class="nav">
				<li class="active"><a href="<?php echo site_url(); ?>" title="Go to the homepage."><i class="icon-home"></i></a></li>
				<li class="dropdown active"> 
					<a class="dropdown-toggle" id="dLabel" role="button" data-toggle="dropdown" data-target="#" href="#">Support Plans<b class="caret"></b></a>  
					<ul class="dropdown-menu">  
						<li><a href="">RIS | Online Home Computer Repair Plans</a></li>  
						<li><a href="">BIS | Business Support Plans</a></li>
						<li><a href="">FortiVoice & TalkSwitch PBX Support Plans</a></li>
					</ul>  
				</li>
				<li class="dropdown active">
					<a class="dropdown-toggle" id="dLabel" role="button" data-toggle="dropdown" data-target="#" href="#">FortiVoice<b class="caret"></b></a>  
					<ul class="dropdown-menu">  
						<li><a href="">Starter Bundles</a></li>
						<li><a href="">FortiVoice PBX Systems</a></li>
						<li><a href="">FortiVoice IP Phones</a></li>
						<li><a href="">FortiVoice IP Cordless</a></li>
						<li><a href="">FortiFone Analog Phones</a></li>
						<li><a href="">FortiVoice & Phone Addons</a></li>
						<li><a href="">FortiVoice Support Plans</a></li>
						<li><a href="">FortiVoice Installation</a></li>
						<li><a href="">FortiVoice Software</a></li>
						<li><a href="">FortiVoice Accessories</a></li>
						<li><a href="">Custom Recordings</a></li>
						<li><a href="">LynkVoIP Service for FortiVoice</a></li>
					</ul>  
				</li>
				<li class="dropdown active"> 
					<a class="dropdown-toggle" id="dLabel" role="button" data-toggle="dropdown" data-target="#" href="#">Lynk VoIP<b class="caret"></b></a>  
					<ul class="dropdown-menu">  
						<li><a href="">US / Canada Flat Rate Calling Plans</a></li>
						<li><a href="">UK Flat Rate Calling Plans</a></li>
						<li><a href="">Per Minute Calling Plans</a></li>
						<li><a href="">Multi-Country Calling Plans</a></li>
						<li><a href="">High Volume & Call Center Plans</a></li>
						<li><a href="">NOC Management</a></li>
					</ul>  
				</li>
				<li class="dropdown active"> 
					<a class="dropdown-toggle" id="dLabel" role="button" data-toggle="dropdown" data-target="#" href="#">Cloud Services<b class="caret"></b></a>  
					<ul class="dropdown-menu">  
						<li><a href="">Custom Cloud Servers</a></li>
						<li><a href="">Onsite, Offsite, Cloud Backup Solutions</a></li>
						<li><a href="">Live-Tech Hosted Microsoft Exchange 2010</a></li>
						<li><a href="">Live-Tech Hosted Microsoft SharePoint 2010</a></li>
						<li><a href="">Live-Tech Hosted Microsoft Exchange 2013</a></li>
						<li><a href="">Live-Tech Hosted Microsoft SharePoint 2013</a></li>
						<li><a href="">SkyWorker 2010</a></li>
						<li><a href="">SkyWorker 2013 (coming soon)</a></li>
						<li><a href="">SkyNox</a></li>
					</ul>  
				</li>
				<!-- <li class="active"><a href="#">Business Solutions</a></li> -->
				<li class="dropdown active"> 
					<a class="dropdown-toggle" id="dLabel" role="button" data-toggle="dropdown" data-target="#" href="#">Business Solutions<b class="caret"></b></a>  
					<ul class="dropdown-menu">  
						<li><a href="">Help Desk Services</a></li>
						<li><a href="">Project Management</a></li>
						<li><a href="">Office Out of the Box</a></li>
						<li><a href="">PBX Consultation & Management</a></li>
						<li><a href="">Technology Refresh & Migration Services</a></li>
						<li><a href="">Zippy Fax - eFax Solutions</a></li>
					</ul>  
				</li>
				<li class="dropdown active"> 
					<a class="dropdown-toggle" id="dLabel" role="button" data-toggle="dropdown" data-target="#" href="#">Web Solutions<b class="caret"></b></a>  
					<ul class="dropdown-menu">  
						<li><a href="">Branding & Identity Creation</a></li>
						<li><a href="">WordPress Development</a></li>
						<li><a href="">Custom Development</a></li>
						<li><a href="">SharePoint Development</a></li>
						<li><a href="">Shared Hosting</a></li>
						<li><a href="">VPS Hosting</a></li>
						<li><a href="">Dedicated Hosting</a></li>
						<li><a href="">Cloud VPS Hosting</a></li>
						<li><a href="">Cloud Dedicated Hosting</a></li>
						<li><a href="">Portfolio</a></li>
					</ul>  
				</li>
				<li class="dropdown active"> 
					<a class="dropdown-toggle" id="dLabel" role="button" data-toggle="dropdown" data-target="#" href="#">Shop Live-Tech<b class="caret"></b></a>  
					<ul class="dropdown-menu">  
						<li><a href="">PC Support</a></li>
						<li><a href="">MAC Support</a></li>
						<li><a href="">Remote Support</a></li>
						<li><a href="">Online Support</a></li>
						<li><a href="">FortiVoice Products</a></li>
						<li><a href="">Lynk VoIP</a></li>
						<li><a href="">Advanced SystemCare</a></li>
						<li><a href="">Software</a></li>
						<li><a href="">Hardware</a></li>
						<li><a href="">Web Services</a></li>
						<li><a href="">Cloud Services</a></li>
						<li><a href="">Data Vault</a></li>
						<!-- <li><a href="">Security Cameras & DVR Systems</a></li> -->
					</ul>  
				</li>
				<li class="dropdown active"> 
					<a class="dropdown-toggle" id="dLabel" role="button" data-toggle="dropdown" data-target="#" href="#">Resources<b class="caret"></b></a>  
					<ul class="dropdown-menu">  
						<li><a href="">Knowledge Base</a></li>
						<li><a href="">FAQs</a></li>
						<li><a href="">Legal</a></li>
						<li><a href="">Press</a></li>
					</ul>  
				</li>
				<!--
				<li class="dropdown active"> 
					<a class="dropdown-toggle" id="dLabel" role="button" data-toggle="dropdown" data-target="#" href="#">About<b class="caret"></b></a>  
					<ul class="dropdown-menu">  
						<li><a href="">Management Team</a></li>
						<li><a href="">Our Vision</a></li>
						<li><a href="">Our Culture</a></li>
						<li><a href="">Partners</a></li>
						<li><a href="">In the News</a></li>
						<li><a href="">Careers</a></li>
					</ul>  
				</li>
				-->
				<li class="dropdown active"> 
					<a class="dropdown-toggle" id="dLabel" role="button" data-toggle="dropdown" data-target="#" href="#">Contact<b class="caret"></b></a>  
					<ul class="dropdown-menu">  
						<li><a href="">Contact us Online</a></li>
						<li><a href="">Refer a Partner</a></li>
						<li><a href="">Refer an Affiliate</a></li>
						<li><a href="">Refer a Friend Program</a></li>
						<li><a href="">Become a Reseller</a></li>
					</ul>  
				</li>
			</ul> 	
			</div>

		</div>
		
	</div>
	
<!-- CONTAINER -->
<div class="container" style="margin-bottom: 25px;">
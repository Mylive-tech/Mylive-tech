			</div> <!-- end #container -->
            
            <div class="livesupport">
        <!-- Begin SupportSuite Javascript Code -->
<script src="http://support.mylive-tech.com/visitor/index.php?_m=livesupport&_a=htmlcode&departmentid=0" type="text/javascript"></script><!-- End SupportSuite Javascript Code -->
</div>
            
            <footer role="contentinfo" id="lt-footer">
			
				<div id="inner-footer" class="clearfix">
		         
		          <div id="widget-footer" class="clearfix row-fluid">
		            <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer1') ) : ?>
		            <?php endif; ?>
		            <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer2') ) : ?>
		            <?php endif; ?>
		            <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer3') ) : ?>
		            <?php endif; ?>
		          </div>
					
					<nav class="clearfix">
						<?php bones_footer_links(); // Adjust using Menus in Wordpress Admin ?>
					</nav>
							
					<p class="attribution">&copy; <?php bloginfo('name'); ?>, All Rights Reserved. </p>
				
				</div> <!-- end #inner-footer -->
				
			</footer> <!-- end footer -->
		
		
				
		<!--[if lt IE 7 ]>
  			<script src="//ajax.googleapis.com/ajax/libs/chrome-frame/1.0.3/CFInstall.min.js"></script>
  			<script>window.attachEvent('onload',function(){CFInstall.check({mode:'overlay'})})</script>
		<![endif]-->
		
		<?php wp_footer(); // js scripts are inserted using this function ?>
        <!--
        <script>
		    $('.post_content .flip').click(function(){
        $(this).find('.card').addClass('flipped').mouseleave(function(){
            $(this).removeClass('flipped');
        });
        return false;
    });
		</script>
        -->
        </div>

	</body>

</html>
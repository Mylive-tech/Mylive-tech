$('.btn-expanding').find('.click').click(function(e) {  
  $(this).parent().toggleClass('opened');
});
<?php

/*

Template Name: Home Page

*/

?>



<?php get_header(); ?>

<div class="ltclearfix"></div>

<?php echo do_shortcode('[new_royalslider id="1"]'); ?>
        
        <div class="ltclearfix"></div>



		<!-- LEADERBOARD

		<h4 class="leader-quality"> 

			Professional. Responsive. Reliable. <span>All 100% guaranteed.</span> 

		</h4>



		<div class="row">  

		<div class="span home-intro">  

			<div class="box-inset">

			<p>Live-Tech is a pioneer company with a new approach to  Computer &amp; Technology needs. We care about you &amp; work diligently to  solve all your technical concerns. You have found the experts of Technical  Support. </p>

			<p>Our team is built of highly skilled professionals with over 20 years  of IT experience &amp; use the most advanced methods and technologies to assure  your IT issues are resolved.</p>

			<p>98% of all Technical Support problems are fully resolved  remotely. No Hidden Fees &amp; Live Technical Support 24/7/365. Live-Tech's  mission is always 100% customer satisfaction.</p>

			<p>Call Live-Tech Today &amp; leave IT Management to the experts.

			  </p>

			</div>

		</div>



		<div class="span home-quick-contact">

			<div class="box-inset">

				<div class="home-call">

				<p> Say hello. We'd be glad to help. </p>

				<p><a class="btn btn-warning btn-small" href="#" onclick="window.open('http://support.mylive-tech.com/visitor/index.php?_m=livesupport&_a=startclientchat&sessionid=yrph78uldkjpq9mkvf3jwaeca5hghb5p&proactive=0&departmentid=0&randno=19&fullname=&email=', 'newwindow', 'width=500, height=350'); return false;" title="Chat Now with a Live-Tech Agent"><i class="icon-comment"></i> Live Chat with Support</a></p>

				<p><a class="btn btn-warning btn-small" href="#" onclick="window.open('http://doodle.com/livetech', 'newwindow', 'width=500, height=350', 'scrollbar=yes'); return false;" title="Schedule an Online Meetup"><i class="icon-headphones"></i> Schedule an Online Meetup</a></p>

				</div>



				<hr>



				<div class="home-biz">

				<p> Join our growing network. Let's walk together. </p>

				<p><a class="btn btn-danger btn-small"><i class="icon-heart"></i> Refer a Friend Program</a></p>

				<p><a class="btn btn-danger btn-small" href="<?php bloginfo('url'); ?>/become-live-tech-reseller/"><i class="icon-refresh"></i> Become a Reseller</a></p>

				</div>

			</div>

		</div>

		</div>
 -->
		

		<!-- THUMBNAILS -->

		<h3 class="home-section-head">

			<span>

				<img src="http://icons.iconarchive.com/icons/deleket/soft-scraps/16/Briefcase-icon.png"/>

				SERVICES

			</span> 

			<br />

			Here’s everything we offer you, bit to bytes. 

		</h3>



		<ul class="thumbnails">

		    <li class="span3">

		    	<div class="thumbnail">

			    	<img src="<?php bloginfo('template_url'); ?>/images/ris-home-computer-repair.jpg" data-src="holder.js/300x200" alt="RIS | Online Home Computer Repair &amp; Assistance ">

			    	<div class="caption">

			    	<h4>  Home Computer <br />

			    	  Repair & Assistance </h4>

			    	<p>Professional Comptuer Support &amp; Installation Services for all your home needs. From basic repair to advanced help Live-Tech has the complicated covered.			    	</p>

			    	<p>

			    		<a href="<?php bloginfo('url'); ?>/online-home-computer-repair-plans/remote-phone-support-computers/" class="btn btn-primary">Get Started Now! <br> Choose Your Plan</a>

			    		<a href="<?php bloginfo('url'); ?>/frequently-asked-questions" class="btn btn-mini">F.A.Q.</a>

			    	</p>

			    	</div>

		    	</div>

		    </li>



		    <li class="span3">

		    	<div class="thumbnail">

			    	<img src="<?php bloginfo('template_url'); ?>/images/bis-business-it-support.jpg" data-src="holder.js/300x200" alt="BIS | Business Computer Support &amp; Assistance ">

			    	<div class="caption">

			    	<h4> Business Computer <br />

			    	  Support & Assistance </h4>

			    	<p>Professional Comptuer Support &amp; Installation Services for all your business needs. From basic repair to advanced help Live-Tech has the complicated covered. </p>

			    	<p>

			    		<a href="<?php bloginfo('url'); ?>/bis-get-help-work/bis-compare-support-plans-choices/" class="btn btn-primary">Get Started Now! <br> Choose Your Plan</a>

			    		<a href="<?php bloginfo('url'); ?>/bis-get-help-work/bis-compare-support-plans-choices/" class="btn btn-mini">Custom Services</a>
			    	</p>

			    	</div>

		    	</div>

		    </li>



		    <li class="span3">

		    	<div class="thumbnail">

			    	<img src="<?php bloginfo('template_url'); ?>/images/cloud-hosting-services.jpg" data-src="holder.js/300x200" alt="Cloud Hosting &amp; Services ">

			    	<div class="caption">

			    	<h4> Cloud Hosting & Cloud Services </h4>

			    	<p>Live-Tech takes advantage of the latest cloud technolgies. Offering a very wide array of servers (Premade or Custom), app hosting, &amp; custom cloud services.</p>

			    	<p>

			    		<a hre="" class="btn btn-mini">Details</a>

			    		<a hre="" class="btn btn-mini">Compare Plans</a>

			    	</p>

			    	</div>

		    	</div>

		    </li>



		    <li class="span3">

		    	<div class="thumbnail">

			    	<img src="<?php bloginfo('template_url'); ?>/images/home-business-voip-phone-service.jpg" alt="Home / Business VoIP Phone Service" width="300" height="100" data-src="holder.js/300x200">

			    	<div class="caption">

			    	<h4> Home / Business VoIP Phone Service </h4>

			    	<p> Live-Tech offers outstanding phone service, unlimited calling plans, professional Live-Tech support with 100% satisfaction; whenever you need it the most.</p>

			    	<p>

			    		<a hre="" class="btn btn-mini">Details</a>

			    		<a hre="" class="btn btn-mini">Compare Plans</a>

			    	</p>

			    	</div>

		    	</div>

		    </li>

		</ul>



		

	<a name="consultationform"></a>

		<ul class="thumbnails">

		    <li class="span3">

		    	<div class="thumbnail">

			    	<img src="<?php bloginfo('template_url'); ?>/images/web-development-services.jpg" data-src="holder.js/300x200" alt="Website Development &amp; Custom Art Services ">

			    	<div class="caption">

			    	<h4> Website Development & Custom Art Services </h4>

			    	<p>Live-Tech has professional web designers, artists and outstanding web site hosting plans that are customizable to your needs. </p>

			    	<p>

			    		<a hre="" class="btn btn-mini">Details</a>

			    		<a hre="" class="btn btn-mini">Compare Plans</a>

			    	</p>

			    	</div>

		    	</div>

		    </li>



		    <li class="span3">

		    	<div class="thumbnail">

			    	<img src="<?php bloginfo('template_url'); ?>/images/networking-and-hardware-solutions.jpg" data-src="holder.js/300x200" alt="Networking / Hardware Solutions &amp; Support ">

			    	<div class="caption">

			    	<h4> Networking / Hardware Solutions & Support </h4>

			    	<p>Live-Tech offers customizable Networking solutions and professional Tech support to keep your business running in high gear. </p>

			    	<p>

			    		<a hre="" class="btn btn-mini">Details</a>

			    		<a hre="" class="btn btn-mini">Compare Plans</a>

			    	</p>

		    	</div>

	    	</div>

	    </li>



		    <li class="span3">

		    	<div class="thumbnail">

			    	<img src="<?php bloginfo('template_url'); ?>/images/cloud-backup-solutions.jpg" data-src="holder.js/300x200" alt="Onsite, Offsite, and Cloud Backup Solutions ">

			    	<div class="caption">

			    	<h4> Onsite, Offsite, and Cloud Backup Solutions </h4>

			    	<p> Live-Tech will create your perfect data backup solutions tailored to your particular home or business needs and demands. </p>

			    	<p>

			    		<a hre="" class="btn btn-mini">Details</a>

			    		<a hre="" class="btn btn-mini">Compare Plans</a>

			    	</p>

		    	</div>

	    	</div>

	    </li>



	    <li class="span3">

		    	<div class="thumbnail">

		    	<img src="<?php bloginfo('template_url'); ?>/images/lt-tech-shop.jpg" alt="Hardware &amp; Software Shop ">

			    	<div class="caption">

			    	<h4> Hardware &amp; Software</h4>

			    	<p> Live-Tech offers variety of top-notch, optimized hardware &amp; the best production, security software in our tech shop to get your office running.</p>

			    	<p>

			    		<a hre="" class="btn btn-mini">Details</a>

			    		<a hre="" class="btn btn-mini">Compare Plans</a>

			    	</p>

		    	</div>

	    	</div>

	    </li>

	</ul>





<!-- Banner Ads -->

<div class="row">

 <div class="span12 home-product-slides">

			<?php echo do_shortcode('[products_carousel display="random"]'); ?>

            </div>

		<!-- <div class="home-promo span4">  

			<div>

			<img src="http://199.101.49.90/~mylive5/mylive-tech.com/media/banner-lt-gen-336x280-02.png" width="336" height="281"/>

			</div>  

		</div>



		<div class="home-promo span4">  

			<div>

			<img src="http://199.101.49.90/~mylive5/mylive-tech.com/media/lt-skyworker300x150-01.png" width="300" height="150" alt="">

	      </div>  

          <div>

			Ad 3

	      </div>  

	</div>

		<div class="span4">  

			<div>

             

			</div>  

		</div> -->

	</div>





		<!-- CONSULTATION FORM -->

		<div class="row">

		<div class="span12 quickconsult thumbnail">

        <?php wp_reset_query(); ?>

			<?php echo do_shortcode("[easy_contact_forms fid=3]"); ?>

		</div>

	</div>







		

		<!-- TECHNICAL SERVICES -->

		<h3 class="home-section-head">

			<span>

				<img src="http://icons.iconarchive.com/icons/deleket/soft-scraps/16/Gear-icon.png" style="top: -2px; position: relative;" />

				TECHNICAL SERVICES

			</span> 

			<br />

			We offer services across a plethora of industries. 

		</h3>





	<div class="row">  

		<div class="span2">  

			<div class="box-inset serv-industry">

			<h3 class="tech-services">Technical services for<br /><span>Health Care</span></h3>

			<p> The computer doctors at Live-Tech offer expert IT services &amp; support for medical offices &amp; facilities. We are ‘on-call’ 24/7/365.</p>

            <p><a href="#" class="btn btn-mini">Read Details</a></p>

			</div>  

		</div>



		<div class="span2">

			<div class="box-inset serv-industry">

			<h3 class="tech-services">Technical services for<br /><span>Taxation &amp; Finance</span></h3>

			<p> Live-Tech will securely protect all your tax &amp; financial information, keep  your  office running smoothly 24/7/365.</p>

            <p><a href="#" class="btn btn-mini">Read Details</a></p>

			</div>  

		</div>



		<div class="span2">

			<div class="box-inset serv-industry">

			<h3 class="tech-services">Technical services for<br /><span>Travel &amp; Mobility</span></h3>

			<p> With Live-Tech, even when you're travelling; we help keep your data protected &amp; all issues quickly resolved 24/7/365.</p>

            <p><a href="#" class="btn btn-mini">Read Details</a></p>

			</div>  

		</div>



		<div class="span2">

			<div class="box-inset serv-industry">

			<h3 class="tech-services">Technical services for<br /><span>NOC Management</span></h3>

			<p> Our Network Operation Center is proficient in VoIP service &amp; network monitoring with superb Level 3 IT Techs.</p>

            <p><a href="#" class="btn btn-mini">Read Details</a></p>

			</div>  

		</div>
        
        
        <!-- testi new-->
        
        <h3 class="home-section-head">
			<span>
				<img src="http://icons.iconarchive.com/icons/oxygen-icons.org/oxygen/16/Actions-rating-icon.png"/>
				<img src="http://icons.iconarchive.com/icons/oxygen-icons.org/oxygen/16/Actions-rating-icon.png"/>
				<img src="http://icons.iconarchive.com/icons/oxygen-icons.org/oxygen/16/Actions-rating-icon.png"/>
				TESTIMONIALS
				<img src="http://icons.iconarchive.com/icons/oxygen-icons.org/oxygen/16/Actions-rating-icon.png"/>
			<img src="http://icons.iconarchive.com/icons/oxygen-icons.org/oxygen/16/Actions-rating-icon.png"/>
			<img src="http://icons.iconarchive.com/icons/oxygen-icons.org/oxygen/16/Actions-rating-icon.png"/>
			</span> 
		</h3>

		<div class="home-testimonial smaller span4">  

			<div>

			<p>&ldquo;This was my first experience with Live Tech and I was absolutely amazed with their excellent performance!...&quot;<br />
 <a href="<?php bloginfo('url'); ?>/live-tech/testimonials/" title="Read more client testimonials" rel="bookmark">(Read more)</a></p>
</div>  
		</div>

		<div class="home-testimonial span4">  
			<div>
			<p>“Our first great experience with Live-Tech was getting our &quot;TalkSwitch Phone System&quot; all set up and customized... &quot; <br />
<a href="<?php bloginfo('url'); ?>/live-tech/testimonials/" title="Read more client testimonials" rel="bookmark">(Read more)</a></p>

	      </div>  

	</div>

	</div>



		

		<!-- TESTIMONIALS -->

		<h3 class="home-section-head">

			<span>

				<img src="http://icons.iconarchive.com/icons/oxygen-icons.org/oxygen/16/Actions-rating-icon.png"/>

				<img src="http://icons.iconarchive.com/icons/oxygen-icons.org/oxygen/16/Actions-rating-icon.png"/>

				<img src="http://icons.iconarchive.com/icons/oxygen-icons.org/oxygen/16/Actions-rating-icon.png"/>



				TESTIMONIALS

				<img src="http://icons.iconarchive.com/icons/oxygen-icons.org/oxygen/16/Actions-rating-icon.png"/>

				<img src="http://icons.iconarchive.com/icons/oxygen-icons.org/oxygen/16/Actions-rating-icon.png"/>

				<img src="http://icons.iconarchive.com/icons/oxygen-icons.org/oxygen/16/Actions-rating-icon.png"/>

			</span> 

			<br /> 

			We always listen to what our customers have to say. Very carefully. 

		</h3>



		<div class="row">

		<div class="home-testimonial smaller span4">  

			<div>

			<p>&ldquo;This was my first experience with Live Tech and I was absolutely amazed   with their excellent performance! I had a really nasty virus and other   computer issues. Frank worked with me for a long period of time to   resolve my issues. I have worked with other Techs previously, but none   were as dedicated an competent as Frank. These guys don't stop until the   issues are resolved. I recommend this team to anyone wanting superior   results.   &quot;<br />

				--<strong>Dale Price</strong> <a href="<?php bloginfo('url'); ?>/live-tech/testimonials/" title="Read more client testimonials" rel="bookmark">(Read more)</a></p>

			</div>  

		</div>



		<div class="home-testimonial span4">  

			<div>

			<p>“Our first great experience with Live-Tech was getting our &quot;TalkSwitch Phone System&quot; all set up and customized for our busy veterinary hospital.....100% Success. So now I decided to try Live-Tech IT Support Remote service with a PC problem on a brand new personal desktop. The new machine was &quot;locking up&quot; completely at random. Take it back?....well, we had already spent considerable time getting programs, data, email, etc. all transferred and set-up... Ludy Chacon was able to find the problem way down deep in the bowels of the operating system... 30 hours later PC is still running great and no longer freezing up! Thank You MY Live-Tech!!!!&quot; <br />

-- <strong>Jerry A Foster </strong> <a href="<?php bloginfo('url'); ?>/live-tech/testimonials/" title="Read more client testimonials" rel="bookmark">(Read more)</a></p>

	      </div>  

	</div>

		<div class="home-testimonial smaller span4">  

			<div>

			<p> 

				“Live-Tech Jeremy has been helping us for over a week. He is very caring, competent, and attentive. Without Live-Tech support, we would still be trying to work on two computers versus seven. The ATX software technical support has been horrible. I am so thankful for Jeremy. He has been a lifesaver to us. He is so patient and knows exactly what to do to fix the situation. Thank you, Live-Tech. You are a Godsend." 

				<br />

			-- <strong>Sherri Owen-Calaway, C.P.A.</strong> <a href="<?php bloginfo('url'); ?>/live-tech/testimonials/" title="Read more client testimonials" rel="bookmark">(Read more)</a></p>

			</div>  

		</div>

	</div>



		<!-- SUPPORT ACTIONS -->

		<!--		

		<div class="row" style="margin-bottom: 25px;">

		<div class="span2" style="background-color: #93CBF0; text-align: center;">

			<div style="padding: 15px 5px;">

			<p style="margin-bottom: 0;"> Live Chat with Support </p>

			</div>

		</div>

		<div class="span2" style="background-color: #F0B593; text-align: center;">

			<div style="padding: 15px 5px;">

			<p style="margin-bottom: 0;"> Start a Remote Session </p>

			</div>

		</div>

		<div class="span2" style="background-color: #C892F0; text-align: center;">

			<div style="padding: 15px 5px;">

			<p style="margin-bottom: 0;"> Submit a Ticket </p>

			</div>

		</div>

		<div class="span2" style="background-color: #F89DC6; text-align: center;">

			<div style="padding: 15px 5px;">

			<p style="margin-bottom: 0;"> Support Suite </p>

			</div>

		</div>

		<div class="span2" style="background-color: #AAE690; text-align: center;">

			<div style="padding: 15px 5px;">

			<p style="margin-bottom: 0;"> Read Knowledge Base </p>

			</div>

		</div>



		<div class="span2" style="background-color: #F3E7B0; text-align: center;">

			<div style="padding: 15px 5px;">

			<p style="margin-bottom: 0;"> Get Free Consultation </p>

			</div>

		</div>

	</div>

	-->



		<!-- TABLE -->

		<!--

		<div class="row" style="margin-bottom: 25px;">  

		<div class="span12" style="background-color: #F0F0F0;">

			<table class="table table-striped">  

	        <thead>  

	          <tr>  

	            <th>Student-ID</th>  

	            <th>First Name</th>  

	            <th>Last Name</th>  

	            <th>Grade</th>  

	          </tr>  

	        </thead>  

        <tbody>  

        <tr>  

           <td>001</td>  

	            <td>Rammohan </td>  

	            <td>Reddy</td>  

	            <td>A+</td>  

	          </tr>  

	          <tr>  

	            <td>002</td>  

	            <td>Smita</td>  

	            <td>Pallod</td>  

	            <td>A</td>  

	          </tr>  

	          <tr>  

	            <td>003</td>  

	            <td>Rabindranath</td>  

	            <td>Sen</td>  

	            <td>A+</td>  

	          </tr>  

	        </tbody>  

	      </table>  

		</div>

	</div>

-->



</div>



<div class="row">

 <section id="lt-share">

                        <span class='st_fblike_hcount' displayText='Facebook Like'></span>

<span class='st_facebook_hcount' displayText='Facebook'></span>

<span class='st_googleplus_hcount' displayText='Google +'></span>

<span class='st_twitter_hcount' displayText='Tweet'></span>

<span class='st_linkedin_hcount' displayText='LinkedIn'></span>

<span class='st_pinterest_hcount' displayText='Pinterest'></span>

<span class='st_email_hcount' displayText='Email'></span>

<span class='st_sharethis_hcount' displayText='ShareThis'></span>

</section></div>



<?php get_footer(); ?>
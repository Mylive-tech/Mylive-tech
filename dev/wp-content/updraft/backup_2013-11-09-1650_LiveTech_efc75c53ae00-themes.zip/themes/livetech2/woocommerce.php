<?php get_header(); ?>
			
			<div id="content" class="clearfix row-fluid">
            			
				<div id="main" class="span8 clearfix" role="main">
                
                 <?php if ( function_exists('yoast_breadcrumb') ) {
yoast_breadcrumb('<p id="breadcrumbs">','</p>');
} ?>

					<?php woocommerce_content(); ?>
			
				</div> <!-- end #main -->
    
				<?php get_sidebar(); // sidebar 1 ?>
    
			</div> <!-- end #content -->

<?php get_footer(); ?>
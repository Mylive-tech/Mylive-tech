﻿<!doctype html>  



<!--[if IEMobile 7 ]> <html <?php language_attributes(); ?>class="no-js iem7"> <![endif]-->

<!--[if lt IE 7 ]> <html <?php language_attributes(); ?> class="no-js ie6"> <![endif]-->

<!--[if IE 7 ]>    <html <?php language_attributes(); ?> class="no-js ie7"> <![endif]-->

<!--[if IE 8 ]>    <html <?php language_attributes(); ?> class="no-js ie8"> <![endif]-->

<!--[if (gte IE 9)|(gt IEMobile 7)|!(IEMobile)|!(IE)]><!--><html <?php language_attributes(); ?> class="no-js"><!--<![endif]-->

	

	<head> 

		<meta charset="utf-8">

		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

		

		<title><?php wp_title( '|', true, 'right' ); ?></title>

				

		<meta name="viewport" content="width=device-width, initial-scale=1.0">

				

		<!-- media-queries.js (fallback) -->

		<!--[if lt IE 9]>

			<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>			

		<![endif]-->



		<!-- html5.js -->

		<!--[if lt IE 9]>

			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>

		<![endif]-->

		

  		<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">



		<!-- wordpress head functions -->

		<?php wp_head(); ?>

		<!-- end of wordpress head -->



		<!-- theme options from options panel -->

		<?php get_wpbs_theme_options(); ?>



		<!-- typeahead plugin - if top nav search bar enabled -->

		<?php require_once('library/typeahead.php'); ?>

        

        <!-- Google Analytics 

    <script>

 /* (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){

  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),

  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)

  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');



  ga('create', 'UA-31521160-7', 'mylive-tech.com');

  ga('send', 'pageview');*/



</script>-->



<script>

// this is just a short jQuery thing to add, replace and remove classes to the parent elem.



$('.btn-expanding').find('.click').click(function(e) {  

  $(this).parent().toggleClass('opened');

});

</script>

				

	</head>

	

	<body <?php body_class(); ?>>

				

		<header role="banner">

		

			<div id="inner-header" class="clearfix">

				<div class="navbar navbar-fixed-top">

                

                <!-- Support Buttons -->

             <!--<div id="support-sliders">

    <div>

      

      <div class="container support-action-calls">	

		<div class="row">

		<div class="span2">

			<a class="btn btn-warning btn-sup-action livechat" href="" onclick="window.open('http://support.mylive-tech.com/visitor/index.php?_m=livesupport&_a=startclientchat&sessionid=yrph78uldkjpq9mkvf3jwaeca5hghb5p&proactive=0&departmentid=0&randno=19&fullname=&email=', 'newwindow', 'width=500, height=350'); return false;" title="Chat now with a Live-Tech agent."><i class="icon-comment"></i> Live Chat with Support</a>

		</div>

		<div class="span2">

			<a class="btn btn-warning btn-sup-action remotesession" href="http://www.mylive-tech.com/connect.html" title="Start a remote session." target="_blank"><i class="icon-globe"></i> Start Remote Session</a>

		</div>

		<div class="span2">

			<a class="btn btn-warning btn-sup-action ticketsubmit" href="http://support.mylive-tech.com/index.php?_m=tickets&_a=submit" title="Submit a new ticket." target="_blank"><i class="icon-list-alt"></i> Submit a Ticket</a>

		</div>

		<div class="span2">

			<a class="btn btn-warning btn-sup-action suite" href="http://support.mylive-tech.com/" title="Go to the Support Suite." target="_blank"><i class="icon-briefcase"></i> Support Suite</a>

		</div>

		<div class="span2">

			<a class="btn btn-warning btn-sup-action kb" href="http://support.mylive-tech.com/index.php?_m=knowledgebase&_a=view" title="Read our Knowledge Base." target="_blank"><i class="icon-book"></i> Read Knowledge Base</a>

		</div>

		<div class="span2">

			<a class="btn btn-warning btn-sup-action consult" href="#consultationform" title="Get genuine consultation."><i class="icon-ok-circle"></i> Get Consultation</a>

		</div>

		</div>

		

      </div>

     

    </div>

  </div>-->

  

                

<div class="navbar-inner">

                    

                     <!-- Support Buttons -->

   

   <div class="container-fluid nav-container">

			<!-- Logo -->

			<a href="<?php echo site_url(); ?>" title="Welcome to Live-Tech.">

			<div class="pull-left header-bar-logo">

			<strong><?php bloginfo( 'name' ); ?></strong> <span><?php bloginfo( 'description' ); ?></span>

			</div></a> 

			

			<!-- SVG Action Buttons -->

			<div class="responsive-icons">

				<ul>

				 <li>

				 	<a href="#" onclick="window.open('http://support.mylive-tech.com/visitor/index.php?_m=livesupport&_a=startclientchat&sessionid=yrph78uldkjpq9mkvf3jwaeca5hghb5p&proactive=0&departmentid=0&randno=19&fullname=&email=', 'newwindow', 'width=500, height=350'); return false;" title="Chat Now with a Live-Tech Agent">

				 		<img alt="" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjwhLS0gQ3JlYXRlZCB3aXRoIElua3NjYXBlIChodHRwOi8vd3d3Lmlua3NjYXBlLm9yZy8pIC0tPgoKPHN2ZwogICB4bWxuczpvc2I9Imh0dHA6Ly93d3cub3BlbnN3YXRjaGJvb2sub3JnL3VyaS8yMDA5L29zYiIKICAgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIgogICB4bWxuczpjYz0iaHR0cDovL2NyZWF0aXZlY29tbW9ucy5vcmcvbnMjIgogICB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiCiAgIHhtbG5zOnN2Zz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciCiAgIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiCiAgIHhtbG5zOnNvZGlwb2RpPSJodHRwOi8vc29kaXBvZGkuc291cmNlZm9yZ2UubmV0L0RURC9zb2RpcG9kaS0wLmR0ZCIKICAgeG1sbnM6aW5rc2NhcGU9Imh0dHA6Ly93d3cuaW5rc2NhcGUub3JnL25hbWVzcGFjZXMvaW5rc2NhcGUiCiAgIHNvZGlwb2RpOmRvY25hbWU9ImxpdmUtY2hhdC1pY29uLWJ3LnN2ZyIKICAgaW5rc2NhcGU6dmVyc2lvbj0iMC40OC40IHI5OTM5IgogICB2ZXJzaW9uPSIxLjEiCiAgIGlkPSJsaXZlLWNoYXQiCiAgIGhlaWdodD0iODAiCiAgIHdpZHRoPSI4MCI+CiAgPGRlZnMKICAgICBpZD0iZGVmczQzNjIiPgogICAgPGxpbmVhckdyYWRpZW50CiAgICAgICBpZD0ibGluZWFyR3JhZGllbnQ0MjM5IgogICAgICAgb3NiOnBhaW50PSJzb2xpZCI+CiAgICAgIDxzdG9wCiAgICAgICAgIHN0eWxlPSJzdG9wLWNvbG9yOiNlNmU2ZTY7c3RvcC1vcGFjaXR5OjE7IgogICAgICAgICBvZmZzZXQ9IjAiCiAgICAgICAgIGlkPSJzdG9wNDI0MSIgLz4KICAgIDwvbGluZWFyR3JhZGllbnQ+CiAgICA8bGluZWFyR3JhZGllbnQKICAgICAgIGlkPSJsaW5lYXJHcmFkaWVudDQyMzMiCiAgICAgICBvc2I6cGFpbnQ9InNvbGlkIj4KICAgICAgPHN0b3AKICAgICAgICAgc3R5bGU9InN0b3AtY29sb3I6IzAwMDAwMDtzdG9wLW9wYWNpdHk6MTsiCiAgICAgICAgIG9mZnNldD0iMCIKICAgICAgICAgaWQ9InN0b3A0MjM1IiAvPgogICAgPC9saW5lYXJHcmFkaWVudD4KICAgIDxsaW5lYXJHcmFkaWVudAogICAgICAgaWQ9ImxpbmVhckdyYWRpZW50NDIyNyIKICAgICAgIG9zYjpwYWludD0ic29saWQiPgogICAgICA8c3RvcAogICAgICAgICBzdHlsZT0ic3RvcC1jb2xvcjojMDAwMDAwO3N0b3Atb3BhY2l0eToxOyIKICAgICAgICAgb2Zmc2V0PSIwIgogICAgICAgICBpZD0ic3RvcDQyMjkiIC8+CiAgICA8L2xpbmVhckdyYWRpZW50PgogICAgPGxpbmVhckdyYWRpZW50CiAgICAgICBpbmtzY2FwZTpjb2xsZWN0PSJhbHdheXMiCiAgICAgICB4bGluazpocmVmPSIjbGluZWFyR3JhZGllbnQ0MjI3IgogICAgICAgaWQ9ImxpbmVhckdyYWRpZW50NDIzMSIKICAgICAgIHgxPSIxOS42MjgwMzMiCiAgICAgICB5MT0iOTk5LjY5NTI0IgogICAgICAgeDI9IjYxLjA2Mzk1MSIKICAgICAgIHkyPSI5OTkuNjk1MjQiCiAgICAgICBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgLz4KICAgIDxsaW5lYXJHcmFkaWVudAogICAgICAgaW5rc2NhcGU6Y29sbGVjdD0iYWx3YXlzIgogICAgICAgeGxpbms6aHJlZj0iI2xpbmVhckdyYWRpZW50NDIzMyIKICAgICAgIGlkPSJsaW5lYXJHcmFkaWVudDQyMzciCiAgICAgICB4MT0iMjQuMTI5MTY2IgogICAgICAgeTE9IjEwMzUuMTEyNCIKICAgICAgIHgyPSI1Ni4xNDE4NjEiCiAgICAgICB5Mj0iMTAzNS4xMTI0IgogICAgICAgZ3JhZGllbnRVbml0cz0idXNlclNwYWNlT25Vc2UiIC8+CiAgICA8bGluZWFyR3JhZGllbnQKICAgICAgIGlua3NjYXBlOmNvbGxlY3Q9ImFsd2F5cyIKICAgICAgIHhsaW5rOmhyZWY9IiNsaW5lYXJHcmFkaWVudDQyMzkiCiAgICAgICBpZD0ibGluZWFyR3JhZGllbnQ0MjQzIgogICAgICAgeDE9IjAiCiAgICAgICB5MT0iMTAxMi4zNjIyIgogICAgICAgeDI9IjgwIgogICAgICAgeTI9IjEwMTIuMzYyMiIKICAgICAgIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIiAvPgogIDwvZGVmcz4KICA8c29kaXBvZGk6bmFtZWR2aWV3CiAgICAgaWQ9ImJhc2UiCiAgICAgcGFnZWNvbG9yPSIjZmZmZmZmIgogICAgIGJvcmRlcmNvbG9yPSIjNjY2NjY2IgogICAgIGJvcmRlcm9wYWNpdHk9IjEuMCIKICAgICBpbmtzY2FwZTpwYWdlb3BhY2l0eT0iMC4wIgogICAgIGlua3NjYXBlOnBhZ2VzaGFkb3c9IjIiCiAgICAgaW5rc2NhcGU6em9vbT0iMiIKICAgICBpbmtzY2FwZTpjeD0iLTExLjQ4NzQyMSIKICAgICBpbmtzY2FwZTpjeT0iNDYuODU3MTQzIgogICAgIGlua3NjYXBlOmRvY3VtZW50LXVuaXRzPSJweCIKICAgICBpbmtzY2FwZTpjdXJyZW50LWxheWVyPSJsYXllcjEiCiAgICAgc2hvd2dyaWQ9ImZhbHNlIgogICAgIHNob3dib3JkZXI9InRydWUiCiAgICAgaW5rc2NhcGU6c2hvd3BhZ2VzaGFkb3c9ImZhbHNlIgogICAgIGlua3NjYXBlOndpbmRvdy13aWR0aD0iMTAxMSIKICAgICBpbmtzY2FwZTp3aW5kb3ctaGVpZ2h0PSI3OTEiCiAgICAgaW5rc2NhcGU6d2luZG93LXg9IjI4MyIKICAgICBpbmtzY2FwZTp3aW5kb3cteT0iNzEiCiAgICAgaW5rc2NhcGU6d2luZG93LW1heGltaXplZD0iMCIgLz4KICA8bWV0YWRhdGEKICAgICBpZD0ibWV0YWRhdGE0MzY1Ij4KICAgIDxyZGY6UkRGPgogICAgICA8Y2M6V29yawogICAgICAgICByZGY6YWJvdXQ9IiI+CiAgICAgICAgPGRjOmZvcm1hdD5pbWFnZS9zdmcreG1sPC9kYzpmb3JtYXQ+CiAgICAgICAgPGRjOnR5cGUKICAgICAgICAgICByZGY6cmVzb3VyY2U9Imh0dHA6Ly9wdXJsLm9yZy9kYy9kY21pdHlwZS9TdGlsbEltYWdlIiAvPgogICAgICAgIDxkYzp0aXRsZT48L2RjOnRpdGxlPgogICAgICA8L2NjOldvcms+CiAgICA8L3JkZjpSREY+CiAgPC9tZXRhZGF0YT4KICA8ZwogICAgIGlua3NjYXBlOmxhYmVsPSJMYXllciAxIgogICAgIGlua3NjYXBlOmdyb3VwbW9kZT0ibGF5ZXIiCiAgICAgaWQ9ImxheWVyMSIKICAgICB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwLC05NzIuMzYyMTgpIj4KICAgIDxyZWN0CiAgICAgICB5PSI5NzIuMzYyMTgiCiAgICAgICB4PSIwIgogICAgICAgaGVpZ2h0PSI4MCIKICAgICAgIHdpZHRoPSI4MCIKICAgICAgIGlkPSJyZWN0MzEwNyIKICAgICAgIHN0eWxlPSJmaWxsOnVybCgjbGluZWFyR3JhZGllbnQ0MjQzKTtmaWxsLW9wYWNpdHk6MTtzdHJva2U6bm9uZSIgLz4KICAgIDx0ZXh0CiAgICAgICBzb2RpcG9kaTpsaW5lc3BhY2luZz0iMTAwJSIKICAgICAgIGlkPSJ0ZXh0MzExMSIKICAgICAgIHk9IjEwMzMuMzI4MiIKICAgICAgIHg9IjM5Ljk0MDY4OSIKICAgICAgIHN0eWxlPSJmb250LXNpemU6MTRweDtmb250LXN0eWxlOm5vcm1hbDtmb250LXdlaWdodDpib2xkO2xpbmUtaGVpZ2h0OjEwMCU7bGV0dGVyLXNwYWNpbmc6MHB4O3dvcmQtc3BhY2luZzowcHg7ZmlsbDp1cmwoI2xpbmVhckdyYWRpZW50NDIzNyk7ZmlsbC1vcGFjaXR5OjE7c3Ryb2tlOm5vbmU7Zm9udC1mYW1pbHk6VGFob21hOy1pbmtzY2FwZS1mb250LXNwZWNpZmljYXRpb246VGFob21hIEJvbGQ7Zm9udC1zdHJldGNoOm5vcm1hbDtmb250LXZhcmlhbnQ6bm9ybWFsO3RleHQtYW5jaG9yOm1pZGRsZTt0ZXh0LWFsaWduOmNlbnRlcjt3cml0aW5nLW1vZGU6bHIiCiAgICAgICB4bWw6c3BhY2U9InByZXNlcnZlIj48dHNwYW4KICAgICAgICAgc3R5bGU9ImZvbnQtc2l6ZToxNHB4O2ZvbnQtc3R5bGU6bm9ybWFsO2ZvbnQtdmFyaWFudDpub3JtYWw7Zm9udC13ZWlnaHQ6Ym9sZDtmb250LXN0cmV0Y2g6bm9ybWFsO3RleHQtYWxpZ246Y2VudGVyO2xpbmUtaGVpZ2h0OjEwMCU7d3JpdGluZy1tb2RlOmxyO3RleHQtYW5jaG9yOm1pZGRsZTtmaWxsOnVybCgjbGluZWFyR3JhZGllbnQ0MjM3KTtmaWxsLW9wYWNpdHk6MTtzdHJva2U6bm9uZTtmb250LWZhbWlseTpUYWhvbWE7LWlua3NjYXBlLWZvbnQtc3BlY2lmaWNhdGlvbjpUYWhvbWEgQm9sZCIKICAgICAgICAgeT0iMTAzMy4zMjgyIgogICAgICAgICB4PSIzOS45NDA2ODkiCiAgICAgICAgIGlkPSJ0c3BhbjMxMTMiCiAgICAgICAgIHNvZGlwb2RpOnJvbGU9ImxpbmUiPkxpdmU8L3RzcGFuPjx0c3BhbgogICAgICAgICBzdHlsZT0iZm9udC1zaXplOjE0cHg7Zm9udC1zdHlsZTpub3JtYWw7Zm9udC12YXJpYW50Om5vcm1hbDtmb250LXdlaWdodDpib2xkO2ZvbnQtc3RyZXRjaDpub3JtYWw7dGV4dC1hbGlnbjpjZW50ZXI7bGluZS1oZWlnaHQ6MTAwJTt3cml0aW5nLW1vZGU6bHI7dGV4dC1hbmNob3I6bWlkZGxlO2ZpbGw6dXJsKCNsaW5lYXJHcmFkaWVudDQyMzcpO2ZpbGwtb3BhY2l0eToxO3N0cm9rZTpub25lO2ZvbnQtZmFtaWx5OlRhaG9tYTstaW5rc2NhcGUtZm9udC1zcGVjaWZpY2F0aW9uOlRhaG9tYSBCb2xkIgogICAgICAgICBpZD0idHNwYW4zMTE1IgogICAgICAgICB5PSIxMDQ3LjMyODIiCiAgICAgICAgIHg9IjM5Ljk0MDY4OSIKICAgICAgICAgc29kaXBvZGk6cm9sZT0ibGluZSI+Q2hhdDwvdHNwYW4+PC90ZXh0PgogICAgPHBhdGgKICAgICAgIGlkPSJzcGVlY2gtYnViYmxlLTEzLWljb24iCiAgICAgICBkPSJtIDE5LjcxMDk3MywxMDEyLjY1IGMgMS41MDU2MywtMi44MTE0IDMuMTc2OTQsLTYuNjcwNCAzLjA5MTI4LC05LjM2MDkgLTIuMDI4MzEsLTIuMjk2MiAtMy4xNzQyMiwtNS4yNTUxIC0zLjE3NDIyLC04LjI2ODkyIDAsLTguNDk2OTcgOC43ODA2NywtMTQuNzA5NDkgMTguNjExMjIsLTE0LjcwOTQ5IDkuNzY5MzUsMCAxOC42MTEyMSw2LjE2NTg0IDE4LjYxMTIxLDE0LjcwOTQ5IDAsOC44OTY0MiAtMTAuNDQwNDksMTcuMjA0ODIgLTI0Ljc2NTYsMTMuOTAyMzIgLTIuNjAxNjIsMS41MDk4IC04LjMzODUxLDMuMDM2NCAtMTIuMzczODksMy43Mjc1IHogbSAzOS4xOTg0LDAuMDc2IGMgMi43MzQ3OCwtMy4wOTU3IDMuMDEzODgsLTcuNzI1NCAtMC4wMTgyLC0xMS4yMzAzIC0zLjEyMDU3LDYuNTk5MyAtMTAuODE2NTMsMTEuNTMxNSAtMjAuNjk0NjgsMTEuNDcxNSAyLjg2NjQzLDMuMTU5IDguMDc5NzMsNS4wNDI1IDE0LjQxMjM3LDMuNTgyNSAxLjc2NTgxLDEuMDI0OSA1LjY1OTY5LDIuMDYxIDguMzk4NywyLjUzMDEgLTEuMDIxOTEsLTEuOTA4MiAtMi4xNTYzNSwtNC41Mjc1IC0yLjA5ODE3LC02LjM1MzggeiIKICAgICAgIGlua3NjYXBlOmNvbm5lY3Rvci1jdXJ2YXR1cmU9IjAiCiAgICAgICBzdHlsZT0iZmlsbDp1cmwoI2xpbmVhckdyYWRpZW50NDIzMSk7ZmlsbC1vcGFjaXR5OjEiIC8+CiAgPC9nPgo8L3N2Zz4K" />

				 	</a>

				 </li>

				   

				   <li>

				   	<a href="http://support.mylive-tech.com/index.php?_m=tickets&_a=submit" title="Submit A Ticket">

				   		<img alt="" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjwhLS0gQ3JlYXRlZCB3aXRoIElua3NjYXBlIChodHRwOi8vd3d3Lmlua3NjYXBlLm9yZy8pIC0tPgoKPHN2ZwogICB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iCiAgIHhtbG5zOmNjPSJodHRwOi8vY3JlYXRpdmVjb21tb25zLm9yZy9ucyMiCiAgIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyIKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB2ZXJzaW9uPSIxLjEiCiAgIHdpZHRoPSI4MCIKICAgaGVpZ2h0PSI4MCIKICAgaWQ9InN2ZzQzNjAiPgogIDxkZWZzCiAgICAgaWQ9ImRlZnM0MzYyIiAvPgogIDxtZXRhZGF0YQogICAgIGlkPSJtZXRhZGF0YTQzNjUiPgogICAgPHJkZjpSREY+CiAgICAgIDxjYzpXb3JrCiAgICAgICAgIHJkZjphYm91dD0iIj4KICAgICAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgICAgICA8ZGM6dHlwZQogICAgICAgICAgIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiIC8+CiAgICAgICAgPGRjOnRpdGxlPjwvZGM6dGl0bGU+CiAgICAgIDwvY2M6V29yaz4KICAgIDwvcmRmOlJERj4KICA8L21ldGFkYXRhPgogIDxnCiAgICAgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCwtOTcyLjM2MjE4KSIKICAgICBpZD0ibGF5ZXIxIj4KICAgIDxyZWN0CiAgICAgICB3aWR0aD0iODAiCiAgICAgICBoZWlnaHQ9IjgwIgogICAgICAgeD0iMCIKICAgICAgIHk9Ijk3Mi4zNjIxOCIKICAgICAgIGlkPSJyZWN0MzA1MyIKICAgICAgIHN0eWxlPSJmaWxsOiNlNmU2ZTY7ZmlsbC1vcGFjaXR5OjE7c3Ryb2tlOm5vbmUiIC8+CiAgICA8cGF0aAogICAgICAgZD0ibSAzMS40NjA2MSw5OTUuNTgwMTYgLTEzLjAxOTkxNiwtOC40OTU2IHYgMTkuNTU1MjQgTCAzMS40NjA2MSw5OTUuNTgwMTYgeiBNIDYyLjgyNDksOTgzLjEzNTExIEggMTguNTkzNjM0IEwgNDAuNjkxNjYsOTk3LjU1NDI3IDYyLjgyNDksOTgzLjEzNTExIHogbSAtMTUuOTM5MzIsMTQuNDMwODYgLTYuMTk1ODYsNC4wMzYzMyAtNi4yMDU2LC00LjA0OTMzIC0xNS45ODk0MTYsMTMuNTgyMTMgSCA2Mi44NTk3OSBMIDQ2Ljg4NTU4LDk5Ny41NjU5NyB6IG0gMy4wMjU1NywtMS45NzExMSAxMy4wMjk1NCwxMS4wNjc3NCB2IC0xOS41NTYxMSBsIC0xMy4wMjk1NCw4LjQ4ODM3IHoiCiAgICAgICBpZD0iZW1haWwtaWNvbiIKICAgICAgIHN0eWxlPSJmaWxsOiMwMDAwMDAiIC8+CiAgICA8dGV4dAogICAgICAgeD0iMzkuOTQwNjg5IgogICAgICAgeT0iMTAzMC40Mzg1IgogICAgICAgaWQ9InRleHQzMDYxIgogICAgICAgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIKICAgICAgIHN0eWxlPSJmb250LXNpemU6MTJweDtmb250LXN0eWxlOm5vcm1hbDtmb250LXdlaWdodDpub3JtYWw7bGluZS1oZWlnaHQ6MTAwJTtsZXR0ZXItc3BhY2luZzowcHg7d29yZC1zcGFjaW5nOjBweDtmaWxsOiMwMDAwMDA7ZmlsbC1vcGFjaXR5OjE7c3Ryb2tlOm5vbmU7Zm9udC1mYW1pbHk6U2FucyI+PHRzcGFuCiAgICAgICAgIHg9IjM5Ljk0MDY4OSIKICAgICAgICAgeT0iMTAzMC40Mzg1IgogICAgICAgICBpZD0idHNwYW4zMDY1IgogICAgICAgICBzdHlsZT0iZm9udC1zaXplOjE0cHg7Zm9udC1zdHlsZTpub3JtYWw7Zm9udC12YXJpYW50Om5vcm1hbDtmb250LXdlaWdodDpib2xkO2ZvbnQtc3RyZXRjaDpub3JtYWw7dGV4dC1hbGlnbjpjZW50ZXI7bGluZS1oZWlnaHQ6MTAwJTt3cml0aW5nLW1vZGU6bHItdGI7dGV4dC1hbmNob3I6bWlkZGxlO2ZpbGw6IzAwMDAwMDtmb250LWZhbWlseTpUYWhvbWE7LWlua3NjYXBlLWZvbnQtc3BlY2lmaWNhdGlvbjpUYWhvbWEgQm9sZCI+U3VibWl0PC90c3Bhbj48dHNwYW4KICAgICAgICAgeD0iMzkuOTQwNjg5IgogICAgICAgICB5PSIxMDQ0LjQzODUiCiAgICAgICAgIGlkPSJ0c3BhbjQwOTkiCiAgICAgICAgIHN0eWxlPSJmb250LXNpemU6MTRweDtmb250LXN0eWxlOm5vcm1hbDtmb250LXZhcmlhbnQ6bm9ybWFsO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1zdHJldGNoOm5vcm1hbDt0ZXh0LWFsaWduOmNlbnRlcjtsaW5lLWhlaWdodDoxMDAlO3dyaXRpbmctbW9kZTpsci10Yjt0ZXh0LWFuY2hvcjptaWRkbGU7ZmlsbDojMDAwMDAwO2ZvbnQtZmFtaWx5OlRhaG9tYTstaW5rc2NhcGUtZm9udC1zcGVjaWZpY2F0aW9uOlRhaG9tYSBCb2xkIj5UaWNrZXQ8L3RzcGFuPjwvdGV4dD4KICA8L2c+Cjwvc3ZnPgo=" />

				   	</a>

				   </li>

				   <li>

				   	<a href="http://www.mylive-tech.com/connect.html" title="Start A Remote Session">

				   		<img alt="" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjwhLS0gQ3JlYXRlZCB3aXRoIElua3NjYXBlIChodHRwOi8vd3d3Lmlua3NjYXBlLm9yZy8pIC0tPgoKPHN2ZwogICB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iCiAgIHhtbG5zOmNjPSJodHRwOi8vY3JlYXRpdmVjb21tb25zLm9yZy9ucyMiCiAgIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyIKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB2ZXJzaW9uPSIxLjEiCiAgIHdpZHRoPSI4MCIKICAgaGVpZ2h0PSI4MCIKICAgaWQ9InN2ZzQzNjAiPgogIDxkZWZzCiAgICAgaWQ9ImRlZnM0MzYyIiAvPgogIDxtZXRhZGF0YQogICAgIGlkPSJtZXRhZGF0YTQzNjUiPgogICAgPHJkZjpSREY+CiAgICAgIDxjYzpXb3JrCiAgICAgICAgIHJkZjphYm91dD0iIj4KICAgICAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgICAgICA8ZGM6dHlwZQogICAgICAgICAgIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiIC8+CiAgICAgICAgPGRjOnRpdGxlPjwvZGM6dGl0bGU+CiAgICAgIDwvY2M6V29yaz4KICAgIDwvcmRmOlJERj4KICA8L21ldGFkYXRhPgogIDxnCiAgICAgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCwtOTcyLjM2MjE4KSIKICAgICBpZD0ibGF5ZXIxIj4KICAgIDxyZWN0CiAgICAgICB3aWR0aD0iODAiCiAgICAgICBoZWlnaHQ9IjgwIgogICAgICAgeD0iMCIKICAgICAgIHk9Ijk3Mi4zNjIxOCIKICAgICAgIGlkPSJyZWN0MzA4NyIKICAgICAgIHN0eWxlPSJmaWxsOiNlNmU2ZTY7ZmlsbC1vcGFjaXR5OjE7c3Ryb2tlOm5vbmUiIC8+CiAgICA8cGF0aAogICAgICAgZD0ibSAzOS45MDA2MSw5ODYuNDA3OTggLTcuOTcyNzUsLTQuODU1MDcgNy45NzI3NSwtNC44NzQ1MyB2IDMuMjA3IGMgMy4zNjYxLDAuMDEwNyA2LjcyOTgzLDAuNzUyNjIgOS43NDYyMiwyLjIzMDA4IDYuMDcyODgsMi45NzQ2NSA5LjgxMzcxLDguNDcyMTMgOS44MTM3MSwxNC40MjEzMyAwLDEuOTI5NTggLTAuMzkzOTUsMy44MTE2MSAtMS4xMzI4NCw1LjU3NTUxIGwgLTMuMDczNDYsLTIuNjA3NTMgYyAwLjI1NzU0LC0wLjk2MjcgMC4zOTMwMywtMS45NTcxIDAuMzkzMDMsLTIuOTY3OTggMCwtNC43OTM1MiAtMy4wMTQxMiwtOS4yMjI4NCAtNy45MDcxMywtMTEuNjE5NTkgLTIuNDI2NCwtMS4xODgzOCAtNS4xMzE3MiwtMS43ODY3OCAtNy44Mzk0MywtMS43OTY1MiB2IDMuMjg3MyB6IG0gLTIuNzE4NTYsMjMuMzcwNjIgYyAtMi42NjkwNSwtMC4zODY3IC01LjIyMjA0LC0xLjM1MzcgLTcuMzg1NTQsLTIuODY0IC00LjM2Mjk2LC0zLjA0NTUgLTYuNDc5MjIsLTcuODM0NDMgLTUuNTUyMDMsLTEyLjU2MzAxIDAuMjgzMzcsLTEuNDQ0MzEgMC43OTQ1MSwtMi43NDQ1NyAxLjgzMDExLC00LjQwNzkgTCAyMy4yNzU3NCw5ODcuNTY5IGMgLTEuNDIxOSwyLjAzMzYzIC0yLjM0NzAzLDMuOTc3OTcgLTIuNzkyNzUsNi4yNTE2MyAtMS4xNTEwNCw1Ljg2ODY0IDEuNDc1NTQsMTEuODEyNDcgNi44OTA1MywxNS41OTI0NyAyLjY4OTYyLDEuODc3MyA1Ljg2NDIyLDMuMDc4NSA5LjE4MjU4LDMuNTU2OSBsIC0wLjYyMDQ3LDMuMTYzNCA4LjgwNzY1LC0zLjY5OCAtNi45MjUxNSwtNS44OTk0IC0wLjYzNjA4LDMuMjQyNiB6IG0gMy4xNjA4NywtNS4wNDE4IGMgMS42MTQwMiwtMC4wNzYgMy4xOTM0MiwwLjQzNTEgNC4zMzY0OSwxLjQwNDkgbCAyLjYxOTc3LDIuMjIyNSBjIC0xLjFlLTQsMTBlLTUgLTMuMWUtNCwxMGUtNSAtNC4yZS00LDJlLTQgbCAyLjc5MjM1LDIuMzY4OSBjIDIuNjkzMDIsLTEuNDAwNCA0LjkwMjMsLTMuMzA1NyA2LjQ5NzcxLC01LjUyNTEgbCAtMi43OTQ0LC0yLjM3MDcgYyAtNS4yZS00LDdlLTQgLTguNWUtNCwwIC0wLjAwMiwwIGwgLTIuNjEwOTcsLTIuMjE1MiBjIC0xLjE0MzkxLC0wLjk3MDUzIC0xLjc0NTc5LC0yLjMwODczIC0xLjY1NTg3LC0zLjY3OTEzIDAuMTQ4NSwtMi4yNjYxMSAtMC43OTcwOSwtNC41NzM5NiAtMi44Mzc0LC02LjMwNDk4IC0yLjcyNjIxLC0yLjMxMjk1IC02LjY2NTY2LC0yLjk2Nzg5IC0xMC4wNzk4MiwtMS45NjYyNiBsIDYuMTk4NTUsNS4yNTkgYyAwLjE0MjMsMi4wNTE1NyAtMy41OTY3OCw1LjIyMzg0IC02LjAxNDkxLDUuMTAzMTQgbCAtNi4xOTg0MywtNS4yNTkwMyBjIC0xLjE4MDcxLDIuODk2NjMgLTAuNDA4NzMsNi4yMzg5NiAyLjMxNzQ3LDguNTUxODYgMi4wNDAyLDEuNzMxMiA0Ljc2MDQyLDIuNTMzMiA3LjQzMTQzLDIuNDA3NCB6IgogICAgICAgaWQ9IndyZW5jaC05LWljb24iCiAgICAgICBzdHlsZT0iZmlsbDojMDAwMDAwO2ZpbGwtb3BhY2l0eToxIiAvPgogICAgPHRleHQKICAgICAgIHg9IjExLjE4NjQ0IgogICAgICAgeT0iMTAzMS43MTgxIgogICAgICAgaWQ9InRleHQ0Nzc5IgogICAgICAgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIKICAgICAgIHN0eWxlPSJmb250LXNpemU6MTRweDtmb250LXN0eWxlOm5vcm1hbDtmb250LXZhcmlhbnQ6bm9ybWFsO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1zdHJldGNoOm5vcm1hbDt0ZXh0LWFsaWduOnN0YXJ0O2xpbmUtaGVpZ2h0OjEwMCU7bGV0dGVyLXNwYWNpbmc6MHB4O3dvcmQtc3BhY2luZzowcHg7d3JpdGluZy1tb2RlOmxyLXRiO3RleHQtYW5jaG9yOnN0YXJ0O2ZpbGw6IzAwMDAwMDtmaWxsLW9wYWNpdHk6MTtzdHJva2U6bm9uZTtmb250LWZhbWlseTpUYWhvbWE7LWlua3NjYXBlLWZvbnQtc3BlY2lmaWNhdGlvbjpUYWhvbWEgQm9sZCI+PHRzcGFuCiAgICAgICAgIHg9IjExLjE4NjQ0IgogICAgICAgICB5PSIxMDMxLjcxODEiCiAgICAgICAgIGlkPSJ0c3BhbjQ3ODEiPlJlbW90ZTwvdHNwYW4+PHRzcGFuCiAgICAgICAgIHg9IjExLjE4NjQ0IgogICAgICAgICB5PSIxMDQ1LjcxODEiCiAgICAgICAgIGlkPSJ0c3BhbjQ3ODMiPkNvbm5lY3Q8L3RzcGFuPjwvdGV4dD4KICA8L2c+Cjwvc3ZnPgo=" />

				   	</a>

				   </li>

				    <li>

				    	<a href="http://support.mylive-tech.com/" title="Support Suite">

				    		<img alt="" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjwhLS0gQ3JlYXRlZCB3aXRoIElua3NjYXBlIChodHRwOi8vd3d3Lmlua3NjYXBlLm9yZy8pIC0tPgoKPHN2ZwogICB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iCiAgIHhtbG5zOmNjPSJodHRwOi8vY3JlYXRpdmVjb21tb25zLm9yZy9ucyMiCiAgIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyIKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB2ZXJzaW9uPSIxLjEiCiAgIHdpZHRoPSI4MCIKICAgaGVpZ2h0PSI4MCIKICAgaWQ9InN2ZzQzNjAiPgogIDxkZWZzCiAgICAgaWQ9ImRlZnM0MzYyIiAvPgogIDxtZXRhZGF0YQogICAgIGlkPSJtZXRhZGF0YTQzNjUiPgogICAgPHJkZjpSREY+CiAgICAgIDxjYzpXb3JrCiAgICAgICAgIHJkZjphYm91dD0iIj4KICAgICAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgICAgICA8ZGM6dHlwZQogICAgICAgICAgIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiIC8+CiAgICAgICAgPGRjOnRpdGxlPjwvZGM6dGl0bGU+CiAgICAgIDwvY2M6V29yaz4KICAgIDwvcmRmOlJERj4KICA8L21ldGFkYXRhPgogIDxnCiAgICAgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCwtOTcyLjM2MjE4KSIKICAgICBpZD0ibGF5ZXIxIj4KICAgIDxyZWN0CiAgICAgICB3aWR0aD0iODAiCiAgICAgICBoZWlnaHQ9IjgwIgogICAgICAgeD0iMCIKICAgICAgIHk9Ijk3Mi4zNjIxOCIKICAgICAgIGlkPSJyZWN0MzA2NyIKICAgICAgIHN0eWxlPSJmaWxsOiNlNmU2ZTY7ZmlsbC1vcGFjaXR5OjE7c3Ryb2tlOm5vbmUiIC8+CiAgICA8dGV4dAogICAgICAgeD0iMzkuOTQwNjk3IgogICAgICAgeT0iMTAzNC44MjgxIgogICAgICAgaWQ9InRleHQzMDcxIgogICAgICAgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIKICAgICAgIHN0eWxlPSJmb250LXNpemU6MTRweDtmb250LXN0eWxlOm5vcm1hbDtmb250LXZhcmlhbnQ6bm9ybWFsO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1zdHJldGNoOm5vcm1hbDt0ZXh0LWFsaWduOnN0YXJ0O2xpbmUtaGVpZ2h0OjEwMCU7bGV0dGVyLXNwYWNpbmc6MHB4O3dvcmQtc3BhY2luZzowcHg7d3JpdGluZy1tb2RlOmxyLXRiO3RleHQtYW5jaG9yOnN0YXJ0O2ZpbGw6IzAwMDAwMDtmaWxsLW9wYWNpdHk6MTtzdHJva2U6bm9uZTtmb250LWZhbWlseTpUYWhvbWE7LWlua3NjYXBlLWZvbnQtc3BlY2lmaWNhdGlvbjpUYWhvbWEgQm9sZCI+PHRzcGFuCiAgICAgICAgIHg9IjM5Ljk0MDY5NyIKICAgICAgICAgeT0iMTAzNC44MjgxIgogICAgICAgICBpZD0idHNwYW4zMDc1IgogICAgICAgICBzdHlsZT0iZm9udC1zaXplOjE0cHg7Zm9udC1zdHlsZTpub3JtYWw7Zm9udC12YXJpYW50Om5vcm1hbDtmb250LXdlaWdodDpib2xkO2ZvbnQtc3RyZXRjaDpub3JtYWw7dGV4dC1hbGlnbjpjZW50ZXI7bGluZS1oZWlnaHQ6MTAwJTt3cml0aW5nLW1vZGU6bHItdGI7dGV4dC1hbmNob3I6bWlkZGxlO2ZpbGw6IzAwMDAwMDtmb250LWZhbWlseTpUYWhvbWE7LWlua3NjYXBlLWZvbnQtc3BlY2lmaWNhdGlvbjpUYWhvbWEgQm9sZCI+U3VwcG9ydDwvdHNwYW4+PHRzcGFuCiAgICAgICAgIHg9IjM5Ljk0MDY5NyIKICAgICAgICAgeT0iMTA0OC44MjgxIgogICAgICAgICBpZD0idHNwYW40MDg5IgogICAgICAgICBzdHlsZT0iZm9udC1zaXplOjE0cHg7Zm9udC1zdHlsZTpub3JtYWw7Zm9udC12YXJpYW50Om5vcm1hbDtmb250LXdlaWdodDpib2xkO2ZvbnQtc3RyZXRjaDpub3JtYWw7dGV4dC1hbGlnbjpjZW50ZXI7bGluZS1oZWlnaHQ6MTAwJTt3cml0aW5nLW1vZGU6bHItdGI7dGV4dC1hbmNob3I6bWlkZGxlO2ZpbGw6IzAwMDAwMDtmb250LWZhbWlseTpUYWhvbWE7LWlua3NjYXBlLWZvbnQtc3BlY2lmaWNhdGlvbjpUYWhvbWEgQm9sZCI+U3VpdGU8L3RzcGFuPjwvdGV4dD4KICAgIDxwYXRoCiAgICAgICBkPSJtIDM3Ljg4MjgxLDk5MC4xOTYwMiA3LjM2NTkyLDYuMzAwNDMgLTMuMTE2MTIsMC41NzU5MiAyLjA1MTc0LDQuNTU1NzMgLTEuOTI4MjEsMS4wODM5IC0yLjA2MTk4LC00LjY0MDM5IC0yLjMxMTM1LDIuMzcwOTkgdiAtMTAuMjQ2NTggeiBtIC0xNi4zODM0OCwtOS4zMDYyMyB2IDMwLjY5NDAxIEggNTkuODc5MDQgViA5ODAuODg5NzkgSCAyMS40OTkzMyB6IG0gMzQuNDU3MDYsMjYuMzg3NTEgSCAyNS40MjE5NyBsIC05ZS01LC0yMi4wODA3NSAzMC41MzQ0MiwtMmUtNCB2IDIyLjA4MDk1IHogbSAtNS4wMjAyLDEwLjM1OTYgdiAyLjU1NjkgSCAzMC40NDIyNyB2IC0yLjU1NjkgaCA0LjY1NzYzIHYgLTMuNDUzMSBoIDExLjE3ODU2IHYgMy40NTMxIGggNC42NTc3MyB6IgogICAgICAgaWQ9ImNvbXB1dGVyLTQtaWNvbiIKICAgICAgIHN0eWxlPSJmaWxsOiMwMDAwMDAiIC8+CiAgPC9nPgo8L3N2Zz4K" />

				    	</a>

				    </li> 

				    <li>

				    	<a href="http://support.mylive-tech.com/index.php?_m=knowledgebase&_a=view" title="Read Knowledgebase">

				    		<img alt="" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjwhLS0gQ3JlYXRlZCB3aXRoIElua3NjYXBlIChodHRwOi8vd3d3Lmlua3NjYXBlLm9yZy8pIC0tPgoKPHN2ZwogICB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iCiAgIHhtbG5zOmNjPSJodHRwOi8vY3JlYXRpdmVjb21tb25zLm9yZy9ucyMiCiAgIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyIKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogICB2ZXJzaW9uPSIxLjEiCiAgIHdpZHRoPSI4MCIKICAgaGVpZ2h0PSI4MCIKICAgaWQ9InN2ZzQzNjAiPgogIDxkZWZzCiAgICAgaWQ9ImRlZnM0MzYyIiAvPgogIDxtZXRhZGF0YQogICAgIGlkPSJtZXRhZGF0YTQzNjUiPgogICAgPHJkZjpSREY+CiAgICAgIDxjYzpXb3JrCiAgICAgICAgIHJkZjphYm91dD0iIj4KICAgICAgICA8ZGM6Zm9ybWF0PmltYWdlL3N2Zyt4bWw8L2RjOmZvcm1hdD4KICAgICAgICA8ZGM6dHlwZQogICAgICAgICAgIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3JnL2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiIC8+CiAgICAgICAgPGRjOnRpdGxlPjwvZGM6dGl0bGU+CiAgICAgIDwvY2M6V29yaz4KICAgIDwvcmRmOlJERj4KICA8L21ldGFkYXRhPgogIDxnCiAgICAgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCwtOTcyLjM2MjE4KSIKICAgICBpZD0ibGF5ZXIxIgogICAgIHN0eWxlPSJmaWxsOiNlNmU2ZTY7ZmlsbC1vcGFjaXR5OjEiPgogICAgPHJlY3QKICAgICAgIHdpZHRoPSI4MCIKICAgICAgIGhlaWdodD0iODAiCiAgICAgICB4PSIwIgogICAgICAgeT0iOTcyLjM2MjE4IgogICAgICAgaWQ9InJlY3QzMDc3IgogICAgICAgc3R5bGU9ImZpbGw6I2U2ZTZlNjtmaWxsLW9wYWNpdHk6MTtzdHJva2U6bm9uZSIgLz4KICAgIDx0ZXh0CiAgICAgICB4PSIzOS45NDA2OTciCiAgICAgICB5PSIxMDMzLjgyODEiCiAgICAgICBpZD0idGV4dDMwODEiCiAgICAgICB4bWw6c3BhY2U9InByZXNlcnZlIgogICAgICAgc3R5bGU9ImZvbnQtc2l6ZToxMnB4O2ZvbnQtc3R5bGU6bm9ybWFsO2ZvbnQtdmFyaWFudDpub3JtYWw7Zm9udC13ZWlnaHQ6Ym9sZDtmb250LXN0cmV0Y2g6bm9ybWFsO3RleHQtYWxpZ246Y2VudGVyO2xpbmUtaGVpZ2h0OjEwMCU7bGV0dGVyLXNwYWNpbmc6MHB4O3dvcmQtc3BhY2luZzowcHg7d3JpdGluZy1tb2RlOmxyLXRiO3RleHQtYW5jaG9yOm1pZGRsZTtmaWxsOiMwMDAwMDA7ZmlsbC1vcGFjaXR5OjE7c3Ryb2tlOm5vbmU7Zm9udC1mYW1pbHk6VGFob21hOy1pbmtzY2FwZS1mb250LXNwZWNpZmljYXRpb246VGFob21hIEJvbGQiPjx0c3BhbgogICAgICAgICB4PSIzOS45NDA2OTciCiAgICAgICAgIHk9IjEwMzMuODI4MSIKICAgICAgICAgaWQ9InRzcGFuMzA4NSIKICAgICAgICAgc3R5bGU9ImZvbnQtc2l6ZToxMnB4O2ZvbnQtc3R5bGU6bm9ybWFsO2ZvbnQtdmFyaWFudDpub3JtYWw7Zm9udC13ZWlnaHQ6Ym9sZDtmb250LXN0cmV0Y2g6bm9ybWFsO3RleHQtYWxpZ246Y2VudGVyO2xpbmUtaGVpZ2h0OjEwMCU7d3JpdGluZy1tb2RlOmxyLXRiO3RleHQtYW5jaG9yOm1pZGRsZTtmaWxsOiMwMDAwMDA7ZmlsbC1vcGFjaXR5OjE7Zm9udC1mYW1pbHk6VGFob21hOy1pbmtzY2FwZS1mb250LXNwZWNpZmljYXRpb246VGFob21hIEJvbGQiPktub3dsZWRnZTwvdHNwYW4+PHRzcGFuCiAgICAgICAgIHg9IjM5Ljk0MDY5NyIKICAgICAgICAgeT0iMTA0NS44MjgxIgogICAgICAgICBpZD0idHNwYW40MDkzIgogICAgICAgICBzdHlsZT0iZm9udC1zaXplOjEycHg7Zm9udC1zdHlsZTpub3JtYWw7Zm9udC12YXJpYW50Om5vcm1hbDtmb250LXdlaWdodDpib2xkO2ZvbnQtc3RyZXRjaDpub3JtYWw7dGV4dC1hbGlnbjpjZW50ZXI7bGluZS1oZWlnaHQ6MTAwJTt3cml0aW5nLW1vZGU6bHItdGI7dGV4dC1hbmNob3I6bWlkZGxlO2ZpbGw6IzAwMDAwMDtmaWxsLW9wYWNpdHk6MTtmb250LWZhbWlseTpUYWhvbWE7LWlua3NjYXBlLWZvbnQtc3BlY2lmaWNhdGlvbjpUYWhvbWEgQm9sZCI+QmFzZTwvdHNwYW4+PC90ZXh0PgogICAgPHBhdGgKICAgICAgIGQ9Im0gNjAuODE5ODcsMTAwMC4zMjI5IGggLTcuNDYwODMgdiAtNi42OTQ4NCBsIDcuNDYwODMsNi42OTQ4NCB6IG0gLTExLjIxNzEyLDMuMzcwNiBWIDk5My41OTg5NiBIIDM2Ljg4MzA5IHYgMjUuNTc1MTQgaCAyMy45NzgxMiB2IC0xNS40ODA2IEggNDkuNjAyNzUgeiBNIDQ1LjUxNDE4LDk4Ni40Njk4NiBIIDI4Ljg3NiB2IDI3LjY0MzY0IGggNC4yOTQ1IHYgLTIzLjc5MDA0IGggMTYuNjM4MjggbCAtNC4yOTQ2LC0zLjg1MzYgeiBtIC03LjczMywtNi45ODcyIEggMjEuMTQyOSB2IDI5LjM3Nzc0IGggNC4yOTQ1IHYgLTI1LjUyNDE0IGggMTYuNjM4MjggbCAtNC4yOTQ1LC0zLjg1MzYgeiIKICAgICAgIGlkPSJtdWx0aS1maWxlcy0yLWljb24iCiAgICAgICBzdHlsZT0iZmlsbDojMDAwMDAwO2ZpbGwtb3BhY2l0eToxIiAvPgogIDwvZz4KPC9zdmc+Cg==" />

				    	</a>

				    </li>

				</ul>

			</div>





			<div class="btn-group pull-right toll-free-numbers">

		    	<button class="btn btn-success" onclick="window.location.href='tel:18883618511'" title="Click to call.">

		    		<i class="icon-callus">

		    		</i> Call Us Toll Free: 1-888-361-8511

		    	</button>



			    <button class="btn btn-success dropdown-toggle" data-toggle="dropdown">

			    	<span class="caret"></span>

			    </button>

			    <ul class="dropdown-menu">

                	<li>

                		<a href="tel:18883618511" rel="external" title="Click to call.">

                                   <i class="icon-callus"></i> USA / Canada | 1-786-975-2146

                		</a></li>

			    	

			<li>

			    	<a href="tel:19544824464" rel="external" title="Click to call.">

                                   <i class="icon-callus"></i> Ft. Lauderdale, FL Office | 1-954-482-4464

			    	</a></li>

                        <li>

                    	        <a href="tel:14047999035" rel="external" title="Click to call.">

                    	           <i class="icon-callus"></i> Atlanta, Georgia | 1-404-799-9035

                                </a></li>

                        <li>

			 	<a href="tel:14169001260" rel="external" title="Click to call.">

                         	   <i class="icon-callus"></i> Toronto, Ontario Canada | 1-416-900-1260

			    	</a></li>

			<li class="divider"></li>

			<li>

			    	<a href="tel:+4402030516419" rel="external" title="Click to call.">

                                    <i class="icon-callus"></i> London | +44 020-3051-6419

                       		</a></li>

			 <li class="divider"></li>

			 <li>

			    	<a href="tel:+551232125101" rel="external" title="Click to call.">

			    	    <i class="icon-callus"></i>São Paulo | +55 12-3212-5101

			    	</a></li>

			    </ul>

			</div>

			

			<div class="search-wrapper">

				<form id="searchform" method="get" action="<?php echo htmlspecialchars( $_SERVER['PHP_SELF'] ); ?>" class="navbar-search pull-right">

					<input type="text" id="s" name="s" value="<?php the_search_query(); ?>" class="search-query" placeholder="" title="Type a keyword and hit Enter." />

						<button type="submit">Search

						</button>

				</form> 

			</div>

		

			



        <!-- Header Bar -->

                        <div class="nav_wrapper">

							<nav role="navigation">

							

									<?php if(of_get_option('branding_logo','')!='') { ?>

										<img src="<?php echo of_get_option('branding_logo'); ?>" alt="<?php echo get_bloginfo('description'); ?>">

										<?php }

										if(of_get_option('site_name','1')) bloginfo('name'); ?></a>

								

								<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">

                                

                                <span class="icon-bar"></span>

            	<span class="icon-bar"></span>

            	<span class="icon-bar"></span>

							        

								</a>

								

								<div class="nav-collapse">

									<?php bones_main_nav(); // Adjust using Menus in Wordpress Admin ?>

                                    <ul class="lt-woocom-links">

									<?php global $woocommerce; ?>

                                    <li><?php
	if ( is_user_logged_in() ) {
    $current_user = wp_get_current_user();
    echo 'Welcome, ' . $current_user->user_firstname . '!';
} else {
    echo 'Welcome, visitor!';
}
	?></li>

<li><a class="cart-contents" href="<?php echo $woocommerce->cart->get_cart_url(); ?>" title="<?php _e('View your shopping cart', 'woothemes'); ?>"><?php echo sprintf(_n('%d item', '%d items', $woocommerce->cart->cart_contents_count, 'woothemes'), $woocommerce->cart->cart_contents_count);?> - <?php echo $woocommerce->cart->get_cart_total(); ?></a></li>



 <?php if ( is_user_logged_in() ) { ?>

    <li class="menu-item menu-item-type-post_type menu-item-object-page dropdown"><a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" title="<?php _e('My Account','woothemes'); ?>"><?php _e('My Account','woothemes'); ?></a></li>

 	<li><a href="<?php echo wp_logout_url(); ?>" title="Logout">Logout</a></li>

 <?php } 

 else { ?>

 <li class="livetech-mc" style="display:none"></li>

 	<li><a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" title="<?php _e('Login / Register','woothemes'); ?>"><?php _e('Login / Register','woothemes'); ?></a>

 <?php } ?></li></ul>



								</div>

								

							</nav>

                           

							

							<?php if(of_get_option('search_bar', '1')) {?>

							<form class="navbar-search pull-right" role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">

								<input name="s" id="s" type="text" class="search-query" autocomplete="off" placeholder="<?php _e('Search','bonestheme'); ?>" data-provide="typeahead" data-items="4" data-source='<?php echo $typeahead_data; ?>'>

							</form>

							<?php } ?>

							

						</div> <!-- end .nav-container -->

					</div> <!-- end .navbar-inner -->

				</div> <!-- end .navbar -->

			 </div>

			</div> <!-- end #inner-header -->

		

		</header> <!-- end header -->

		

		<div class="container-fluid">


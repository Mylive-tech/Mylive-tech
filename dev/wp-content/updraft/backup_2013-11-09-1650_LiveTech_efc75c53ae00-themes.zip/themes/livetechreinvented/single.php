<?php get_header(); ?>

	<?php if( have_posts() ) : ?>

		<?php while( have_posts() ) : the_post(); ?>

            <!-- post -->
    		<div class="post">

			<!-- google_ad_section_start -->
			
            <!-- Post Title -->
			<h1 id="post-<?php the_ID(); ?>" title="<?php the_title_attribute(); ?>" class="post-title"> <?php the_title(); ?> </h1>

			<?php the_content( '' ); ?>

			<!-- google_ad_section_end -->

            </div>
            <!-- /post -->
		
            <!-- Post Meta Data -->
            <p class="post-meta" title="Meta data about this post.">                
                <?php // echo get_the_author_link(); ?>
                Posted on <span title="Date on which this post was published."><?php the_time( 'j M, Y' ) ?></span> 
                in
                <?php
                    $category_syntax = '';
                    foreach( ( get_the_category() ) as $category ) 
                    {
                        if( $category->term_id != mb_get_category_id_by_slug( 'internal-featured' ) )
                        $category_syntax = $category_syntax . '<a href="' . get_bloginfo( 'url' ) . '/category/' . $category->slug . '" title="' . $category->category_description . '" rel="category">' . $category->name . '</a>, ';
                    }
                    echo substr_replace( trim( $category_syntax ), '', -1 );
                ?><?php the_tags( ' | Tags: ', ', ', '' ); ?> 
            </p>

			<!-- Social VCard -->
			<p class="social-vcard" title="Share this post with your friends and family.">
				<!-- Facebook -->
				<iframe src="http://www.facebook.com/plugins/like.php?app_id=225359254171967&amp;href=<?php the_permalink() ?>&amp;send=false&amp;layout=box_count&amp;width=50&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font=verdana&amp;height=90" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:50px; height:62px;" allowTransparency="true"></iframe>
				<!-- Twitter -->
				<a href="http://twitter.com/share" class="twitter-share-button" data-count="vertical">Tweet</a><script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
				<!-- Google Plus One -->
				<g:plusone size="tall"></g:plusone>
				<!-- LinkedIn -->
				<script type="text/javascript" src="http://platform.linkedin.com/in.js"></script><script type="in/share" data-url="<?php the_permalink() ?>" data-counter="top"></script>
				<!-- StumbleUpon -->
				<script src="http://www.stumbleupon.com/hostedbadge.php?s=5"></script>
			</p>
			
			<!-- Place this tag after the last plusone tag -->
			<script type="text/javascript">
			(function() {
				var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
				po.src = 'https://apis.google.com/js/plusone.js';
				var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
			})();
			</script>

            <!-- Related Posts -->    
            <?php
                $categories = get_the_category( $post->ID );
                if( $categories ) 
                {
                    $category_ids = array();
                    foreach( $categories as $this_category ) $category_ids[] = $this_category->term_id;
						
                    $args = array(
						'category__in' => $category_ids,
						'post__not_in' => array( $post->ID ),
						'showposts' => 10, // Number of related posts that will be shown.
						'caller_get_posts' => 1
			         );

                    $my_query = new wp_query( $args );
                    if( $my_query->have_posts() ) 
                    {
                        echo '<p class="post-related">';
                        echo '<strong> Related Posts </strong> <br />';
                        while( $my_query->have_posts() ) 
                        {
                            $my_query->the_post(); ?>
                            &raquo; <a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a> 
                            <br />
                        <?php
                        }
                        echo '</p>';
                    }
                    else 
                    { 
                        // Do nothing 
                    }
                }
						
                $post = $backup;
                wp_reset_query();
            ?>
            
            <!-- Comments -->
			<?php if( comments_open() ) comments_template(); ?>

		<?php endwhile; ?>

	<?php else : ?>

		<p> Sorry, but you are looking for something that isn't here. </p>

	<?php endif; ?>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
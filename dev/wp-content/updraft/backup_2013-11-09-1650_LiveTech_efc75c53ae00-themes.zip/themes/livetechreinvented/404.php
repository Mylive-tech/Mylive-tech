<?php get_header(); ?>

	<p style="font-size: 24px; text-align: center; margin-bottom: 10px;"> Holy moley! </p>
	<p style="font-size: 18px; text-align: center; margin-bottom: 25px;"> 
    	You stumbled across a page that appears to have been moved, deleted or does not exist. Perhaps, searching or <a href="<?php bloginfo( 'url' ); ?>"><strong>restarting</strong></a> will help. 
	</p> 
			
	<p style="text-align: center;">
		<img src="<?php bloginfo( 'template_url' ); ?>/img/404.jpg" alt="Page Not Found" title="Page Not Found" style="border: 1px solid #DDD; padding: 3px;" />
	</p>

<?php get_footer(); ?>

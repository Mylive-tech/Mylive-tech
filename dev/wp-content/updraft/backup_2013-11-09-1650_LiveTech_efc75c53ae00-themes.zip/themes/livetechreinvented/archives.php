<?php get_header(); ?>

	<h1 class="post-title"> Archives </h1>
	
	<p> A complete archive of our tech guides. </p>
	
	<h2> Monthly </h2>
	<ul>
        <?php wp_get_archives( 'type=monthly&show_post_count=1' ); ?>
	</ul>
	
	<h2> Topic </h2>
	<ul>
	   <?php wp_list_categories( 'orderby=name&show_count=1&title_li=' ); ?>
	</ul>
	
	<h2> Tag </h2>
	<?php wp_tag_cloud( 'order=ASC&orderby=name&number=0' ); ?>

<?php get_sidebar(); ?>

<?php get_footer(); ?>

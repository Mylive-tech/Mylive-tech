<?php /*
 
</div>
</div>
<!-- /content -->
	
<!-- sidebar -->
<div id="sidebar-wrap">
<div id="sidebar" class="clearfix">
	
	<div class="sidebar-left">
		
		<!-- Popular Posts -->
		<?php 
		$popular_posts = $wpdb->get_results( "SELECT id, post_title FROM {$wpdb->prefix}posts WHERE post_status = 'publish' AND post_type = 'post' ORDER BY comment_count DESC LIMIT 0,10" );
		if( isset( $popular_posts ) && $popular_posts ) { ?>
		<div class="sidebar-section">
			<p class="sidebar-title"> Popular Posts </p>
	            
			<div class="sidebar-menu">
			<ul>
			<?php
			foreach( $popular_posts as $post )
				echo '<li><a href="' . get_permalink( $post->id ) . '" title="' . $post->post_title . '">' . $post->post_title . '</a></li>';
			?>
			</ul>
			</div>
		</div>
		<?php } ?>
		<!-- /Popular Posts -->
		
	</div>
	
	
	<div class="sidebar-right">
		
		<!-- Categories -->
		<div id="sidebar-section">
			<p class="sidebar-title"> Categories </p>
           
			<?php $categories_args = array(
			'orderby'            => 'name',
			'order'              => 'ASC',
			'show_count'         => false,
			'hierarchical'       => false,
			'title_li'           => '',); 
			?> 
			
			<div class="sidebar-menu">
			<ul>
				<?php wp_list_categories( $categories_args ); ?>
			</ul>
			</div>
		</div>
		<!-- /Categories -->

	</div>
		
	<div class="sidebar-wide">
		
		<p class="sidebar-title"> About </p>
		<p>
			<img src="<?php bloginfo( 'template_url' ); ?>/images/about-the-techie-50.jpg" alt="Abdulqader Kapadia" style="float: left; margin-right: 10px;" /> 
			<a href="http://www.techieonthemove.com/about-the-techie" rel="author">Abdulqader Kapadia</a> is a technology enthusiast with multiple years of industry experience primarily in the field of web development. 
		</p>
		
	</div>
	
</div>
</div>
<!-- /sidebar -->
    
    <?php /*
    
    <!-- sidebar-wrap -->
	<div id="sidebar-wrap">
    
		<?php /*
		<!-- Social -->
        <div class="sidebar-section">
        <h3 class="sidebar-title"> Social </h3>
            <p> <fb:like-box href="http://www.facebook.com/platform" width="340" show_faces="true" stream="false" border_color="#F5F5F5" header="false"></fb:like-box> </p>
        </div> 	
        * ?>
        
        <!-- Popular Posts -->
		<?php 
		$popular_posts = $wpdb->get_results( "SELECT id, post_title FROM {$wpdb->prefix}posts WHERE post_status = 'publish' AND post_type = 'post' ORDER BY comment_count DESC LIMIT 0,10" );
		if( isset( $popular_posts ) && $popular_posts ) { ?>
			<div class="sidebar-section clearfix">
			<h3 class="sidebar-title"> Popular Posts </h3>
	            
				<div class="sidebar-menu">
				<ul>
				<?php
				foreach( $popular_posts as $post )
					echo '<li><a href="' . get_permalink( $post->id ) . '" title="' . $post->post_title . '">' . $post->post_title . '</a></li>';
				?>
				</ul>
				</div>
			</div>
		<?php } ?>
		<!-- /Popular Posts -->
	        
		<!-- Tags -->
		<div class="sidebar-section">
		<h3 class="sidebar-title"> Tags </h3>
	        
		<?php $tag_args = array(
					'smallest'                  => 12, 
	                'largest'                   => 22,
	                'unit'                      => 'px', 
	                'number'                    => 0,  
	                'format'                    => 'flat',
	                'separator'                 => ' ',
	                'orderby'                   => 'count', 
	                'order'                     => 'DESC',
	                'exclude'                   => null, 
	                'include'                   => null, 
	                'topic_count_text_callback' => default_topic_count_text,
	                'link'                      => 'view', 
	                'taxonomy'                  => 'post_tag', 
	                'echo'                      => true ); ?>
			<p style="padding: 10px;"> <?php wp_tag_cloud( $tag_args ); ?> </p>
		</div>
		<!-- /Tags -->
		
		<?php /*
		<!-- sidebar1 -->
        <div id="sidebar1" class="clearfix">
       
            <!-- Categories -->
            <div id="sidebar-section" class="clearfix">
				<h3 class="sidebar-title"> Categories </h3>
            
                <?php $categories_args = array(
                'orderby'            => 'name',
                'order'              => 'ASC',
                'show_count'         => false,
                'exclude'            => mb_get_category_id_by_slug( 'internal-featured' ),
                'hierarchical'       => false,
                'title_li'           => '',); 
                ?> 
                <div class="sidebar-category-menu">
                <ul>
                    <?php wp_list_categories( $categories_args ); ?>
                </ul>
                </div>
            </div>
           	        
        </div>
        <!-- /sidebar1 -->
        *?>        

        <?php /*
    	<!-- sidebar2 -->
    	<div id="sidebar2" class="clearfix">
    	</div>
    	</div>
    	<!-- /sidebar2-wrap -->
    	* ?>
    
    </div>
    <!-- /sidebar-wrap -->
    
    */ ?>
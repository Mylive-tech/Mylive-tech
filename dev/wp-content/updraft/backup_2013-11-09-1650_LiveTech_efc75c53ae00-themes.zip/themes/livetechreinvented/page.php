<?php get_header(); ?>
    <!-- post -->
    <div class="post" style="border-bottom: 0; margin-bottom: 0;">
	<?php if( have_posts() ) : ?>
		<?php while( have_posts() ) : the_post(); ?>
			<h1 id="post-<?php the_ID(); ?>" title="<?php the_title_attribute(); ?>" class="post-title"> <?php the_title(); ?> </h1>
			<?php 
				the_content( '' );
				
			?>
		
		<?php endwhile; ?>
	<?php else : ?>
		<p> Sorry, but you are looking for something that isn't here. </p>
	<?php endif; ?>

    </div>
    <!-- /post -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
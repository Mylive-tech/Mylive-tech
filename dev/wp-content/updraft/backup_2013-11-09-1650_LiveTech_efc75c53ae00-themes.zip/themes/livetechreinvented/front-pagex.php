<?php
/*
Template Name: Home Page
*/
?>

<?php get_header(); ?>

		<!-- CAROUSEL -->
		<div id="myCarousel" class="carousel slide" >
		    <ol class="carousel-indicators">
		    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
		    <li data-target="#myCarousel" data-slide-to="1"></li>
		    <li data-target="#myCarousel" data-slide-to="2"></li>
		    <li data-target="#myCarousel" data-slide-to="3"></li>
		    <li data-target="#myCarousel" data-slide-to="4"></li>
		    </ol>
		    <!-- Carousel items -->
		    <div class="carousel-inner">
			    <div class="active item">
			    	<img src="<?php bloginfo('template_url'); ?>/img/slider/01-live-tech-worldwide-satisfied-customers.jpg" alt="Servicing Over 25,000 Customers Worldwide">
                    <div class="carousel-caption">
                      <h3>Servicing Over 25,000 Computers Worldwide </h3>
                      <p style="margin-top: 0;"> Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit. </p>
                    </div>
			    </div>
			    <div class="item">
			    	<img src="<?php bloginfo('template_url'); ?>/img/slider/02-advanced-systemcare.jpg" alt="Advanced SystemCare with Antivirus">
                    <div class="carousel-caption">
                      <h3> Advanced SystemCare with Antivirus  </h3>
                      <p> Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit. </p>
                    </div>
			    </div>
			    <div class="item">
			    	<img src="<?php bloginfo('template_url'); ?>/img/slider/03-livetech-hosted-exchange.jpg" alt="Live-Tech Hosted Microsoft Exchange 2010">
                    <div class="carousel-caption">
                      <h3> Live-Tech Hosted Microsoft Exchange 2010 </h3>
                      <p> Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit. </p>
                    </div>
			    </div>
			    <div class="item">
			    	<img src="<?php bloginfo('template_url'); ?>/img/slider/04-browser-control-internet-security.jpg" alt="BR Control Internet Security">
                    <div class="carousel-caption">
                      <h3> BR Control Internet Security </h3>
                      <p> Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit. </p>
                    </div>
			    </div>
			    <div class="item">
			    	<img src="<?php bloginfo('template_url'); ?>/img/slider/05-skynox-secure-cloud-backup.jpg" alt="Military-grade Cloud Backup Solution">
                    <div class="carousel-caption">
                      <h3> Military-grade Cloud Backup Solution </h3>
                      <p> Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit. </p>
                    </div>
			    </div>
		    </div>

		    <!-- Carousel nav -->
		    <a class="carousel-control left" href="#myCarousel" data-slide="prev">&lsaquo;</a>
		    <a class="carousel-control right" href="#myCarousel" data-slide="next">&rsaquo;</a>
	    </div>

		<!-- LEADERBOARD -->
		<h4 class="leader-quality"> 
			Quality. Integrity. Rapidity. <span>All 100% guaranteed.</span> 
		</h4>

		<div class="row">  
		<div class="span7">  
			<div class="box-inset">
			<p> Live-Tech is here to provide complete IT technical support solutions. Our team is built of high skilled professionals with over 20 years of IT experience. We use the most advanced methods and technologies to assure that your IT problem is resolved. </p>
			<p> 98% of all Technical Support problems are fully resolved with our Remote IT Support Options. </p>
			<p style="margin-bottom: 0;"> Call Live-Tech Today and leave IT Management to the experts. Live-Tech is a pioneer company that honors a NO FIX – NO PAY support policy. </p>
			</div>
		</div>

		<div class="span5">
			<div class="box-inset" style="padding: 15px;">
				<div style="margin: 0; background-image: url(http://icons.iconarchive.com/icons/3xhumed/tools-hardware-pack-4/48/Creative-Fatal1ty-Gaming-Headset-icon.png); background-repeat: no-repeat; background-position: 96% center;">
				<p style="margin-bottom: 2px; font-size: 13px; font-weight: bold;"> Say hello. We'd be glad to help. </p>
				<a class="btn btn-warning btn-small"><i class="icon-comment"></i> Live Chat with Support</a>
				<a class="btn btn-warning btn-small"><i class="icon-headphones"></i> Schedule an Online Meetup</a>
				</div>

				<hr style="clear: both; display: block; height: 1px; border: 0; border-top: 1px solid #DADADA; margin: 15px 0px; padding: 0;">

				<div style="margin: 0; background-image: url(http://icons.iconarchive.com/icons/dapino/callcenter-girls/48/callcenter-girls-blonde-icon.png); background-repeat: no-repeat; background-position: 96% center;">
				<p style="margin-bottom: 2px; font-size: 13px; font-weight: bold;"> Join our growing network. Let's walk together. </p>
				<a class="btn btn-danger btn-small"><i class="icon-heart"></i> Refer a Friend Program</a>
				<a class="btn btn-danger btn-small"><i class="icon-refresh"></i> Become a Reseller</a>
				</div>
			</div>
		</div>
		</div>
		
		<!-- THUMBNAILS -->
		<h3 class="home-section-head">
			<span>
				<img src="http://icons.iconarchive.com/icons/deleket/soft-scraps/16/Briefcase-icon.png" style="top: -2px; position: relative;" />
				SERVICES
			</span> 
			<br />
			Here’s everything we offer you, bit to bytes. 
		</h3>

		<ul class="thumbnails">
		    <li class="span3">
		    	<div class="thumbnail">
			    	<img src="http://www.computer-wiz.net/wp-content/uploads/2012/11/repairs_image02-300x100.png" data-src="holder.js/300x200" alt="">
			    	<div class="caption">
			    	<h4> RIS | Online Home Computer Repair & Assistance </h4>
			    	<p> Head to the docs for information, examples, and code snippets, or take the next leap and customize Bootstrap for any upcoming project. </p>
			    	<p style="margin-bottom: 0;">
			    		<a hre="" class="btn btn-mini">Details</a>
			    		<a hre="" class="btn btn-mini">Compare Plans</a>
			    	</p>
			    	</div>
		    	</div>
		    </li>

		    <li class="span3">
		    	<div class="thumbnail">
			    	<img src="http://www.latecamisado.com/wp-content/uploads/2012/10/cropped-technology1.jpg" data-src="holder.js/300x200" alt="">
			    	<div class="caption">
			    	<h4> BIS | Business Computer Support & Assistance </h4>
			    	<p> Head to the docs for information, examples, and code snippets, or take the next leap and customize Bootstrap for any upcoming project. </p>
			    	<p style="margin-bottom: 0;">
			    		<a hre="" class="btn btn-mini">Details</a>
			    		<a hre="" class="btn btn-mini">Compare Plans</a>
			    	</p>
			    	</div>
		    	</div>
		    </li>

		    <li class="span3">
		    	<div class="thumbnail">
			    	<img src="http://jtstyle.com/data/uploads/services/hosting.jpg" data-src="holder.js/300x200" alt="">
			    	<div class="caption">
			    	<h4> Cloud Hosting & Services </h4>
			    	<p> Head to the docs for information, examples, and code snippets, or take the next leap and customize Bootstrap for any upcoming project. </p>
			    	<p style="margin-bottom: 0;">
			    		<a hre="" class="btn btn-mini">Details</a>
			    		<a hre="" class="btn btn-mini">Compare Plans</a>
			    	</p>
			    	</div>
		    	</div>
		    </li>

		    <li class="span3">
		    	<div class="thumbnail">
			    	<img src="http://www.bimserve.com/ict/wp-content/themes/bim/functions/thumb.php?src=ict/wp-content/uploads/2013/02/in_3.jpg&w=300&h=100&zc=1&q=90" data-src="holder.js/300x200" alt="">
			    	<div class="caption">
			    	<h4> Home / Business VoIP Phone Service </h4>
			    	<p> Head to the docs for information, examples, and code snippets, or take the next leap and customize Bootstrap for any upcoming project. </p>
			    	<p style="margin-bottom: 0;">
			    		<a hre="" class="btn btn-mini">Details</a>
			    		<a hre="" class="btn btn-mini">Compare Plans</a>
			    	</p>
			    	</div>
		    	</div>
		    </li>
		</ul>

		
	<a name="consultationform"></a>
		<ul class="thumbnails" style="margin-bottom: 25px; padding-bottom: 0;">
		    <li class="span3">
		    	<div class="thumbnail">
			    	<img src="http://www-03.ibm.com/systems/resources/BottomModule_WWEvents.jpg" data-src="holder.js/300x200" alt="">
			    	<div class="caption">
			    	<h4> Website Development & Custom Art Services </h4>
			    	<p> Head to the docs for information, examples, and code snippets, or take the next leap and customize Bootstrap for any upcoming project. </p>
			    	<p style="margin-bottom: 0;">
			    		<a hre="" class="btn btn-mini">Details</a>
			    		<a hre="" class="btn btn-mini">Compare Plans</a>
			    	</p>
			    	</div>
		    	</div>
		    </li>

		    <li class="span3">
		    	<div class="thumbnail">
			    	<img src="http://www.ditecom.com/imagenes/networking.png" data-src="holder.js/300x200" alt="">
			    	<div class="caption">
			    	<h4> Networking / Hardware Solutions & Support </h4>
			    	<p> Head to the docs for information, examples, and code snippets, or take the next leap and customize Bootstrap for any upcoming project. </p>
			    	<p style="margin-bottom: 0;">
			    		<a hre="" class="btn btn-mini">Details</a>
			    		<a hre="" class="btn btn-mini">Compare Plans</a>
			    	</p>
		    	</div>
	    	</div>
	    </li>

		    <li class="span3">
		    	<div class="thumbnail">
			    	<img src="http://blogs.softchoice.com/advisor/files/2012/09/server-clouds-300x100.jpg" data-src="holder.js/300x200" alt="">
			    	<div class="caption">
			    	<h4> Onsite, Offsite, and Cloud Backup Solutions </h4>
			    	<p> Head to the docs for information, examples, and code snippets, or take the next leap and customize Bootstrap for any upcoming project. </p>
			    	<p style="margin-bottom: 0;">
			    		<a hre="" class="btn btn-mini">Details</a>
			    		<a hre="" class="btn btn-mini">Compare Plans</a>
			    	</p>
		    	</div>
	    	</div>
	    </li>

	    <li class="span3">
		    	<div class="thumbnail">
		    	<img src="http://www.arcabit.com/thumbnail.php?crop=1&width=300&height=100&file=48" alt="">
			    	<div class="caption">
			    	<h4> Office Out of the Box </h4>
			    	<p> This service will offer a company's remotely working employee with all the required setup and software to get started.  </p>
			    	<p style="margin-bottom: 0;">
			    		<a hre="" class="btn btn-mini">Details</a>
			    		<a hre="" class="btn btn-mini">Compare Plans</a>
			    	</p>
		    	</div>
	    	</div>
	    </li>
	</ul>


		<!-- CONSULTATION FORM -->
		<div class="row" style="margin-bottom: 25px;">
		<div class="span12 quickconsult thumbnail">
			<div style=" text-align: center; padding: 15px; ">
			<h4> Get a straightforward & genuine consultation. Quickly. </h4>
			<form class="form-inline" style="margin: 0;">
			    <input type="text" class="input-small" placeholder="Name" style="width: 200px;">
			    <input type="text" class="input-small" placeholder="Email" style="width: 200px;">
			    <input type="text" class="input-small" placeholder="Phone" style="width: 200px;">
			    <textarea rows="1" placeholder="Message" style="width: 200px; height: 20px;"></textarea>
			    <button type="submit" class="btn"><i class="icon-share-alt"></i>Send</button>
			    <br />
			    <label class="checkbox" style="font-size: 13px; margin-top: 3px;">
				<input type="checkbox" value="">
				Subscribe to our newsletter to receive latest news and updates. Absolutely free.
				</label>
			</form>
			</div>
		</div>
	</div>



		
		<!-- TECHNICAL SERVICES -->
		<h3 class="home-section-head">
			<span>
				<img src="http://icons.iconarchive.com/icons/deleket/soft-scraps/16/Gear-icon.png" style="top: -2px; position: relative;" />
				TECHNICAL SERVICES
			</span> 
			<br />
			We offer services across a plethora of industries. 
		</h3>


	<div class="row" style="margin-bottom: 25px;">  
		<div class="span3" style="background-color: #F0F0F0;">  
			<div class="box-inset">
			<p style="border-bottom: 1px solid #CCC; padding-bottom: 10px;"> <span style="font-size: 12px; font-weight: bold; text-transform: uppercase;"><i class="icon-briefcase"></i> Technical services for</span> <br /> <span style="color: #BF0000; font-size: 22px;">Health Care</span> </p>
			<p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
			</div>  
		</div>

		<div class="span3" style="background-color: #F0F0F0;">
			<div class="box-inset">
			<p style="border-bottom: 1px solid #CCC; padding-bottom: 10px;"> <span style="font-size: 12px; font-weight: bold; text-transform: uppercase;"><i class="icon-briefcase"></i> Technical services for</span> <br /> <span style="color: #BF0000; font-size: 22px;">Taxation and Finance</span> </p>
			<p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
			</div>  
		</div>

		<div class="span3" style="background-color: #F0F0F0;">
			<div class="box-inset">
			<p style="border-bottom: 1px solid #CCC; padding-bottom: 10px;"> <span style="font-size: 12px; font-weight: bold; text-transform: uppercase;"><i class="icon-briefcase"></i> Technical services for</span> <br /> <span style="color: #BF0000; font-size: 22px;">Travel and Mobility</span> </p>
			<p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
			</div>  
		</div>

		<div class="span3" style="background-color: #F0F0F0;">
			<div class="box-inset">
			<p style="border-bottom: 1px solid #CCC; padding-bottom: 10px;"> <span style="font-size: 12px; font-weight: bold; text-transform: uppercase;"><i class="icon-briefcase"></i> Technical services for</span> <br /> <span style="color: #BF0000; font-size: 22px;">NOC Management</span> </p>
			<p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
			</div>  
		</div>
	</div>

		
		<!-- TESTIMONIALS -->
		<h3 class="home-section-head">
			<span>
				<img src="http://icons.iconarchive.com/icons/blackblurrr/xmas-pack/16/star-icon.png" style="top: -2px; position: relative;" />
				<img src="http://icons.iconarchive.com/icons/blackblurrr/xmas-pack/16/star-icon.png" style="top: -2px; position: relative;" />
				<img src="http://icons.iconarchive.com/icons/blackblurrr/xmas-pack/16/star-icon.png" style="top: -2px; position: relative;" />

				TESTIMONIALS
				<img src="http://icons.iconarchive.com/icons/blackblurrr/xmas-pack/16/star-icon.png" style="top: -2px; position: relative;" />
				<img src="http://icons.iconarchive.com/icons/blackblurrr/xmas-pack/16/star-icon.png" style="top: -2px; position: relative;" />
				<img src="http://icons.iconarchive.com/icons/blackblurrr/xmas-pack/16/star-icon.png" style="top: -2px; position: relative;" />
			</span> 
			<br /> 
			We always listen to what our customers have to say. Very carefully. 
		</h3>

		<div class="row" style="margin-bottom: 25px;">
		<div class="span4" style="background-color: #FFF6CF;">  
			<div style="padding: 15px; margin: 0;">
			<p> 
			“This was my first experience with Live Tech and I was absolutely amazed with their excellent performance! I had a really nasty virus and other computer issues. Frank worked with me for a long period of time to resolve my issues. I have worked with other Techs previously, but none were as dedicated an competent as Frank. These guys don't stop until the issues are resolved. I recommend this team to anyone wanting superior results." 
				<br />
				-- <strong>Jerry A Foster</strong> <small><a href="">www.company.com</a></small> 
			</p>
			</div>  
		</div>

		<div class="span4" style="background-color: #FFF1AF;">  
			<div style="padding: 15px; margin: 0;">
			<p> 
				“Live-Tech Support did fantastic work in helping me clean my machines infected with viruses and also helped me on network mapping. They are one stop shop for all computer needs. Their knowledge, inclination and efforts to resolve any business application problem (Tax, accounting, including Quick Books, MS office and host of other applications) is great !. The best thing is, they are cordial, professional and available late evening and weekends as well. I strongly recommend them for total system solution." 
				<br />
				-- <strong>Rasesh Vora, Vora Tax Services</strong> <small><a href="">www.company.com</a></small>
			</p>
		</div>  
	</div>
		<div class="span4" style="background-color: #FFF6CF;">  
			<div style="padding: 15px; margin: 0;">
			<p> 
				“Live-Tech Jeremy has been helping us for over a week. He is very caring, competent, and attentive. Without Live-Tech support, we would still be trying to work on two computers versus seven. The ATX software technical support has been horrible. I am so thankful for Jeremy. He has been a lifesaver to us. He is so patient and knows exactly what to do to fix the situation. Thank you, Live-Tech. You are a Godsend." 
				<br />
			-- <strong>Sherri Owen-Calaway, C.P.A.</strong> <small><a href="">www.company.com</a></small>
			</p>
			</div>  
		</div>
	</div>

		<!-- SUPPORT ACTIONS -->
		<!--		
		<div class="row" style="margin-bottom: 25px;">
		<div class="span2" style="background-color: #93CBF0; text-align: center;">
			<div style="padding: 15px 5px;">
			<p style="margin-bottom: 0;"> Live Chat with Support </p>
			</div>
		</div>
		<div class="span2" style="background-color: #F0B593; text-align: center;">
			<div style="padding: 15px 5px;">
			<p style="margin-bottom: 0;"> Start a Remote Session </p>
			</div>
		</div>
		<div class="span2" style="background-color: #C892F0; text-align: center;">
			<div style="padding: 15px 5px;">
			<p style="margin-bottom: 0;"> Submit a Ticket </p>
			</div>
		</div>
		<div class="span2" style="background-color: #F89DC6; text-align: center;">
			<div style="padding: 15px 5px;">
			<p style="margin-bottom: 0;"> Support Suite </p>
			</div>
		</div>
		<div class="span2" style="background-color: #AAE690; text-align: center;">
			<div style="padding: 15px 5px;">
			<p style="margin-bottom: 0;"> Read Knowledge Base </p>
			</div>
		</div>

		<div class="span2" style="background-color: #F3E7B0; text-align: center;">
			<div style="padding: 15px 5px;">
			<p style="margin-bottom: 0;"> Get Free Consultation </p>
			</div>
		</div>
	</div>
	-->

		<!-- TABLE -->
		<!--
		<div class="row" style="margin-bottom: 25px;">  
		<div class="span12" style="background-color: #F0F0F0;">
			<table class="table table-striped">  
	        <thead>  
	          <tr>  
	            <th>Student-ID</th>  
	            <th>First Name</th>  
	            <th>Last Name</th>  
	            <th>Grade</th>  
	          </tr>  
	        </thead>  
        <tbody>  
        <tr>  
           <td>001</td>  
	            <td>Rammohan </td>  
	            <td>Reddy</td>  
	            <td>A+</td>  
	          </tr>  
	          <tr>  
	            <td>002</td>  
	            <td>Smita</td>  
	            <td>Pallod</td>  
	            <td>A</td>  
	          </tr>  
	          <tr>  
	            <td>003</td>  
	            <td>Rabindranath</td>  
	            <td>Sen</td>  
	            <td>A+</td>  
	          </tr>  
	        </tbody>  
	      </table>  
		</div>
	</div>
-->

</div>

<?php get_footer(); ?>
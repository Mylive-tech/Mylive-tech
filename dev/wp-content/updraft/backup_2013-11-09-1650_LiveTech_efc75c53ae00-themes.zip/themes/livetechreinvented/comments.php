<?php // Do not delete these lines
if ('comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
die ('Please do not load this page directly. Thanks!');

if (!empty($post->post_password)) { // if there's a password
	if ($_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) {  // and it doesn't match the cookie
		?>
		
		<p class="nocomments"><?php _e("This post is password protected. Enter the password to view comments."); ?><p>
		
		<?php
		return;
	}
}

/* This variable is for alternating comment background */
$oddcomment = 'alt';
?>

<!-- You can start editing here. -->

<a name="commenting" id="comments"></a>

<!-- comments-wrap -->
<div id="comments-wrap">

	<h5 class="comments-title">COMMENTS <span style="float:right;"><?php comments_number('No person has commented yet.', '1 person has commented.', '% people have commented.'); ?> </span></h5>    
    
    <!-- Facebook Comments -->
    <fb:comments href="<?php the_permalink() ?>" num_posts="5" width="600"></fb:comments>
    
	<?php if ($comments) : ?>
    
    	<ol class="comments-list">
    
    		<?php foreach ($comments as $comment) : ?>
    
            <li id="comment-<?php comment_ID() ?>" class="<?php echo tj_comment_class() ?>">
            
            	<div class="comment-author">
				<?php comment_author_link() ?>
                <span class="comments-time">
                	<a href="#comment-<?php comment_ID() ?>"> <?php comment_date('j F, Y') ?></a> <? edit_comment_link(__(' Edit', 'sandbox'), ' ', ''); ?>
				</span>
                </div>
                
                <div class="comment-text">
                <?php comment_text() ?>
                
                <?php if ($comment->comment_approved == '0') : ?>
                <p class="error-message">Your comment is awaiting moderation.</p>
                <?php endif; ?>
                </div>
               
            </li>
            
            <?php endforeach; /* end for each comment */ ?>
    
    	</ol>
    
    <?php else : // this is displayed if there are no comments so far ?>
    
    	<?php if ('open' == $post-> comment_status) : ?> 
    	<!-- If comments are open, but there are no comments. -->
    	<?php else : // comments are closed ?>
        <!-- If comments are closed. -->
        <p class="error-message">Sorry, comments are closed.</p>
    
    	<?php endif; ?>
    
    <?php endif; ?>
    
    <?php if ('open' == $post-> comment_status) : ?>
        
        <?php if ( get_option('comment_registration') && !$user_ID ) : ?>
        
        	<p>You must be <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?redirect_to=<?php the_permalink(); ?>">logged in</a> to post a comment.</p>
        
        <?php else : ?>
        
        	<div class="comments-form">
            
                <form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">
                
                    <?php if ( $user_ID ) : ?>
                    
                        <p>
                            Logged in as <a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>. <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?action=logout" title="<?php _e('Log out of this account') ?>">Logout &raquo;</a>
                        </p>
        
                    <?php else : ?>
                        
                        <table style="width:90%;">
                        <tr>
                        	<td>
                            Full Name <span class="error-message"><small><?php if ($req) _e('*'); ?></small></span> <br />
	                        <input class="comment-textbox" type="text" name="author" id="author" value="<?php echo $comment_author; ?>" title="Enter your full name." />
                            </td>
                            <td>
                            Email Address <span class="error-message"><small><?php if ($req) _e('*'); ?></small></span> <br />
	                        <input class="comment-textbox" type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" title="Enter your email address."/>
                            </td>
                            <td>
                            Website Address <br />
                        	<input class="comment-textbox" type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" title="Enter your website URL."/>
                            </td>
                        </tr>
                        </table>
                        
                    <?php endif; ?>
                        
                    <p>
                    Enter your comment <br />
                    <textarea class="comment-textbox" name="comment" id="comment" cols="50" rows="5" title="Enter your comment."></textarea> <br />
                    <span class="comments-note"> Kindly review your comment before submitting. Do not spam or use abusive language. </span>
                    </p>
                    
                    <p>
                    <input class="comment-submit" name="submit" type="submit" id="submit" value="Submit" title="Click to submit your comment." />
                    <input type="hidden" name="comment_post_ID" value="<?php echo $id; ?>" />
                    </p>
                    
                    <?php do_action('comment_form', $post->ID); ?>
                    
                </form>
			</div>
        
        <?php endif; // If registration required and not logged in ?>
        
	<?php endif; // if you delete this the sky will fall on your head ?>
    
</div>
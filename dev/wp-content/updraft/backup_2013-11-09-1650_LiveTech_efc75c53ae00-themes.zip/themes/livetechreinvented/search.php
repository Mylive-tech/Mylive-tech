<?php get_header(); ?>

	<?php if( have_posts() ) : ?>
    
        <p class="posts-message"> We found following results for the keyword <strong><?php the_search_query(); ?></strong>. </p>
	
        <!-- posts -->
        <div class="posts">

		<?php while( have_posts() ) : the_post(); ?>
            
            <!-- posts-row -->
            <div class="posts-row clearfix">
            
            	<div class="posts-row-left">
            	
            		<?php
                    if( has_post_thumbnail() ) 
                    {
                        echo get_the_post_thumbnail( $post->ID, array( 100 ,100 ) ); 
                    }
                    else
                    { ?>
                    	<img src="<?php bloginfo( 'template_url' ); ?>/images/feature-image-default.png" alt="Sorry, the thumbnail is missing." title="Sorry, the thumbnail is missing." />
                    <?php } ?>
            		
            	</div>
            	
            	<div class="posts-row-right">
            		
            		<!-- google_ad_section_start -->
        		
	                <!-- Post Title -->
	                <h3 id="post-<?php the_ID(); ?>" class="posts-title"> <a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a> </h3>
	        							
	                <!-- Post Meta -->
	                <p class="posts-meta">
	                    <span title="Date on which this post was published."><?php the_time( 'j M, Y' ) ?></span>  
	                </p>
	                    
	                <p> <?php echo mb_display_post_summary( $post->ID ); ?> </p>
	
	                <!-- google_ad_section_end -->
            	
            	</div>

            </div>
            <!-- /posts-row -->

		<?php endwhile; ?>
        
        </div>
        <!-- /posts -->
		
        <!-- posts-navigation -->
		<?php if( mb_page_navigation_exist() ): ?>
		<div class="posts-navigation">
			<p> <?php posts_nav_link( ' &minus; ', '&laquo; Previous', 'Next &raquo;' ); ?> </p>
		</div>
		<?php endif; ?>
        <!-- /posts-navigation -->
			
	<?php else : ?>

		<p> Sorry, but you are looking for something that isn't here. </p>
		
	<?php endif; ?>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
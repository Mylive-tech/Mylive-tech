</div>
<!-- /CONTAINER -->
	
	<!-- LINE -->
	
	<hr style="margin-bottom: 25px;">
	
	<!-- SOCIAL -->
	
	<div class="container">
	
		<div class="row">
		<div class="span8">
			<p>
		        <!-- AddThis BEGIN -->
				<div class="addthis_toolbox addthis_default_style">
				<a class="addthis_button_facebook_like" fb:like:layout="button_count" style="width: 75px;"></a>
				<a class="addthis_button_tweet" style="width: 60px;"></a>
				<a class="addthis_button_google_plusone" g:plusone:size="medium" style="width: 65px;"></a>
				<a class="addthis_button_linkedin_counter" style="width: 100px;"></a> 
				<a class="addthis_button_pinterest_pinit" style="width: 34px;"></a>
				<a class="addthis_counter addthis_pill_style" style="width: 55px;"></a>
				</div>
				<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-51d3ddab2198d321"></script>
				<!-- AddThis END -->
			</p>
			<p style="clear: left; margin: 0; text-align: left;">
				<iframe src="//www.facebook.com/plugins/like.php?href=http%3A%2F%2Ffacebook.com%2Flivetechexchange&amp;send=false&amp;layout=standard&amp;width=400&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font&amp;height=35&amp;appId=261100693918446" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:300px; height:35px;text-align:center" allowTransparency="true"></iframe>
			</p>
		</div>
		<div class="span4">
			<p style="margin: 0; text-align: right;">
				Let's connect to share and talk more. <br />
				<a href="http://www.facebook.com/pages/My-Live-Tech/224274488659" title="Follow Live-Tech on Facebook." target="_blank" rel="nofollow"> <img src="<?php bloginfo('template_url'); ?>/img/facebook-32.png" alt="Facebook" /> </a>
				<a href="https://plus.google.com/u/0/b/112659795564637259745/112659795564637259745" title="Follow Live-Tech on Google+." target="_blank" rel="nofollow"> <img src="<?php bloginfo('template_url'); ?>/img/googleplus-32.png" alt="Google+" /> </a>
				<a href="http://www.twitter.com/mylivetech" title="Follow Live-Tech on Twitter." target="_blank" rel="nofollow"> <img src="<?php bloginfo('template_url'); ?>/img/twitter-32.png" alt="Twitter" /> </a>
				<a href="https://www.youtube.com/user/livetech2006" title="Watch Live-Tech Videos on YouTube." target="_blank" rel="nofollow"> <img src="<?php bloginfo('template_url'); ?>/img/youtube-32.png" alt="YouTube" /> </a>
				<a href="http://www.linkedin.com/companies/live-tech" title="Follow Live-Tech on LinkedIn." target="_blank" rel="nofollow"> <img src="<?php bloginfo('template_url'); ?>/img/linkedin-32.png" alt="LinkedIn" /> </a>
				<a href="http://pinterest.com/frankzabroski/live-tech/" title="Follow Live-Tech on Pinterest." target="_blank" rel="nofollow"> <img src="<?php bloginfo('template_url'); ?>/img/pinterest-32.png" alt="Pinterest" /> </a>
				<a href="http://support.mylive-tech.com/rss/index.php?_m=news&amp;_a=view&amp;group=supportsuite" title="Subscribe to Live-Tech's RSS Feed." target="_blank" rel="nofollow"> <img src="<?php bloginfo('template_url'); ?>/img/rss-32.png" alt="RSS" /> </a>
			</p>
		</div>
		</div>
	
	</div>
	
	<!-- LINE -->
    
    <!--Footer Widgets-->
   <div class="footer-wrapper">
    <div id="footer-sidebar" class="secondary">
<div id="footer-sidebar1">
<?php
if(is_active_sidebar('footer-sidebar-1')){
dynamic_sidebar('footer-sidebar-1');
}
?>
</div>
<div id="footer-sidebar2">
<?php
if(is_active_sidebar('footer-sidebar-2')){
dynamic_sidebar('footer-sidebar-2');
}
?>
</div>
<div id="footer-sidebar3">
<?php
if(is_active_sidebar('footer-sidebar-3')){
dynamic_sidebar('footer-sidebar-3');
}
?>

</div>
</div>
</div>

    <!--End Footer Widgets-->
	<div style="display: block; clear: both; height: 2px; background-color: #BF0000;"> &nbsp; </div>
	
	<!-- FOOTER -->
	
	<footer>
	<div class="container-fluid" style="background-color: #F0F0F0; padding-top: 25px;">
	
	<div class="container">
	
		<div class="row" style="margin-bottom: 25px;"">
		<div class="span4" style="text-align: left;">
			<p style="margin: 0; font-size: 12px;"> 
				Copyright &copy; <?php echo date( 'Y' ); ?> Live-Tech. All Rights Reserved.
			</p>
		</div>
		
		<?php /*
		<div class="span2" style="text-align: left;">
			<a class="opacity-30" href="http://www.alexa.com/siteinfo/http://www.mylive-tech.com/"><script type='text/javascript' src='http://xslt.alexa.com/site_stats/js/s/a?url=http://www.mylive-tech.com/'></script></a>
		</div>
		*/ ?>
		
		<div class="span8" style="text-align: right;">
			<p style="margin: 0; text-align: right;">
				<a href="<?php echo site_url( 'about' ); ?>" title="About">About</a> .
				<a href="<?php echo site_url( 'management' ); ?>" title="Management">Management</a> .
				<a href="<?php echo site_url( 'vision' ); ?>" title="Our Vision">Our Vision</a> .
				<a href="<?php echo site_url( 'partners' ); ?>" title="Partners">Partners</a> .
				<a href="<?php echo site_url( 'news' ); ?>" title="News">News</a> .
				<a href="<?php echo site_url( 'careers' ); ?>" title="Careers">Careers</a>
			</p>
		</div>
		</div>
		
		<!-- Family -->
		
		<div class="row" style="margin-bottom: 25px;"">
		<div class="span12" style="text-align: left; font-size: 12px;">
		
			<p style="margin-bottom: 0px; text-transform: uppercase;"><i class="icon-heart"></i> <strong>The <span style="color: #BF0000;">Live-Tech</span> Family</strong> </p>
			<p style="margin-bottom: 0;">
				<a href="http://www.mylive-tech.com">Live-Tech</a> |
				<a href="http://www.livetechexchange.com">Live-Tech Exchange</a> |
				<a href="http://www.livetechit.com/blog">Live-Tech IT Blog</a> |
				<a href="http://www.talkswitchshop.com">FortiVoice & TalkSwitch</a> |
				<a href="http://livetechdirectory.com">Live-Tech Directory</a> |
				<a href="http://www.lynkvoip.com">Lynk VoIP</a> |
				<a href="http://www.brcontrol.com.br">BR Control Internet Security</a> |
				<a href="http://marketplace.mylive-tech.com">Live-Tech Marketplace</a>
			</p>
				
		</div>
		</div>
		
		<!-- Links -->
		
		<p style="font-size: 12px; font-weight: bold; border-bottom: 1px solid #CCC; margin-bottom: 0px; padding-bottom: 3px; text-transform: uppercase;"><i class="icon-th-large"></i> <span style="color: #BF0000;">Live-Tech</span> Installs, Supports & Maintains </p>
		<div class="row" style="margin-bottom: 0px; font-size: 12px;">  
		<div class="span2" style="background-color: #E9E9E9; padding: 10px 0px;">
			<ul>
				<li><a href="http://www.mylive-tech.com/shop.html#!/~/product/id=16045351" title="IObit Solutions">IObit Solutions</a></li>
				<li><a href="http://www.mylive-tech.com/shop.html#!/~/category/id=694003&amp;offset=0&amp;sort=normal" title="Internet Securities">Internet Securities</a></li>
               	<li>Spyware Removal</li>
                <li>Virus Sweep &amp; Clean Files</li>
                <li>Hardware Upgrades</li>
                <li>Hardware Troubleshooting</li>
                <li>Software Support</li>
                <li><a href="http://www.mylive-tech.com/shop.html#!/~/category/id=694006&amp;offset=0&amp;sort=normal" title="Employee Management">Employee Management</a></li>
                <li><a href="http://www.mylive-tech.com/shop.html#!/~/category/id=694005&amp;offset=0&amp;sort=normal" title="Parental Controls">Parental Controls</a></li>
                <li><a href="http://www.mylive-tech.com/shop.html#!/~/category/id=694003&amp;offset=0&amp;sort=normal" title="Security">Security</a></li>
                <li><a href="http://www.mylive-tech.com/shop.html#!/~/category/id=975006&amp;offset=0&amp;sort=normal" title="Computer Care">Computer Care</a></li>
                <li>Software Installation</li>
                <li>Windows Updates &amp; Support</li>
                <li>Point of Sale Systems Support</li>
			</ul>
		</div>
		<div class="span2" style="background-color: #E9E9E9; padding: 10px 0px;">
			<ul>
                <li>Windows PowerShell</li>
                <li>3G / 4G Networks</li>
                <li>Wireless Security</li>
                <li>Wired &amp; Wireless Network</li>
                <li>Wired &amp; Wireless Router</li>
                <li>Files, Printers, &amp; Fax Sharing</li>
                <li>DSL, Cable, &amp; ISP Support</li>
                <li>Data Backup &amp; Restore</li>
                <li>Cloud Technologies</li>
                <li><a href="http://www.mylive-tech.com/shop.html#!/~/product/category=1211071&amp;id=4951475" title="Live-Tech Backup Solutions">Live-Tech Backup Solutions</a></li>
                <li>Firewall Installations &amp; Support</li>
				<li><a href="http://www.mylive-tech.com/shop.html#!/~/category/id=290429&amp;offset=0&amp;sort=normal" title="Website Hosting"> Website Hosting</a></li>
				<li><a href="http://www.mylive-tech.com/shop.html#!/~/category/id=1226034&amp;offset=0&amp;sort=normal" title="Website Development"> Website Development</a></li>
			</ul>
		</div>
		<div class="span2" style="background-color: #E9E9E9; padding: 10px 0px;">
			<ul>
                
                <li>iPhone &amp; BlackBerry Support</li>
                <li>Smartphone Support</li>
                <li><a href="http://support.mylive-tech.com/" title="Live-Tech Support Suite"> Live-Tech Support Suite </a></li>
                <li>Printer Installation &amp; Support</li>
                <li>E-Mail Setup &amp; Support</li>
                <li>Outlook Setup &amp; Support</li>
                <li><a href="http://www.mylive-tech.com/shop.html#!/~/category/id=271715&amp;offset=0&amp;sort=normal" title="Macintosh Setup &amp; Support">Macintosh Setup &amp; Support</a></li>
                <li>Air Card Support</li>
                <li><a href="http://www.mylive-tech.com/shop.html#!/~/category/id=264316&amp;offset=0&amp;sort=normal" title="TalkSwitch Phone System">TalkSwitch Phone System</a></li>
                <li><a href="http://www.mylive-tech.com/shop.html#!/~/category/id=264326&amp;offset=0&amp;sort=normal" title="TalkSwitch Support">TalkSwitch Support</a></li>
                <li><a href="http://www.mylive-tech.com/shop.html#!/~/category/id=271764&amp;offset=0&amp;sort=normal" title="VoIP Phone Services">VoIP Phone Services</a></li>
                <li>Network Copiers &amp; Scanners</li>
                <li><a href="http://www.mylive-tech.com/shop.html#!/~/category/id=1047100&amp;offset=0&amp;sort=normal" title="E-Fax (Digital Fax)">E-Fax (Digital Fax)</a></li>
                <li><a href="http://www.mylive-tech.com/shop.html#!/~/category/id=1047100&amp;offset=0&amp;sort=normal" title="ZippyFax Solutions">ZippyFax Solutions</a></li>
			</ul>
		</div>
		<div class="span2" style="background-color: #E9E9E9; padding: 10px 0px;">
			<ul>
                <li>Microsoft Office XP</li>
                <li>Microsoft Office 2000 Suites</li>
                <li>Microsoft Office 2003 Suites</li>
                <li>Microsoft Office 2007 Suites</li>
                <li>Microsoft Office 2010 Suites</li>
                <li>Microsoft Office 2013 Suites</li>
                <li>Microsoft Internet Explorer</li>
                <li>Microsoft Windows 2000</li>
                <li>Microsoft Windows Vista</li>
                <li>Microsoft Windows XP</li>
				<li>Microsoft Windows 7</li>
				<li>Microsoft Windows 8 / 8.1</li>
			</ul>
		</div>
		<div class="span2" style="background-color: #E9E9E9; padding: 10px 0px;">
			<ul>
                
                <li>Windows Small Business Server</li>
                <li><a href="http://www.livetechexchange.com" title="Live-Tech Hosted Microsoft Exchange 2010" target="_blank">Hosted Microsoft Exchange 2010</a></li>
                <li><a href="http://www.livetechexchange.com" title="Live-Tech Hosted Microsoft Exchange 2010" target="_blank">Hosted Microsoft Exchange 2013</a></li>
                <li>Hosted Microsoft SharePoint 2010</li>
                <li>Hosted Microsoft SharePoint 2013</li>
                <li>Microsoft Internet Security &amp; Acceleration Server</li>
                <li>Server Technologies - Microsoft BizTalk Server</li>
                <li>Microsoft  SharePoint Server</li>
                <li>Windows Essential Business Server</li>
			</ul>
		</div>
		<div class="span2" style="background-color: #E9E9E9; padding: 10px 0px;">
			<ul>
				<li>Microsoft Host Integration Server</li>
				<li>Microsoft Windows Server 2012</li>
                <li><a href="http://www.livetechexchange.com" title="Exchange Email Server">Exchange Email Server</a></li>
				<li>Microsoft Commerce Server</li>
                <li>Microsoft Content Management Server</li>
                <li>Microsoft SQL Server</li>
                <li><a href="http://www.mylive-tech.com/shop.html#!/~/category/id=628101&amp;offset=0&amp;sort=normal" title="CCTV/IP Security">CCTV/IP Security</a></li>
                <li><a href="http://www.mylive-tech.com/shop.html#!/~/category/id=628101&amp;offset=0&amp;sort=normal" title="DVR Systems">DVR Systems</a></li>
                <li><a href="http://brcontrol.com.br/ENG/BRCONTROL.html" title="BR Control">BR Control</a></li>
                <li><a href="http://brcontrol.com.br/ENG/BRREPORTER.html" title="BR Reporter">BR Reporter</a></li>
                <li><a href="http://brcontrol.com.br/ENG/ACCESSPATROL.html" title="AccessPatrol">AccessPatrol</a></li>
                <li><a href="http://brcontrol.com.br/ENG/ENPOWERMANAGER.html" title="EnPowerManager">EnPowerManager</a></li>
                <li><a href="http://www.mylive-tech.com/shop.html#!/~/category/id=975006&amp;offset=0&amp;sort=normal" title="Advanced System Care">Advanced System Care</a></li>
                <li><a href="http://www.mylive-tech.com/asc/" title="System Tune Up">System Tune Up</a></li>
			</ul>
		</div>
		</div>
	
	</div>
	
	</div>
	</footer>
	
	<?php do_action( 'wp_footer', '' ); ?>
    
    <!-- ScrollUp -->
	<script type="text/javascript">
	if( $(window).width() > 800 )
	{
		$(function () 
		{
			$.scrollUp
			({
				scrollName: 'scrollUp', // Element ID
			    topDistance: '300', // Distance from top before showing element (px)
			    topSpeed: 1200, // Speed back to top (ms)
			    animation: 'fade', // Fade, slide, none
			    animationInSpeed: 200, // Animation in speed (ms)
			    animationOutSpeed: 200, // Animation out speed (ms)
			    scrollText: 'Back to Top', // Text for element
			    activeOverlay: false, // Set CSS color to display scrollUp active point, e.g '#00FFFF'
			});
		});
	}
	</script>
   
    
		<!-- SupportSuite -->
	<script type="text/javascript" src="http://support.mylive-tech.com/visitor/index.php?_m=livesupport&_a=htmlcode&nolink=1"></script>
	
</body>
</html>
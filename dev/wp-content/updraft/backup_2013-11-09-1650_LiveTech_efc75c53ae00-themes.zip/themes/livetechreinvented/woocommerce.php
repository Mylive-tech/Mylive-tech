<?php get_header(); ?>
    <!-- post -->
    <div class="post">
    
   <div id="lt-breadcrumb"> <?php if ( function_exists('yoast_breadcrumb') ) {
yoast_breadcrumb('<p id="breadcrumbs">','</p>');
} ?></div>

    
			<div class="woocommerce">
<?php woocommerce_content(); ?>
</div>

 
    <div id="lt-sidebar">
<?php
if(is_active_sidebar('right-sidebar')){
dynamic_sidebar('right-sidebar');
}
?>
   </div>
    <!-- /post -->

 </div>
<?php get_footer(); ?>
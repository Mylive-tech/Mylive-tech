<?php get_header(); ?>

	<h1 class="post-title"> Links </h1>

	<p> Complete list of the blog's bookmarks. </p>

	<ul>
	   <?php wp_list_bookmarks( 'title_li=&title_before=<strong>&title_after=</strong>&category_before=<li>&category_after=</li>' ); ?>
	</ul>

<?php get_sidebar(); ?>

<?php get_footer(); ?>

<?php
/**
 * Plugin Name: WooCommerce First Data Gateway
 * Plugin URI: http://www.woothemes.com/products/firstdata/
 * Description: Accept credit cards in WooCommerce through the First Data GGe4 or Global Gateway
 * Author: SkyVerge
 * Author URI: http://www.skyverge.com
 * Version: 3.1
 * Text Domain: wc-firstdata
 * Domain Path: /languages/
 *
 * Copyright: (c) 2013 SkyVerge, Inc. (info@skyverge.com)
 *
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @package   WC-First-Data
 * @author    SkyVerge
 * @category  Payment-Gateways
 * @copyright Copyright (c) 2013, SkyVerge, Inc.
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Required functions
if ( ! function_exists( 'woothemes_queue_update' ) )
	require_once( 'woo-includes/woo-functions.php' );

// Plugin updates
woothemes_queue_update( plugin_basename( __FILE__ ), 'eb3e32663ec0810592eaf0d097796230', '18645' );

// Check if WooCommerce is active
if ( ! is_woocommerce_active() )
	return;

/**
 * The WC_FirstData global object
 * @name $wc_firstdata
 * @global WC_FirstData $GLOBALS['wc_firstdata']
 */
$GLOBALS['wc_firstdata'] = new WC_FirstData();

/**
 * The main class for the First Data Gateway.  This class handles all the
 * non-gateway tasks such as verifying dependencies are met, loading the text
 * domain, etc.  It also loads the First Data Gateway when needed now that the
 * gateway is only created on the checkout & settings pages / api hook.  The gateway is
 * also loaded in the following instances:
 *
 * + On the My Account page to display / change saved payment methods
 *
 */
class WC_FirstData {


	/** string plugin text domain */
	const TEXT_DOMAIN = 'wc-firstdata';

	/** string version number */
	const VERSION = '3.1';

	/** string the global gateway class name */
	const GLOBAL_GATEWAY_CLASS_NAME = 'WC_Gateway_FirstData_Global_Gateway';

	/** string the GGe4 gateway class name */
	const GGE4_GATEWAY_CLASS_NAME = 'WC_Gateway_FirstData';

	/** string the GGe4 addons gateway class name */
	const GGE4_ADDONS_GATEWAY_CLASS_NAME = 'WC_Gateway_FirstData_Addons';

	/** string the legacy global gateway id */
	const GLOBAL_GATEWAY_ID = 'firstdata-global-gateway';

	/** string the GGe4 gateway id */
	const GGE4_GATEWAY_ID = 'firstdata';


	/** @var string plugin path without trailing slash */
	private $plugin_path;

	/** @var string plugin uri */
	private $plugin_url;

	/** @var string class to load as gateway, can be base or add-ons class */
	public $gateway_class_name;

	/** @var \WC_Logger instance */
	private $logger;

	/** @var bool helper for lazy subscriptions active check */
	private $subscriptions_active;

	/** @var bool helper for lazy pre-orders active check */
	private $pre_orders_active;


	/**
	 * Setup main plugin class
	 *
	 * @since 3.0
	 */
	public function __construct() {

		// Load First Data API / Gateway
		add_action( 'plugins_loaded', array( $this, 'init' ) );

		add_action( 'init', array( $this, 'include_template_functions' ), 25 );

		// Admin
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {

			// handle switching between GGe4 and Global Gateway versions
			add_action( 'admin_action_wc_firstdata_change_gateway', array( $this, 'change_gateway' ) );

			// render any admin notices
			add_action( 'admin_notices', array( $this, 'render_admin_notices' ) );

			// add a 'Configure' link to the plugin action links
			add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'plugin_configure_link' ) );

			// run every time
			$this->install();
		}

		// Load translation files
		add_action( 'init', array( $this, 'load_translation' ) );
	}


	/**
	 * Initialize the gateway once all plugins are loaded:
	 * Loads API and Gateway classes
	 *
	 * @since 3.0
	 */
	public function init() {

		// Base gateway class
		if ( $this->using_gge4_gateway() ) {

			require( 'includes/class-wc-gateway-firstdata.php' );

			// load add-ons class if subscriptions and/or pre-orders are active and using the gge4 gateway
			if ( $this->is_subscriptions_active() || $this->is_pre_orders_active() ) {

				require( 'includes/class-wc-gateway-firstdata-addons.php' );
			}

			// Add the 'Manage My Payment Methods' on the 'My Account' page for the GGe4 gateway
			add_action( 'woocommerce_after_my_account', array( $this, 'add_my_payment_methods' ) );

		} else {

			// legacy global gateway class and library
			require( 'includes/class-wc-gateway-firstdata-global-gateway.php' );
			require( 'lib/lphp.php' );
		}

		// Add classes to WC Payment Methods
		add_filter( 'woocommerce_payment_gateways', array( $this, 'load_gateway' ) );

	}


	/**
	 * Function used to init WooCommerce First Data template functions,
	 * making them pluggable by plugins and themes.
	 *
	 * @since 3.0
	 */
	public function include_template_functions() {
		include_once( 'includes/wc-gateway-firstdata-template.php' );
	}


	/**
	 * Adds First Data to the list of available payment gateways
	 *
	 * @since 3.0
	 * @param array $gateways
	 * @return array $gateways
	 */
	public function load_gateway( $gateways ) {

		$gateways[] = $this->get_gateway_class_name();

		return $gateways;
	}


	/**
	 * Load plugin text domain
	 *
	 * @since 3.0
	 */
	public function load_translation() {

		load_plugin_textdomain( 'wc-firstdata', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}


	/** Admin methods ******************************************************/


	/**
	 * Checks if required PHP extensions are loaded and SSL is enabled. Adds an admin notice if either check fails.
	 * Also gateway settings are checked as well.
	 *
	 * @since  3.0
	 */
	public function render_admin_notices() {

		// report any missing extensions
		$missing_extensions = $this->get_missing_dependencies();

		if ( count( $missing_extensions ) > 0 ) {

			$message = sprintf(
				_n( 'WooCommerce First Data Gateway requires the %s PHP extension to function.  Contact your host or server administrator to configure and install the missing extension.',
				'WooCommerce First Data Gateway requires the following PHP extensions to function: %s.  Contact your host or server administrator to configure and install the missing extensions.',
				count( $missing_extensions ), self::TEXT_DOMAIN ),
				'<strong>' . implode( ', ', $missing_extensions ) . '</strong>'
			);

			echo '<div class="error"><p>' . $message . '</p></div>';
		}

		// Display a message on the Plugins list table if we've switched between GGe4 or Global Gateway
		if ( isset( $_GET['wc_firstdata_gateway'] ) && $_GET['wc_firstdata_gateway'] ) {
			if ( self::GGE4_GATEWAY_CLASS_NAME == $_GET['wc_firstdata_gateway'] ) {
				echo '<div class="updated"><p>' . sprintf( __( "%sFirst Data GGe4 Gateway is now being used.%s", self::TEXT_DOMAIN ), '<strong>', '</strong>' ) . '</p></div>';
			} elseif ( self::GLOBAL_GATEWAY_CLASS_NAME == $_GET['wc_firstdata_gateway'] ) {
				echo '<div class="updated"><p>' . sprintf( __( "%sFirst Data Global Gateway is now being used.%s", self::TEXT_DOMAIN ), '<strong>', '</strong>' ) . '</p></div>';
			}
		}

		// check settings:  gateway active and SSl enabled, and GGe4 v12 API enabled
		$settings = get_option( 'woocommerce_' . $this->get_gateway_id() . '_settings' );

		if ( isset( $settings['enabled'] ) && 'yes' == $settings['enabled'] ) {

			if ( isset( $settings['environment'] ) && 'production' == $settings['environment'] ) {
				// SSL check if gateway enabled/production mode
				if ( 'no' === get_option( 'woocommerce_force_ssl_checkout' ) )
					echo '<div class="error"><p>' . sprintf( __( "%sFirst Data Error%s: WooCommerce is not being forced over SSL; your customer's credit card data is at risk.", self::TEXT_DOMAIN ), '<strong>', '</strong>' ), '</p></div>';
			}

			// current environment
			$environment_prefix = isset( $settings['environment'] ) && 'demo' == $settings['environment'] ? 'demo_' : '';

			// if the GGe4 gateway is enabled and gateway id/password is configured (v11 API) but not
			//  the key id and hmac key (v12 API) display a notice recommending they take action to do so.  Note
			//  that we're pulling the raw settings array here, which kind of sucks but is more convenient than
			//  loading the gateway on every admin page request
			if ( isset( $settings[ $environment_prefix . 'gateway_id' ] ) && $settings[ $environment_prefix . 'gateway_id' ] &&
				isset( $settings[ $environment_prefix . 'gateway_password' ] ) && $settings[ $environment_prefix . 'gateway_password' ] &&
				( ! isset( $settings[ $environment_prefix . 'key_id' ] ) || ! $settings[ $environment_prefix . 'key_id' ] ||
				! isset( $settings[ $environment_prefix . 'hmac_key' ] ) || ! $settings[ $environment_prefix . 'hmac_key' ] ) ) {

				echo '<div class="updated"><p>' . sprintf( __( "%sFirst Data GGe4 Gateway:%s It's recommended that you %sconfigure%s the new Key ID and Hmac Key settings for increased transaction security.  See the %sdocumentation%s for further details.", self::TEXT_DOMAIN ), '<strong>', '</strong>', '<a href="' . $this->get_settings_url() . '">', '</a>', '<a href="http://docs.woothemes.com/document/firstdata#api-security">', '</a>' ) . '</p></div>';
			}
		}
	}


	/**
	 * Return the plugin action links.  This will only be called if the plugin
	 * is active.
	 *
	 * @since 3.0
	 * @param array $actions associative array of action names to anchor tags
	 * @return array associative array of plugin action links
	 */
	public function plugin_configure_link( $actions ) {

		global $status, $page, $s;

		// add an action to switch between the legacy Global Gateway and GGe4 versions
		if ( $this->using_gge4_gateway() ) {
			$actions['use_global_gateway'] = '<a href="' . wp_nonce_url( 'admin.php?action=wc_firstdata_change_gateway&amp;gateway=' . self::GLOBAL_GATEWAY_CLASS_NAME . '&amp;plugin_status=' . $status . '&amp;paged=' . $page . '&amp;s=' . $s, 'wc-firstdata-change-gateway_' . __FILE__ ) . '" title="' . esc_attr__( 'Use the Global Gateway', self::TEXT_DOMAIN ) . '">' . __( 'Use Global Gateway', self::TEXT_DOMAIN ) . '</a>';
		} else {
			$actions['use_gge4_gateway'] = '<a href="' . wp_nonce_url( 'admin.php?action=wc_firstdata_change_gateway&amp;gateway=' . self::GGE4_GATEWAY_CLASS_NAME . '&amp;plugin_status=' . $status . '&amp;paged=' . $page . '&amp;s=' . $s, 'wc-firstdata-change-gateway_' . __FILE__ ) . '" title="' . esc_attr__( 'Use the GGe4 Gateway', self::TEXT_DOMAIN ) . '">' . __( 'Use GGe4', self::TEXT_DOMAIN ) . '</a>';
		}

		// add a 'Configure' link to the front of the actions list for this plugin
		$actions['configure'] = '<a href="' . $this->get_settings_url() . '">' . __( 'Configure', self::TEXT_DOMAIN ) . '</a>';

		return $actions;
	}


	/**
	 * Implements the Admin Plugins page change gateway action
	 *
	 * @since 3.0
	 */
	public function change_gateway() {

		// Plugins page arguments
		$plugin_status = isset( $_GET['plugin_status'] ) ? $_GET['plugin_status'] : '';
		$page          = isset( $_GET['paged'] ) ? $_GET['paged'] : '';
		$s             = isset( $_GET['s'] ) ? $_GET['s'] : '';

		// the gateway version to use
		$gateway = isset( $_GET['gateway'] ) ? $_GET['gateway'] : '';

		// get the base return url
		$return_url = admin_url( 'plugins.php?plugin_status=' . $plugin_status . '&paged=' . $page . '&s=' . $s );

		// security check
		if ( ! wp_verify_nonce( $_GET['_wpnonce'], 'wc-firstdata-change-gateway_' . __FILE__ ) ) {
			wp_redirect( $return_url );
			exit;
		}

		// one of the known gateways
		if ( self::GLOBAL_GATEWAY_CLASS_NAME == $gateway || self::GGE4_GATEWAY_CLASS_NAME == $gateway ) {
			update_option( 'wc_firstdata_gateway', $gateway );
			$return_url = add_query_arg( array( 'wc_firstdata_gateway' => $gateway ), $return_url );
		}

		// back to whence we came
		wp_redirect( $return_url );
		exit;
	}


	/** Frontend methods ******************************************************/


	/**
	 * Helper to add the 'My Cards' section to the 'My Account' page
	 *
	 * Available only for the GGe4 gateway
	 *
	 * @since 3.0
	 */
	public function add_my_payment_methods() {

		$gateway = new WC_Gateway_FirstData();

		$gateway->show_my_payment_methods();
	}


	/** Lifecycle methods ******************************************************/


	/**
	 * Handles version checking
	 *
	 * @since 3.0
	 */
	private function install() {

		$installed_version = get_option( 'wc_firstdata_version' );

		// installed version lower than plugin version?
		if ( -1 === version_compare( $installed_version, self::VERSION ) ) {

			$this->upgrade( $installed_version );

			// new version number
			update_option( 'wc_firstdata_version', self::VERSION );
		}
	}


	/**
	 * Handles upgrades
	 *
	 * @since 3.0
	 * @param string $installed_version the currently installed version
	 */
	private function upgrade( $installed_version ) {

		if ( ! $installed_version && ( $settings = get_option( 'woocommerce_' . self::GGE4_GATEWAY_ID . '_settings' ) ) ) {
			// upgrading from the pre-rewrite version, need to adjust the settings array

			if ( isset( $settings['pemfile'] ) ) {
				// Global Gateway: the new global gateway id is firstdata-global-gateway, so
				//  we'll make that change and set the Global Gateway as the active version
				//  for a seamless "upgrade" from the previous standalone Global Gateway plugin

				// sandbox -> environment
				if ( isset( $settings['sandbox'] ) && 'yes' == $settings['sandbox'] ) {
					$settings['environment'] = 'sandbox';
				} else {
					$settings['environment'] = 'production';
				}
				unset( $settings['sandbox'] );

				// rename the settings option
				delete_option( 'woocommerce_' . self::GGE4_GATEWAY_ID . '_settings' );
				update_option( 'woocommerce_' . self::GLOBAL_GATEWAY_ID . '_settings', $settings );

				// Make the Global Gateway version active
				update_option( 'wc_firstdata_gateway', self::GLOBAL_GATEWAY_CLASS_NAME );

			} else {
				// GGe4

				// logger -> debug_mode
				if ( ! isset( $settings['logger'] ) || 'no' == $settings['logger'] ) {
					$settings['debug_mode'] = 'off';
				} elseif ( isset( $settings['logger'] ) && 'yes' == $settings['logger'] ) {
					$settings['debug_mode'] = 'log';
				}
				unset( $settings['logger'] );

				// set demo fields
				if ( isset( $settings['environment'] ) && 'demo' == $settings['environment'] ) {
					$settings['demo_gateway_id']       = $settings['gateway_id'];
					$settings['demo_gateway_password'] = $settings['gateway_password'];

					$settings['gateway_id']       = '';
					$settings['gateway_password'] = '';
				}

				// set the updated options array
				update_option( 'woocommerce_firstdata_settings', $settings );
			}
		}
	}


	/** Helper methods ******************************************************/


	/**
	 * Gets the string name of any required PHP extensions that are not loaded
	 *
	 * @since 3.0
	 * @return array
	 */
	public function get_missing_dependencies() {

		$missing_extensions = array();

		foreach ( $this->get_dependencies() as $ext ) {

			if ( ! extension_loaded( $ext ) )
				$missing_extensions[] = $ext;
		}

		return $missing_extensions;
	}


	/**
	 * Get the PHP dependencies for extension depending on the gateway being used
	 *
	 * @since 3.0
	 * @return array of required PHP extension names, based on the gateway in use
	 */
	private function get_dependencies() {

		if ( $this->using_global_gateway() )
			return array( 'curl' );
		else
			return array( 'SimpleXML', 'xmlwriter', 'dom', 'hash' );  // GGe4 dependencies
	}


	/**
	 * Checks is WooCommerce Subscriptions is active
	 *
	 * @since 3.0
	 * @return bool true if WCS is active, false if not active
	 */
	public function is_subscriptions_active() {

		if ( is_bool( $this->subscriptions_active ) )
			return $this->subscriptions_active;

		$active_plugins = (array) get_option( 'active_plugins', array() );

		if ( is_multisite() )
			$active_plugins = array_merge( $active_plugins, get_site_option( 'active_sitewide_plugins', array() ) );

		return $this->subscriptions_active = in_array( 'woocommerce-subscriptions/woocommerce-subscriptions.php', $active_plugins ) || array_key_exists( 'woocommerce-subscriptions/woocommerce-subscriptions.php', $active_plugins );
	}


	/**
	 * Checks is WooCommerce Pre-Orders is active
	 *
	 * @since 3.0
	 * @return bool true if WC Pre-Orders is active, false if not active
	 */
	public function is_pre_orders_active() {

		if ( is_bool( $this->pre_orders_active ) )
			return $this->pre_orders_active;

		$active_plugins = (array) get_option( 'active_plugins', array() );

		if ( is_multisite() )
			$active_plugins = array_merge( $active_plugins, get_site_option( 'active_sitewide_plugins', array() ) );

		return $this->pre_orders_active = in_array( 'woocommerce-pre-orders/woocommerce-pre-orders.php', $active_plugins ) || array_key_exists( 'woocommerce-pre-orders/woocommerce-pre-orders.php', $active_plugins );
	}


	/**
	 * Saves errors or messages to WooCommerce Log (woocommerce/logs/firstdata.txt)
	 *
	 * @since 3.0
	 * @param string $message error or message to save to log
	 */
	public function log( $message ) {
		global $woocommerce;

		if ( ! is_object( $this->logger ) )
			$this->logger = $woocommerce->logger();

		$this->logger->add( 'firstdata', $message );
	}


	/** Getter methods ******************************************************/


	/**
	 * Gest the gateway settings URL
	 *
	 * @since 3.0
	 * @return string gateway settings URL
	 */
	private function get_settings_url() {

		$manage_url = admin_url( 'admin.php?page=woocommerce_settings&tab=payment_gateways' );

		if ( version_compare( WOOCOMMERCE_VERSION, "2.0.0" ) >= 0 )
			$manage_url = add_query_arg( array( 'section' => $this->get_gateway_class_name() ), $manage_url ); // WC 2.0+
		else
			$manage_url = add_query_arg( array( 'subtab' => 'gateway-' . $this->get_gateway_id() ), $manage_url ); // WC 1.6.6-

		return $manage_url;
	}


	/**
	 * Gets the gateway class name.  This is one of the following:
	 *
	 * * WC_Gateway_FirstData_Global_Gateway - if the legacy gateway is enabled
	 * * WC_Gateway_FirstData - if the GGe4 gateway is enabled (default)
	 * * WC_Gateway_FirstData_Addons - if GGe4 is enabled and pre-orders or subscriptions plugins are installed and active
	 *
	 * @since 3.0
	 * @return string the gateway class name
	 */
	public function get_gateway_class_name() {

		if ( ! isset( $this->gateway_class_name ) ) {

			// get the configured gateway class
			$this->gateway_class_name = get_option( 'wc_firstdata_gateway', self::GGE4_GATEWAY_CLASS_NAME );

			// GGe4 version supports subscriptions/pre-orders
			if ( self::GGE4_GATEWAY_CLASS_NAME == $this->gateway_class_name && ( $this->is_subscriptions_active() || $this->is_pre_orders_active() ) ) {
				$this->gateway_class_name = self::GGE4_ADDONS_GATEWAY_CLASS_NAME;
			}
		}

		return $this->gateway_class_name;
	}


	/**
	 * Gets the gateway id for the current gateway
	 *
	 * @since 3.0
	 * @return string returns either 'firstdata' or 'firstdata-global-gateway'
	 */
	public function get_gateway_id() {
		return $this->using_gge4_gateway() ? self::GGE4_GATEWAY_ID : self::GLOBAL_GATEWAY_ID;
	}


	/**
	 * Returns the plugin's path without a trailing slash, i.e.
	 * /path/to/wp-content/plugins/plugin-directory
	 *
	 * @since 3.0
	 * @return string the plugin path
	 */
	public function get_plugin_path() {

		if ( $this->plugin_path )
			return $this->plugin_path;

		return $this->plugin_path = untrailingslashit( plugin_dir_path( __FILE__ ) );
	}


	/**
	 * Returns the plugin's url without a trailing slash, i.e.
	 * http://skyverge.com/wp-content/plugins/plugin-directory
	 *
	 * @since  3.0
	 * @return string the plugin URL
	 */
	public function get_plugin_url() {

		if ( $this->plugin_url )
			return $this->plugin_url;

		return $this->plugin_url = untrailingslashit( plugins_url( '/', __FILE__ ) );
	}


	/**
	 * Returns true if the legacy Global Gateway is being used
	 *
	 * @since 3.0
	 * @return boolean true if the legacy Global Gateway is being used
	 */
	private function using_global_gateway() {
		return self::GLOBAL_GATEWAY_CLASS_NAME == $this->get_gateway_class_name();
	}


	/**
	 * Returns true if the GGe4 Gateway is being used
	 *
	 * @since 3.0
	 * @return boolean true if the GGe4 Gateway is being used
	 */
	private function using_gge4_gateway() {
		return ! $this->using_global_gateway();
	}


}

<?php
/**
 * WooCommerce First Data
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce First Data to newer
 * versions in the future. If you wish to customize WooCommerce First Data for your
 * needs please refer to http://docs.woothemes.com/document/firstdata/
 *
 * @package     WC-First-Data/Gateway-Addons
 * @author      SkyVerge
 * @copyright   Copyright (c) 2013, SkyVerge, Inc.
 * @license     http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * First Data Addons Class
 *
 * Extends the base First Data gateway to provide support for WC Add-ons -- Subscriptions and Pre-Orders
 *
 * @since 3.0
 */
class WC_Gateway_FirstData_Addons extends WC_Gateway_FirstData {


	/**
	 * Load parent gateway and add-on specific hooks
	 *
	 * @since 3.0
	 */
	public function __construct() {
		global $wc_firstdata;

		// load parent gateway
		parent::__construct();

		// add subscription support if active and First Data tokenization is enabled
		if ( $this->tokenization_enabled() && $wc_firstdata->is_subscriptions_active() ) {

			$this->supports = array_merge( $this->supports,
				array(
					'subscriptions',
					'subscription_suspension',
					'subscription_cancellation',
					'subscription_reactivation',
					'subscription_amount_changes',
					'subscription_date_changes'
				)
			);

			// process scheduled subscription payments
			add_action( 'scheduled_subscription_payment_' . $this->id, array( $this, 'process_scheduled_subscription_payment' ), 10, 3 );

			// prevent unnecessary order meta from polluting parent renewal orders
			add_filter( 'woocommerce_subscriptions_renewal_order_meta_query', array( $this, 'remove_subscriptions_renewal_order_meta' ), 10, 4 );
		}

		// add pre-orders support if active and First Data tokenization is enabled
		if ( $this->tokenization_enabled() && $wc_firstdata->is_pre_orders_active() ) {

			$this->supports = array_merge( $this->supports,
				array(
					'pre-orders',
				)
			);

			// process batch pre-order payments
			add_action( 'wc_pre_orders_process_pre_order_completion_payment_' . $this->id, array( $this, 'process_pre_order_payment' ) );
		}
	}


	/**
	 * Don't render the "securely save card" element on the pay page for
	 * subscription transactions or pre-order requiring payment tokenization
	 * as the card will always be saved
	 *
	 * @since 3.0
	 * @return boolean true if tokenization should be forced on the checkout page, false otherwise
	 */
	public function tokenization_forced() {
		global $wc_firstdata;

		if ( ( $wc_firstdata->is_subscriptions_active() && WC_Subscriptions_Cart::cart_contains_subscription() ) ||
			( $wc_firstdata->is_pre_orders_active() &&
			WC_Pre_Orders_Cart::cart_contains_pre_order() &&
			WC_Pre_Orders_Product::product_is_charged_upon_release( WC_Pre_Orders_Cart::get_pre_order_product() ) ) ) {

			// always tokenize the card for subscription transactions or pre-orders that are charged upon release
			return true;

		} else {

			return parent::tokenization_forced();

		}
	}


	/**
	 * Process payment for an order:
	 * 1) If the order contains a subscription, process the initial subscription payment (could be $0 if a free trial exists)
	 * 2) If the order contains a pre-order, process the pre-order total (could be $0 if the pre-order is charged upon release)
	 * 3) Otherwise use the parent::process_payment() method for regular product purchases
	 *
	 * @since 3.0
	 * @param int $order_id
	 * @return array
	 */
	public function process_payment( $order_id ) {

		global $woocommerce, $wc_firstdata;

		// processing subscription
		if ( $wc_firstdata->is_subscriptions_active() && WC_Subscriptions_Order::order_contains_subscription( $order_id ) ) {

			$order = $this->get_order( $order_id );

			// set subscription-specific order description
			$order->description = sprintf( __( '%s - Subscription Order %s', WC_FirstData::TEXT_DOMAIN ), esc_html( get_bloginfo( 'name' ) ), $order->get_order_number() );

			// get subscription amount
			$order->payment_total = WC_Subscriptions_Order::get_total_initial_payment( $order );

			try {


				// existing tokenized payment method?
				if ( isset( $order->payment->token ) && $order->payment->token ) {

					// zero dollar initial payment, there's nothing further to do, just record the
					if ( 0 == $order->payment_total ) {

						// save the tokenized card info for charging the subscription in the future since we'll be skipping the do_transaction() call
						update_post_meta( $order->id, '_wc_firstdata_card_type',        $order->payment->type );
						update_post_meta( $order->id, '_wc_firstdata_card_expiry_date', $order->payment->exp_date );
						update_post_meta( $order->id, '_wc_firstdata_environment',      $this->get_environment() );
						update_post_meta( $order->id, '_wc_firstdata_transarmor_token', $order->payment->token );

					}

				} else {

					// otherwise tokenize the payment method
					$order = $this->create_payment_token( $order );

					if ( ! $order->payment->token ) {
						// no token returned, indicating an incorrectly configured account, can't go any further
						$this->mark_order_as_failed( $order, __( "Tokenization attempt failed.", WC_FirstData::TEXT_DOMAIN ), __( 'An error occurred during payment, please contact us to complete your transaction.', WC_FirstData::TEXT_DOMAIN ) );
						return;
					}
				}

				// process transaction: if this is a zero dollar order and we already have a credit card token there's no need to perform a transaction, otherwise do so
				if (  0 == $order->payment_total || $this->do_transaction( $order ) ) {

					$order->payment_complete(); // mark order as having received payment

					$woocommerce->cart->empty_cart();

					return array(
						'result'   => 'success',
						'redirect' => $this->get_return_url( $order ),
					);
				}

			} catch ( Exception $e ) {

				// log API requests/responses here too, as exceptions could be thrown before $response object is returned
				$this->log_api();

				$this->mark_order_as_failed( $order, $e->getMessage() );
			}

		} elseif ( $wc_firstdata->is_pre_orders_active() && WC_Pre_Orders_Order::order_contains_pre_order( $order_id ) ) {
			// processing pre-order

			// do pre-authorization
			if ( WC_Pre_Orders_Order::order_requires_payment_tokenization( $order_id ) ) {

				$order = $this->get_order( $order_id );

				// set pre-order-specific order description
				$order->description = sprintf( __( '%s - Pre-Order Authorization %s', WC_FirstData::TEXT_DOMAIN ), esc_html( get_bloginfo( 'name' ) ), $order->get_order_number() );

				try {

					// using an existing tokenized cc
					if ( isset( $order->payment->token ) && $order->payment->token ) {

						// save the tokenized card info for completing the pre-order in the future
						update_post_meta( $order->id, '_wc_firstdata_card_type',        $order->payment->type );
						update_post_meta( $order->id, '_wc_firstdata_card_expiry_date', $order->payment->exp_date );
						update_post_meta( $order->id, '_wc_firstdata_environment',      $this->get_environment() );
						update_post_meta( $order->id, '_wc_firstdata_transarmor_token', $order->payment->token );

					} else {

						// otherwise tokenize the payment method
						$order = $this->create_payment_token( $order );

						if ( ! $order->payment->token ) {
							// no token returned, indicating an incorrectly configured account, can't go any further
							$this->mark_order_as_failed( $order, __( "Tokenization attempt failed.", WC_FirstData::TEXT_DOMAIN ), __( 'An error occurred during payment, please contact us to complete your transaction.', WC_FirstData::TEXT_DOMAIN ) );
							return;
						}
					}

					// mark order as pre-ordered / reduce order stock
					WC_Pre_Orders_Order::mark_order_as_pre_ordered( $order );

					// empty cart
					$woocommerce->cart->empty_cart();

					// redirect to thank you page
					return array(
						'result'   => 'success',
						'redirect' => $this->get_return_url( $order ),
					);

				} catch ( Exception $e ) {

					// log API requests/responses here too, as exceptions could be thrown before $response object is returned
					$this->log_api();

					$this->mark_order_as_failed( $order, $e->getMessage() );
				}

			} else {

				// charged upfront (or paying for a newly-released pre-order with the gateway), process just like regular product
				return parent::process_payment( $order_id );
			}

		} else {
			// processing regular product

			return parent::process_payment( $order_id );
		}
	}


	/**
	 * Process a pre-order payment when the pre-order is released
	 *
	 * @since 3.0
	 * @param \WC_Order $order original order containing the pre-order
	 * @throws Exception
	 */
	public function process_pre_order_payment( $order ) {

		// set order defaults
		$order = $this->get_order( $order->id );

		// order description
		$order->description = sprintf( __( '%s - Pre-Order Release Payment for Order %s', WC_FirstData::TEXT_DOMAIN ), esc_html( get_bloginfo( 'name' ) ), $order->get_order_number() );

		// get the card token to complete the order
		$order->payment->token    = $order->order_custom_fields['_wc_firstdata_transarmor_token'][0];
		$order->payment->exp_date = $order->order_custom_fields['_wc_firstdata_card_expiry_date'][0];
		$order->payment->type     = $order->order_custom_fields['_wc_firstdata_card_type'][0];

		try {

			// token, expiration date and type are required
			if ( ! $order->payment->token || ! $order->payment->exp_date || ! $order->payment->type )
				throw new Exception( __( 'Pre-Order Release: Customer or Payment Profile is missing.', WC_FirstData::TEXT_DOMAIN ) );

			$response = $this->get_api()->create_new_transaction( $order );

			$this->log_api();

			// success! update order record
			if ( $response->transaction_approved() ) {

				// add order note
				$order->add_order_note( sprintf( __( 'First Data Pre-Order Release Payment Approved (Sequence Number: %s) ', WC_FirstData::TEXT_DOMAIN ), $response->get_sequence_no() ) );

				// complete the order
				$order->payment_complete();

			} else {

				// log API requests/responses here too, as exceptions could be thrown before $response object is returned
				$this->log_api();

				// failure
				throw new Exception( $response->get_failure_message() );
			}

		} catch ( Exception $e ) {

			// Mark order as failed
			$message = sprintf( __( 'First Data Pre-Order Release Payment Failed (Result: %s)', WC_FirstData::TEXT_DOMAIN ), $e->getMessage() );

			if ( 'failed' != $order->status )
				$order->update_status( 'failed', $message );
			else
				$order->add_order_note( $message );

			$this->add_debug_message( $e->getMessage(), 'error' );
		}
	}


	/**
	 * Process subscription renewal
	 *
	 * @since 3.0
	 * @param float $amount_to_charge subscription amount to charge, could include multiple renewals if they've previously failed and the admin has enabled it
	 * @param WC_Order $order original order containing the subscription
	 * @param int $product_id the ID of the subscription product
	 * @throws Exception
	 */
	public function process_scheduled_subscription_payment( $amount_to_charge, $order, $product_id ) {

		try {

			// set order defaults
			$order = $this->get_order( $order->id );

			// set custom class members used by API ( @see WC_Gateway_FirstData::get_order() )
			$order->payment_total    = $amount_to_charge;
			$order->transaction_type = 0 != $order->payment_total ? $this->transaction_type : self::TRANSACTION_TYPE_PRE_AUTHORIZATION_ONLY;
			$order->description      = sprintf( __( '%s - Renewal for Subscription Order %s', WC_FirstData::TEXT_DOMAIN ), esc_html( get_bloginfo( 'name' ) ), $order->get_order_number() );

			// required: token from parent order
			if ( ! isset( $order->order_custom_fields['_wc_firstdata_transarmor_token'][0] ) || ! $order->order_custom_fields['_wc_firstdata_transarmor_token'][0] )
				throw new Exception( __( 'Subscription Renewal: TransArmor token is missing.', WC_FirstData::TEXT_DOMAIN ) );

			// Could use get_active_payment_profile_id() to charge the active
			//  card on file for renewals, but this is confusing for customers
			//  on sites that sell both subscriptions and products instead use
			//  the same payment profile that was used to purchase the subscription
			$token = $order->order_custom_fields['_wc_firstdata_transarmor_token'][0];
			$card = $this->get_credit_card_token_details( $order->user_id, $token );

			// token did not correspond to one of our saved cards (this could be due to the customer deleting that card)
			if ( ! $card )
				throw new Exception( __( 'Subscription Renewal: TransArmor token no longer exists.', WC_FirstData::TEXT_DOMAIN ) );

			// set the fields required for correct order processing
			$order->payment->token    = $token;
			$order->payment->exp_date = $card['exp_date'];
			$order->payment->type     = $card['type'];

			$response = $this->get_api()->create_new_transaction( $order );

			// log the transaction
			$this->add_debug_message( __( 'Subscription Renewal', WC_FirstData::TEXT_DOMAIN ) );
			$this->log_api();

			// success! update order record
			if ( $response->transaction_approved() ) {

				// add order note
				$order->add_order_note( __( 'First Data Subscription Renewal Payment Approved', WC_FirstData::TEXT_DOMAIN ) );

				// update subscription
				WC_Subscriptions_Manager::process_subscription_payments_on_order( $order, $product_id );

			} else {
				// failure
				throw new Exception( $response->get_failure_message() );
			}

		} catch ( Exception $e ) {

			// log API requests/responses here too, as exceptions could be thrown before $response object is returned
			$this->log_api();

			$order->add_order_note( sprintf( __( 'First Data Subscription Renewal Payment Failed (Result: %s)', WC_FirstData::TEXT_DOMAIN ), $e->getMessage() ) );

			$this->add_debug_message( $e->getMessage(), 'error' );

			// update subscription
			WC_Subscriptions_Manager::process_subscription_payment_failure_on_order( $order, $product_id );
		}
	}


	/**
	 * Don't copy over profile/payment meta when creating a parent renewal order
	 *
	 * @since 3.0
	 * @param array $order_meta_query MySQL query for pulling the metadata
	 * @param int $original_order_id Post ID of the order being used to purchased the subscription being renewed
	 * @param int $renewal_order_id Post ID of the order created for renewing the subscription
	 * @param string $new_order_role The role the renewal order is taking, one of 'parent' or 'child'
	 * @return string
	 */
	public function remove_subscriptions_renewal_order_meta( $order_meta_query, $original_order_id, $renewal_order_id, $new_order_role ) {

		if ( 'parent' == $new_order_role )
			$order_meta_query .= " AND `meta_key` NOT IN ("
							  . "'_wc_firstdata_transaction_tag', "
							  . "'_wc_firstdata_authorization_num', "
							  . "'_wc_firstdata_sequence_no', "
							  . "'_wc_firstdata_card_type', "
							  . "'_wc_firstdata_card_last_four', "
							  . "'_wc_firstdata_card_expiry_date', "
							  . "'_wc_firstdata_environment', "
							  . "'_wc_firstdata_transarmor_token' )";

		return $order_meta_query;
	}


} // end WC_Gateway_FirstData_Addons class

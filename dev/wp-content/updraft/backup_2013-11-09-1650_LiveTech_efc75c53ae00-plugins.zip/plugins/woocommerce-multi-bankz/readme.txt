﻿=== WooCommerce MultiBank ===
Contributors: André Carrano
Donate link: www.basequatro.com
Tags: woocommerce, bank, multi, multibank, gateway, account, various, woo, cielo, f2b, boleto, bb, hasb, bradesco, itaú, santander
Requires at least: 3.3
Tested up to: 3.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Stable tag: 0.1


Accept up to 5 different banks accounts to show to your customer. This is a simple gateway for who want to sell with many different bank accounts.

== Description ==

Accept up to 5 different banks accounts to show to your customer. This is a simple gateway for who want to sell with many different bank accounts.

This module will be discontinued when woocommerce release the v1.7 that comes with multibank option. If you have any sugestion please ask here in support.

----

<a href="http://www.basequatro.com">Adquira a versão dos módulos de pegamento</a> direto com a CIELO, F2b, Boleto direto, Caixa CEF, BB, Itaú, HSBC, Santander e Bradesco.

== Installation ==

1. Upload folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Set you bank accounts in Payment Gateway tab in Woocommerce

== Frequently asked questions ==

**How i can configure?**

Enter in Woocommerce - Configuration - Payment - MultiBank

= Support =

No support will be provided for this plugin, but if have any questions please use the forum.

== Screenshots ==

1. 

== Changelog ==

0.1 - Initial Release

== Upgrade notice ==



